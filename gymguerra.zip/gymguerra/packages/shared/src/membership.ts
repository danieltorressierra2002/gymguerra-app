/**
 * Lógica de membresías compartida entre la API y el frontend.
 *
 * Reglas (equivalen al semáforo original de src/lib/membership.js):
 *  - daysLeft = días entre HOY y la fecha de vencimiento (puede ser negativo).
 *  - endDate es la fecha de vencimiento, igual que en la app original: ese día
 *    todavía cuenta. Un plan de 1 mes que empieza el 9 de nov vence el 9 de dic, y la
 *    renovación empieza ese mismo día (el periodo es [inicio, vencimiento)).
 *  - Los planes se miden en MESES CALENDARIO o en DÍAS. Si el mes de destino no tiene
 *    ese día se usa el último (31 de ene + 1 mes = 28 de feb), a diferencia de
 *    Date.setMonth, que se desbordaría al 3 de marzo.
 *  - Vencido:   daysLeft < 0   (la fecha de vencimiento ya pasó)
 *  - Por vencer: 0 <= daysLeft <= warningDays   (antes DIAS_ALERTA_AMARILLO)
 *  - Al día:    daysLeft > warningDays
 *  - Pausada y cancelada son estados explícitos y tienen prioridad.
 *
 * Todas las fechas son cadenas "AAAA-MM-DD" (sin hora) para evitar errores de
 * zona horaria. "Hoy" se calcula en la zona horaria del gimnasio.
 */

export type StoredStatus = 'ACTIVE' | 'FROZEN' | 'CANCELLED';
export type SemaforoState = 'OK' | 'EXPIRING' | 'EXPIRED' | 'FROZEN' | 'CANCELLED';

export interface Semaforo {
  state: SemaforoState;
  /** null cuando está cancelada. En pausa: días que le quedaban al pausar. */
  daysLeft: number | null;
}

export const DEFAULT_WARNING_DAYS = 5;

const DAY_MS = 86_400_000;
const ISO_DATE = /^\d{4}-\d{2}-\d{2}$/;

export function isValidIsoDate(value: string): boolean {
  if (!ISO_DATE.test(value)) return false;
  const [y, m, d] = value.split('-').map(Number) as [number, number, number];
  const date = new Date(Date.UTC(y, m - 1, d));
  return date.getUTCFullYear() === y && date.getUTCMonth() === m - 1 && date.getUTCDate() === d;
}

function toMs(iso: string): number {
  if (!isValidIsoDate(iso)) throw new RangeError(`Fecha inválida: ${iso}`);
  const [y, m, d] = iso.split('-').map(Number) as [number, number, number];
  return Date.UTC(y, m - 1, d);
}

export function addDays(iso: string, days: number): string {
  if (!Number.isInteger(days)) throw new RangeError('days debe ser entero');
  return new Date(toMs(iso) + days * DAY_MS).toISOString().slice(0, 10);
}

/** Días de `from` a `to` (negativo si `to` es anterior). */
export function daysBetween(from: string, to: string): number {
  return Math.round((toMs(to) - toMs(from)) / DAY_MS);
}

/** Fecha de hoy ("AAAA-MM-DD") en la zona horaria indicada (IANA, p. ej. "America/Havana"). */
export function todayInTimeZone(timeZone = 'UTC', now: Date = new Date()): string {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(now);
}

/** Suma meses calendario; si el mes de destino no tiene ese día, usa su último día. */
export function addMonths(iso: string, months: number): string {
  if (!Number.isInteger(months)) throw new RangeError('months debe ser entero');
  const d = new Date(toMs(iso));
  const total = d.getUTCMonth() + months;
  const year = d.getUTCFullYear() + Math.floor(total / 12);
  const month = ((total % 12) + 12) % 12;
  const lastDay = new Date(Date.UTC(year, month + 1, 0)).getUTCDate();
  return new Date(Date.UTC(year, month, Math.min(d.getUTCDate(), lastDay))).toISOString().slice(0, 10);
}

/** Un plan dura N meses calendario o N días (exactamente uno de los dos). */
export type PlanDuration = { months: number } | { days: number };

/** Fecha de vencimiento de una membresía que empieza en `startDate`. */
export function computeEndDate(startDate: string, duration: PlanDuration): string {
  if ('months' in duration) {
    if (!Number.isInteger(duration.months) || duration.months < 1) {
      throw new RangeError('months debe ser un entero >= 1');
    }
    return addMonths(startDate, duration.months);
  }
  if (!Number.isInteger(duration.days) || duration.days < 1) {
    throw new RangeError('days debe ser un entero >= 1');
  }
  return addDays(startDate, duration.days);
}

/**
 * Inicio de una renovación: el día del vencimiento si aún está vigente (así el día
 * de cobro no se corre), o hoy si ya venció (no se cobran días sin membresía).
 */
export function nextStartDate(previousEndDate: string, today: string): string {
  return previousEndDate >= today ? previousEndDate : today;
}

export interface SemaforoInput {
  status: StoredStatus;
  endDate: string;
  today: string;
  warningDays?: number;
  /** Fecha en que se pausó (solo si status = FROZEN). */
  frozenAt?: string | null;
}

export function computeSemaforo(input: SemaforoInput): Semaforo {
  const warningDays = input.warningDays ?? DEFAULT_WARNING_DAYS;
  if (!Number.isInteger(warningDays) || warningDays < 0) {
    throw new RangeError('warningDays debe ser un entero >= 0');
  }

  if (input.status === 'CANCELLED') return { state: 'CANCELLED', daysLeft: null };

  if (input.status === 'FROZEN') {
    return { state: 'FROZEN', daysLeft: daysBetween(input.frozenAt ?? input.today, input.endDate) };
  }

  const daysLeft = daysBetween(input.today, input.endDate);
  if (daysLeft < 0) return { state: 'EXPIRED', daysLeft };
  if (daysLeft <= warningDays) return { state: 'EXPIRING', daysLeft };
  return { state: 'OK', daysLeft };
}

/** Al reanudar una pausa, el vencimiento se corre los días que estuvo pausada. */
export function unfreezeEndDate(
  endDate: string,
  frozenAt: string,
  today: string,
): { endDate: string; extraDays: number } {
  const extraDays = Math.max(0, daysBetween(frozenAt, today));
  return { endDate: addDays(endDate, extraDays), extraDays };
}

function tzOffsetMs(utcMs: number, timeZone: string): number {
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone,
    hourCycle: 'h23',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  }).formatToParts(new Date(utcMs));
  const get = (type: string) => Number(parts.find((p) => p.type === type)?.value);
  const asUtc = Date.UTC(get('year'), get('month') - 1, get('day'), get('hour'), get('minute'), get('second'));
  return asUtc - Math.floor(utcMs / 1000) * 1000;
}

/**
 * Instante UTC en que empieza el día `iso` en la zona horaria indicada.
 * Sirve para filtrar por fecha (p. ej. pagos del 20 de nov) sin errores de huso ni de cambio de hora.
 */
export function zonedDayStart(iso: string, timeZone = 'UTC'): Date {
  const guess = toMs(iso);
  const first = guess - tzOffsetMs(guess, timeZone);
  return new Date(guess - tzOffsetMs(first, timeZone));
}
