export type OrderStatus = 'PENDING' | 'PAID' | 'PREPARED' | 'DELIVERED' | 'CANCELLED';

/**
 * Cambios de estado que puede hacer el administrador a mano.
 * PENDING → PAID no está aquí a propósito: un pedido pasa a PAGADO solo cuando
 * los pagos registrados cubren el total, nunca por decisión manual.
 * Un pedido pagado no se cancela directamente: primero se anula el pago.
 */
export const ORDER_TRANSITIONS: Record<OrderStatus, readonly OrderStatus[]> = {
  PENDING: ['CANCELLED'],
  PAID: ['PREPARED'],
  PREPARED: ['DELIVERED'],
  DELIVERED: [],
  CANCELLED: [],
};

export function canTransition(from: OrderStatus, to: OrderStatus): boolean {
  return ORDER_TRANSITIONS[from].includes(to);
}
