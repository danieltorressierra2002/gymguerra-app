import { describe, expect, it } from 'vitest';
import {
  CONSENT_MAX_AGE_SECONDS,
  LEGAL_DOCUMENTS,
  acceptAll,
  canTransition,
  customConsent,
  fillPlaceholders,
  hasConsent,
  parseConsent,
  pendingDocuments,
  rejectAll,
  serializeConsent,
  slugify,
  withSuffix,
} from './index';

describe('slugify', () => {
  it('quita tildes, ñ y símbolos', () => {
    expect(slugify('Proteína Whey — 1 kg')).toBe('proteina-whey-1-kg');
    expect(slugify('  Camiseta ¡Niño! ')).toBe('camiseta-nino');
  });
  it('usa un valor por defecto si no queda nada y respeta el largo máximo', () => {
    expect(slugify('***')).toBe('producto');
    expect(slugify('a'.repeat(200), 10)).toBe('aaaaaaaaaa');
    expect(slugify('abc def', 4)).toBe('abc');
  });
  it('withSuffix resuelve colisiones', () => {
    expect(withSuffix('bebida', 1)).toBe('bebida');
    expect(withSuffix('bebida', 3)).toBe('bebida-3');
  });
});

describe('estados de pedido', () => {
  it('flujo normal: pagado → preparado → entregado', () => {
    expect(canTransition('PAID', 'PREPARED')).toBe(true);
    expect(canTransition('PREPARED', 'DELIVERED')).toBe(true);
  });
  it('solo se cancela un pedido pendiente', () => {
    expect(canTransition('PENDING', 'CANCELLED')).toBe(true);
    expect(canTransition('PAID', 'CANCELLED')).toBe(false);
    expect(canTransition('PREPARED', 'CANCELLED')).toBe(false);
  });
  it('pendiente no pasa a pagado a mano ni se salta pasos', () => {
    expect(canTransition('PENDING', 'PAID')).toBe(false);
    expect(canTransition('PAID', 'DELIVERED')).toBe(false);
  });
  it('los estados finales no cambian', () => {
    expect(canTransition('DELIVERED', 'PREPARED')).toBe(false);
    expect(canTransition('CANCELLED', 'PENDING')).toBe(false);
  });
});

describe('documentos legales', () => {
  it('sin aceptaciones, términos y privacidad están pendientes (no las condiciones de tienda)', () => {
    expect(pendingDocuments([])).toEqual(['TERMS', 'PRIVACY']);
  });
  it('aceptar la versión vigente la quita de pendientes', () => {
    const v = LEGAL_DOCUMENTS.TERMS.version;
    expect(pendingDocuments([{ documentType: 'TERMS', version: v }])).toEqual(['PRIVACY']);
  });
  it('una versión antigua vuelve a quedar pendiente', () => {
    expect(
      pendingDocuments([
        { documentType: 'TERMS', version: '0.9' },
        { documentType: 'PRIVACY', version: LEGAL_DOCUMENTS.PRIVACY.version },
      ]),
    ).toEqual(['TERMS']);
  });
});

describe('fillPlaceholders', () => {
  it('reemplaza datos y marca visiblemente los que faltan', () => {
    const r = fillPlaceholders('Titular: {{NOMBRE}} en {{CIUDAD}}. Otra vez {{NOMBRE}}.', { NOMBRE: 'Gym SA' });
    expect(r.text).toBe('Titular: Gym SA en [COMPLETAR: CIUDAD]. Otra vez Gym SA.');
    expect(r.missing).toEqual(['CIUDAD']);
  });
  it('un valor vacío o con solo espacios cuenta como faltante', () => {
    expect(fillPlaceholders('{{A}}', { A: '   ' }).missing).toEqual(['A']);
  });
  it('detecta las notas de revisión pendientes', () => {
    const r = fillPlaceholders('Plazo: [[REVISAR: según la ley local]] y [[REVISAR: edad mínima]]', {});
    expect(r.reviewNotes).toEqual(['según la ley local', 'edad mínima']);
  });
});

describe('consentimiento de cookies', () => {
  const now = new Date('2026-11-21T12:00:00Z');

  it('rechazar todo deja todo lo opcional apagado; aceptar todo lo enciende', () => {
    expect(rejectAll(now)).toMatchObject({ preferences: false, analytics: false, marketing: false });
    expect(acceptAll(now)).toMatchObject({ preferences: true, analytics: true, marketing: true });
  });

  it('lo opcional empieza apagado (sin casillas premarcadas)', () => {
    expect(customConsent({}, now)).toMatchObject({ preferences: false, analytics: false, marketing: false });
    expect(customConsent({ analytics: true }, now)).toMatchObject({ analytics: true, marketing: false });
  });

  it('serializa y vuelve a leer la misma decisión', () => {
    const state = customConsent({ analytics: true }, now);
    expect(parseConsent(serializeConsent(state), now)).toEqual(state);
  });

  it('un valor ausente, corrupto o manipulado se trata como sin decisión', () => {
    expect(parseConsent(null, now)).toBeNull();
    expect(parseConsent('%%%', now)).toBeNull();
    expect(parseConsent(encodeURIComponent('{"version":1,"analytics":"si"}'), now)).toBeNull();
    expect(parseConsent(encodeURIComponent('{"version":99,"preferences":true,"analytics":true,"marketing":true,"updatedAt":"2026-11-21T00:00:00Z"}'), now)).toBeNull();
  });

  it('caduca a los 180 días y vuelve a pedirse', () => {
    const state = acceptAll(now);
    const later = new Date(now.getTime() + (CONSENT_MAX_AGE_SECONDS - 60) * 1000);
    const expired = new Date(now.getTime() + (CONSENT_MAX_AGE_SECONDS + 60) * 1000);
    expect(parseConsent(serializeConsent(state), later)).not.toBeNull();
    expect(parseConsent(serializeConsent(state), expired)).toBeNull();
  });

  it('sin decisión no hay permiso para ninguna categoría opcional', () => {
    expect(hasConsent(null, 'analytics')).toBe(false);
    expect(hasConsent(rejectAll(now), 'analytics')).toBe(false);
    expect(hasConsent(acceptAll(now), 'analytics')).toBe(true);
  });
});
