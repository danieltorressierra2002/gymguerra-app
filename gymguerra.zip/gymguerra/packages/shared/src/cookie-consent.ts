/**
 * Estado del consentimiento de cookies (lógica pura, sin navegador).
 * - Las técnicas/necesarias no requieren consentimiento y no se guardan aquí.
 * - Todo lo opcional empieza APAGADO: no hay casillas premarcadas.
 * - El consentimiento caduca a los 180 días y vuelve a pedirse; si cambian las
 *   categorías en uso, sube CONSENT_VERSION para pedirlo de nuevo.
 */
export type OptionalCategory = 'preferences' | 'analytics' | 'marketing';

export const CONSENT_COOKIE = 'gg_consent';
export const CONSENT_VERSION = 1;
export const CONSENT_MAX_AGE_SECONDS = 180 * 24 * 60 * 60;

export interface ConsentState {
  version: number;
  preferences: boolean;
  analytics: boolean;
  marketing: boolean;
  /** ISO 8601: cuándo decidió (sirve como registro de la elección) */
  updatedAt: string;
}

export function customConsent(
  choices: Partial<Record<OptionalCategory, boolean>>,
  now: Date = new Date(),
): ConsentState {
  return {
    version: CONSENT_VERSION,
    preferences: choices.preferences === true,
    analytics: choices.analytics === true,
    marketing: choices.marketing === true,
    updatedAt: now.toISOString(),
  };
}

export const acceptAll = (now?: Date) => customConsent({ preferences: true, analytics: true, marketing: true }, now);
export const rejectAll = (now?: Date) => customConsent({}, now);

export function serializeConsent(state: ConsentState): string {
  return encodeURIComponent(JSON.stringify(state));
}

/** null = no hay decisión válida (no existe, está corrupta, es de otra versión o caducó). */
export function parseConsent(raw: string | null | undefined, now: Date = new Date()): ConsentState | null {
  if (!raw) return null;
  try {
    const v: unknown = JSON.parse(decodeURIComponent(raw));
    if (typeof v !== 'object' || v === null) return null;
    const o = v as Record<string, unknown>;
    if (o.version !== CONSENT_VERSION) return null;
    if (typeof o.preferences !== 'boolean' || typeof o.analytics !== 'boolean' || typeof o.marketing !== 'boolean') {
      return null;
    }
    if (typeof o.updatedAt !== 'string') return null;
    const at = Date.parse(o.updatedAt);
    if (Number.isNaN(at)) return null;
    if (now.getTime() - at > CONSENT_MAX_AGE_SECONDS * 1000) return null;
    return {
      version: CONSENT_VERSION,
      preferences: o.preferences,
      analytics: o.analytics,
      marketing: o.marketing,
      updatedAt: o.updatedAt,
    };
  } catch {
    return null;
  }
}

/** Sin decisión guardada, ninguna categoría opcional está permitida. */
export function hasConsent(state: ConsentState | null, category: OptionalCategory): boolean {
  return state?.[category] === true;
}
