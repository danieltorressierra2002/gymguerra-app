/** "Proteína Whey — 1 kg" → "proteina-whey-1-kg". Quita tildes (ñ → n) y símbolos. */
export function slugify(input: string, maxLength = 80, fallback = 'producto'): string {
  const base = input
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, maxLength)
    .replace(/-+$/g, '');
  return base || fallback;
}

/** n = 1 → slug; n = 2 → slug-2; ... para resolver colisiones. */
export function withSuffix(slug: string, n: number): string {
  return n <= 1 ? slug : `${slug}-${n}`;
}
