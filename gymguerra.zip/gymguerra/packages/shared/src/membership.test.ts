import { describe, expect, it } from 'vitest';
import {
  addDays,
  addMonths,
  computeEndDate,
  computeSemaforo,
  daysBetween,
  isValidIsoDate,
  nextStartDate,
  todayInTimeZone,
  unfreezeEndDate,
} from './membership';

const today = '2026-11-20';
const sem = (endDate: string, warningDays = 5) =>
  computeSemaforo({ status: 'ACTIVE', endDate, today, warningDays });

describe('computeSemaforo', () => {
  it('Al día cuando faltan más de warningDays', () => {
    expect(sem('2026-11-26')).toEqual({ state: 'OK', daysLeft: 6 });
  });

  it('Por vencer cuando faltan exactamente warningDays', () => {
    expect(sem('2026-11-25')).toEqual({ state: 'EXPIRING', daysLeft: 5 });
  });

  it('Por vencer el mismo día del vencimiento (aún no ha pasado)', () => {
    expect(sem('2026-11-20')).toEqual({ state: 'EXPIRING', daysLeft: 0 });
  });

  it('Vencido cuando la fecha ya pasó', () => {
    expect(sem('2026-11-19')).toEqual({ state: 'EXPIRED', daysLeft: -1 });
  });

  it('respeta un umbral configurable', () => {
    expect(sem('2026-11-30', 10).state).toBe('EXPIRING');
    expect(sem('2026-11-30', 9).state).toBe('OK');
    expect(sem('2026-11-21', 0).state).toBe('OK');
    expect(sem('2026-11-20', 0).state).toBe('EXPIRING');
  });

  it('cancelada tiene prioridad sobre las fechas', () => {
    expect(computeSemaforo({ status: 'CANCELLED', endDate: '2027-01-01', today })).toEqual({
      state: 'CANCELLED',
      daysLeft: null,
    });
  });

  it('pausada congela los días restantes desde que se pausó', () => {
    const r = computeSemaforo({
      status: 'FROZEN',
      endDate: '2026-12-10',
      frozenAt: '2026-11-15',
      today,
    });
    expect(r).toEqual({ state: 'FROZEN', daysLeft: 25 });
  });

  it('rechaza umbrales inválidos', () => {
    expect(() => sem('2026-11-25', -1)).toThrow(RangeError);
    expect(() => sem('2026-11-25', 1.5)).toThrow(RangeError);
  });
});

describe('fechas', () => {
  it('plan de 1 mes: empieza el 9 de nov y vence el 9 de dic (como la app original)', () => {
    expect(computeEndDate('2026-11-09', { months: 1 })).toBe('2026-12-09');
    expect(computeEndDate('2026-12-15', { months: 1 })).toBe('2027-01-15');
    expect(computeEndDate('2026-11-09', { months: 3 })).toBe('2027-02-09');
  });

  it('meses calendario: usa el último día si el mes de destino es más corto', () => {
    expect(addMonths('2026-01-31', 1)).toBe('2026-02-28');
    expect(addMonths('2028-01-31', 1)).toBe('2028-02-29'); // año bisiesto
    expect(addMonths('2026-03-31', 1)).toBe('2026-04-30');
    expect(addMonths('2026-12-31', 2)).toBe('2027-02-28');
  });

  it('addMonths cruza el fin de año y admite meses negativos', () => {
    expect(addMonths('2026-11-15', 3)).toBe('2027-02-15');
    expect(addMonths('2026-01-15', -2)).toBe('2025-11-15');
    expect(addMonths('2026-06-10', 12)).toBe('2027-06-10');
  });

  it('plan en días: 30 días desde el 9 de nov vence el 9 de dic', () => {
    expect(computeEndDate('2026-11-09', { days: 30 })).toBe('2026-12-09');
    expect(computeEndDate('2026-11-01', { days: 1 })).toBe('2026-11-02');
  });

  it('computeEndDate rechaza duraciones inválidas', () => {
    expect(() => computeEndDate('2026-11-01', { days: 0 })).toThrow(RangeError);
    expect(() => computeEndDate('2026-11-01', { months: 0 })).toThrow(RangeError);
    expect(() => computeEndDate('2026-11-01', { months: 1.5 })).toThrow(RangeError);
  });

  it('addDays y daysBetween son coherentes, incluso en años bisiestos', () => {
    expect(addDays('2028-02-28', 1)).toBe('2028-02-29');
    expect(addDays('2027-02-28', 1)).toBe('2027-03-01');
    expect(daysBetween('2026-11-20', '2026-12-20')).toBe(30);
    expect(daysBetween('2026-12-20', '2026-11-20')).toBe(-30);
  });

  it('valida fechas imposibles', () => {
    expect(isValidIsoDate('2026-02-31')).toBe(false);
    expect(isValidIsoDate('2026-13-01')).toBe(false);
    expect(isValidIsoDate('20-11-2026')).toBe(false);
    expect(isValidIsoDate('2026-11-20')).toBe(true);
    expect(() => addDays('2026-02-31', 1)).toThrow(RangeError);
  });

  it('todayInTimeZone respeta la zona horaria', () => {
    const instant = new Date('2026-11-20T02:30:00Z');
    expect(todayInTimeZone('UTC', instant)).toBe('2026-11-20');
    expect(todayInTimeZone('America/New_York', instant)).toBe('2026-11-19');
  });
});

describe('renovación y pausa', () => {
  it('renovación vigente empieza el día del vencimiento (el día de cobro no se corre)', () => {
    expect(nextStartDate('2026-11-25', today)).toBe('2026-11-25');
    expect(nextStartDate('2026-11-20', today)).toBe('2026-11-20');
  });

  it('renovación de una vencida empieza hoy', () => {
    expect(nextStartDate('2026-11-10', today)).toBe(today);
  });

  it('reanudar corre el vencimiento los días pausados', () => {
    expect(unfreezeEndDate('2026-12-10', '2026-11-15', today)).toEqual({
      endDate: '2026-12-15',
      extraDays: 5,
    });
  });

  it('reanudar el mismo día no cambia nada', () => {
    expect(unfreezeEndDate('2026-12-10', today, today)).toEqual({
      endDate: '2026-12-10',
      extraDays: 0,
    });
  });
});
