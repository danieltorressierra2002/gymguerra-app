import { describe, expect, it } from 'vitest';
import { zonedDayStart } from './membership';

describe('zonedDayStart', () => {
  it('UTC: medianoche exacta', () => {
    expect(zonedDayStart('2026-11-20', 'UTC').toISOString()).toBe('2026-11-20T00:00:00.000Z');
  });

  it('respeta el huso con horario estándar y de verano', () => {
    expect(zonedDayStart('2026-11-20', 'America/New_York').toISOString()).toBe('2026-11-20T05:00:00.000Z');
    expect(zonedDayStart('2026-07-01', 'America/New_York').toISOString()).toBe('2026-07-01T04:00:00.000Z');
  });

  it('funciona el día del cambio de hora', () => {
    // EE. UU. adelanta el reloj el 8 de marzo de 2026: ese día aún empieza en UTC-5
    expect(zonedDayStart('2026-03-08', 'America/New_York').toISOString()).toBe('2026-03-08T05:00:00.000Z');
    expect(zonedDayStart('2026-03-09', 'America/New_York').toISOString()).toBe('2026-03-09T04:00:00.000Z');
  });

  it('husos al este de UTC', () => {
    expect(zonedDayStart('2026-11-20', 'Europe/Madrid').toISOString()).toBe('2026-11-19T23:00:00.000Z');
  });
});
