/**
 * Documentos legales: versiones vigentes y utilidades para completar las plantillas.
 * Si cambias el contenido de un documento de forma relevante, SUBE su versión:
 * a cada persona se le volverá a pedir la aceptación.
 */
export type LegalDocumentType = 'TERMS' | 'PRIVACY' | 'STORE_TERMS';

export interface LegalDocumentInfo {
  version: string;
  /** AAAA-MM-DD */
  effectiveDate: string;
}

export const LEGAL_DOCUMENTS: Record<LegalDocumentType, LegalDocumentInfo> = {
  TERMS: { version: '1.0', effectiveDate: '2026-11-21' },
  PRIVACY: { version: '1.0', effectiveDate: '2026-11-21' },
  STORE_TERMS: { version: '1.0', effectiveDate: '2026-11-21' },
};

/** Se aceptan en el primer inicio de sesión. Las condiciones de la tienda, al comprar. */
export const REQUIRED_AT_LOGIN: readonly LegalDocumentType[] = ['TERMS', 'PRIVACY'];

/** Documentos de inicio de sesión cuya versión vigente aún no ha aceptado la persona. */
export function pendingDocuments(
  accepted: ReadonlyArray<{ documentType: LegalDocumentType; version: string }>,
): LegalDocumentType[] {
  return REQUIRED_AT_LOGIN.filter(
    (type) => !accepted.some((a) => a.documentType === type && a.version === LEGAL_DOCUMENTS[type].version),
  );
}

const PLACEHOLDER = /\{\{([A-Z_]+)\}\}/g;
const REVIEW_NOTE = /\[\[REVISAR:([^\]]*)\]\]/g;

export interface FilledTemplate {
  text: string;
  /** Datos sin completar, p. ej. ["DIRECCION", "PAIS"] */
  missing: string[];
  /** Notas «[[REVISAR: ...]]» que un abogado o el dueño deben resolver antes de publicar */
  reviewNotes: string[];
}

/**
 * Reemplaza {{DATO}} por su valor. Lo que falta queda visible como «[COMPLETAR: DATO]»
 * para que nunca se publique una página con huecos silenciosos.
 */
export function fillPlaceholders(template: string, values: Record<string, string | undefined>): FilledTemplate {
  const missing = new Set<string>();
  const text = template.replace(PLACEHOLDER, (_m, key: string) => {
    const value = values[key]?.trim();
    if (value) return value;
    missing.add(key);
    return `[COMPLETAR: ${key}]`;
  });
  const reviewNotes = [...template.matchAll(REVIEW_NOTE)].map((m) => (m[1] ?? '').trim());
  return { text, missing: [...missing], reviewNotes };
}
