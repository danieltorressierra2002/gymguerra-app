/** apps/web/tailwind.config.js — consume los tokens de src/styles/tokens.css */
const c = (name) => `rgb(var(--${name}) / <alpha-value>)`;

/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      colors: {
        bg: c('bg'),
        surface: c('surface'),
        card: c('card'),
        line: c('line'),
        fg: c('text'),
        muted: c('muted'),
        brand: {
          DEFAULT: c('brand'),
          hover: c('brand-hover'),
          text: c('brand-text'),
          on: c('on-brand'),
        },
        // Estados de membresía: usar siempre con icono + texto
        ok: c('ok'),
        warn: c('warn'),
        danger: c('danger'),
        info: c('info'),
      },
      fontFamily: {
        sans: ['"Inter Variable"', 'system-ui', 'sans-serif'],
        display: ['"Barlow Condensed"', 'Impact', 'sans-serif'],
      },
      fontSize: {
        // [tamaño, altura de línea]
        xs: ['0.75rem', '1.125rem'],
        sm: ['0.875rem', '1.375rem'],
        base: ['1rem', '1.625rem'],
        lg: ['1.125rem', '1.75rem'],
        xl: ['1.25rem', '1.75rem'],
        '2xl': ['1.5rem', '2rem'],
        '3xl': ['1.875rem', '2.25rem'],
        '4xl': ['2.25rem', '2.5rem'],
        // Hero fluido (móvil → escritorio)
        hero: ['clamp(2.75rem, 8vw, 5.5rem)', { lineHeight: '0.95', letterSpacing: '-0.01em' }],
      },
      borderRadius: {
        sm: 'var(--radius-sm)',
        md: 'var(--radius-md)',
        lg: 'var(--radius-lg)',
      },
      boxShadow: {
        card: 'var(--shadow-card)',
        pop: 'var(--shadow-pop)',
        brand: 'var(--glow-brand)',
      },
      transitionTimingFunction: { gym: 'var(--ease)' },
      transitionDuration: { fast: 'var(--dur-fast)', DEFAULT: 'var(--dur)' },
      keyframes: {
        'fade-in': { from: { opacity: 0 }, to: { opacity: 1 } },
        'slide-up': {
          from: { opacity: 0, transform: 'translateY(8px)' },
          to: { opacity: 1, transform: 'translateY(0)' },
        },
        shimmer: { '100%': { transform: 'translateX(100%)' } }, // skeletons
      },
      animation: {
        'fade-in': 'fade-in var(--dur) var(--ease) both',
        'slide-up': 'slide-up var(--dur) var(--ease) both',
      },
    },
  },
  plugins: [],
};
