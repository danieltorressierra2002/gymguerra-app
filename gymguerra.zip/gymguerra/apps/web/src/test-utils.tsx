import { render } from '@testing-library/react';
import type { ReactElement } from 'react';
import { MemoryRouter } from 'react-router-dom';
import { vi } from 'vitest';
import { ToastProvider } from './components/ui';
import { AuthProvider } from './lib/auth';

export interface Call {
  method: string;
  url: string;
  path: string;
  body?: any; // eslint-disable-line @typescript-eslint/no-explicit-any
  headers: Record<string, string>;
  credentials?: RequestCredentials;
}
export interface Reply { status?: number; body?: unknown }

/** Sustituye fetch por un servidor de mentira y devuelve el registro de peticiones. */
export function mockFetch(handler: (call: Call) => Reply | undefined) {
  const calls: Call[] = [];
  vi.stubGlobal(
    'fetch',
    vi.fn(async (input: RequestInfo | URL, init?: RequestInit) => {
      const url = String(input);
      const call: Call = {
        method: init?.method ?? 'GET',
        url,
        path: url.replace(/^\/api/, '').split('?')[0]!,
        body: init?.body ? JSON.parse(String(init.body)) : undefined,
        headers: (init?.headers ?? {}) as Record<string, string>,
        credentials: init?.credentials,
      };
      calls.push(call);
      const r = handler(call) ?? { status: 404, body: { error: { code: 'NOT_FOUND', message: 'No encontrado' } } };
      const status = r.status ?? 200;
      return new Response(status === 204 ? null : JSON.stringify(r.body ?? {}), {
        status,
        headers: { 'content-type': 'application/json' },
      });
    }),
  );
  return calls;
}

export const err = (status: number, code: string, message = code, details?: unknown): Reply => ({
  status,
  body: { error: { code, message, ...(details ? { details } : {}) } },
});

export function renderApp(ui: ReactElement, route = '/') {
  return render(
    <MemoryRouter initialEntries={[route]}>
      <AuthProvider>
        <ToastProvider>{ui}</ToastProvider>
      </AuthProvider>
    </MemoryRouter>,
  );
}

export const sessionOf = (user: object) => (c: Call): Reply | undefined => {
  if (c.path === '/auth/refresh') return { body: { data: { accessToken: 'tok', tokenType: 'Bearer', expiresIn: 900 } } };
  if (c.path === '/account/me') return { body: { data: user } };
  return undefined;
};
