import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../lib/api';
import { errorText } from '../lib/format';
import { Button, TextField } from '../components/ui';

/** Página a la que lleva el enlace de activación: https://…/crear-contrasena#token=… */
export function CreatePassword() {
  const [token] = useState(() => new URLSearchParams(window.location.hash.slice(1)).get('token'));
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);

  // El token sale de la barra de direcciones y del historial en cuanto se lee
  useEffect(() => {
    if (token) window.history.replaceState(null, '', window.location.pathname + window.location.search);
  }, [token]);

  const tooShort = password.length > 0 && password.length < 10;
  const mismatch = confirm.length > 0 && confirm !== password;

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!token || tooShort || mismatch) return;
    setBusy(true);
    setError(null);
    try {
      await api.request('/auth/set-password', { method: 'POST', body: { token, password }, auth: false });
      setDone(true);
    } catch (err) {
      setError(errorText(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="grid min-h-dvh place-items-center p-4">
      <main className="w-full max-w-sm rounded-lg border border-line bg-card p-6 shadow-card">
        <p className="text-center font-display text-4xl font-bold uppercase"><span className="text-brand">Gym</span>Guerra</p>
        <h1 className="mt-1 text-center font-display text-2xl font-semibold uppercase">Crea tu contraseña</h1>

        {!token ? (
          <p role="alert" className="mt-6 text-sm text-danger">
            El enlace está incompleto o ya se usó. Pide uno nuevo a la administración del gimnasio.
          </p>
        ) : done ? (
          <div className="mt-6 flex flex-col gap-4">
            <p role="status" className="text-sm">¡Listo! Tu contraseña quedó guardada. Ya puedes iniciar sesión.</p>
            <Link to="/login" className="inline-flex min-h-11 items-center justify-center rounded-md bg-brand px-4 text-sm font-semibold text-brand-on">
              Ir a iniciar sesión
            </Link>
          </div>
        ) : (
          <form onSubmit={submit} className="mt-6 flex flex-col gap-4" noValidate>
            <TextField label="Nueva contraseña" type="password" autoComplete="new-password" required value={password}
              onChange={(e) => setPassword(e.target.value)}
              hint="Mínimo 10 caracteres. Una frase larga es más segura y fácil de recordar."
              error={tooShort ? 'Debe tener al menos 10 caracteres.' : null} />
            <TextField label="Repite la contraseña" type="password" autoComplete="new-password" required value={confirm}
              onChange={(e) => setConfirm(e.target.value)} error={mismatch ? 'Las contraseñas no coinciden.' : null} />
            {error && <p role="alert" className="text-sm text-danger">{error}</p>}
            <Button type="submit" busy={busy} disabled={!password || tooShort || mismatch || !confirm}>Guardar contraseña</Button>
          </form>
        )}
      </main>
    </div>
  );
}
