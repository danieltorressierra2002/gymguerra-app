import { useState } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { LegalLinks } from '../features/legal';
import { homePathFor, useAuth } from '../lib/auth';
import { errorText } from '../lib/format';
import { Button, TextField } from '../components/ui';

export function Login() {
  const { user, login } = useAuth();
  const location = useLocation();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [help, setHelp] = useState(false);

  if (user) {
    const from = (location.state as { from?: string } | null)?.from;
    return <Navigate to={from && from !== '/login' ? from : homePathFor(user.role)} replace />;
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await login(email.trim(), password);
    } catch (err) {
      setError(errorText(err));
      setPassword('');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex min-h-dvh flex-col items-center justify-center gap-6 p-4">
      <main className="w-full max-w-sm rounded-lg border border-line bg-card p-6 shadow-card">
        <p className="text-center font-display text-4xl font-bold uppercase"><span className="text-brand">Gym</span>Guerra</p>
        <h1 className="mt-1 text-center text-sm text-muted">Inicia sesión para ver tu membresía</h1>

        <form onSubmit={submit} className="mt-6 flex flex-col gap-4" noValidate>
          <TextField label="Correo electrónico" type="email" autoComplete="username" inputMode="email" required
            value={email} onChange={(e) => setEmail(e.target.value)} />
          <TextField label="Contraseña" type="password" autoComplete="current-password" required
            value={password} onChange={(e) => setPassword(e.target.value)} />
          {error && <p role="alert" className="text-sm text-danger">{error}</p>}
          <Button type="submit" busy={busy} disabled={!email || !password}>Entrar</Button>
        </form>

        <button type="button" onClick={() => setHelp((v) => !v)} aria-expanded={help}
          className="mt-4 w-full text-center text-sm text-brand-text underline">
          ¿Olvidaste tu contraseña o es tu primera vez?
        </button>
        {help && (
          <p className="mt-2 rounded-md border border-line p-3 text-sm text-muted">
            Pide en el gimnasio un enlace nuevo para crear tu contraseña. La administración te lo entregará (por WhatsApp o en persona).
          </p>
        )}
      </main>
      <LegalLinks />
    </div>
  );
}
