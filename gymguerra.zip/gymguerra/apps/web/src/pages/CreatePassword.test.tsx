import { screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Route, Routes } from 'react-router-dom';
import { beforeEach, describe, expect, it } from 'vitest';
import { err, mockFetch, renderApp } from '../test-utils';
import { CreatePassword } from './CreatePassword';

const TOKEN = 'tok_abcdefghijklmnopqrstuvwxyz0123456789';
const page = (
  <Routes>
    <Route path="/crear-contrasena" element={<CreatePassword />} />
    <Route path="/login" element={<p>Pantalla de login</p>} />
  </Routes>
);
const open = (hash = `#token=${TOKEN}`) => window.history.replaceState(null, '', `/crear-contrasena${hash}`);
const type = async (a: string, b = a) => {
  await userEvent.type(screen.getByLabelText('Nueva contraseña'), a);
  await userEvent.type(screen.getByLabelText('Repite la contraseña'), b);
};

describe('crear contraseña con el enlace de activación', () => {
  beforeEach(() => window.history.replaceState(null, '', '/'));

  it('quita el token de la barra de direcciones en cuanto lo lee', () => {
    mockFetch(() => undefined);
    open();
    renderApp(page, '/crear-contrasena');
    expect(window.location.hash).toBe('');
    expect(screen.getByLabelText('Nueva contraseña')).toBeInTheDocument();
  });

  it('sin token explica que hay que pedir otro enlace', () => {
    mockFetch(() => undefined);
    open('');
    renderApp(page, '/crear-contrasena');
    expect(screen.getByRole('alert')).toHaveTextContent(/enlace está incompleto/i);
    expect(screen.queryByLabelText('Nueva contraseña')).not.toBeInTheDocument();
  });

  it('valida el largo y la coincidencia antes de enviar', async () => {
    const calls = mockFetch(() => undefined);
    open();
    renderApp(page, '/crear-contrasena');
    await type('corta', 'otra');
    expect(screen.getByText('Debe tener al menos 10 caracteres.')).toBeInTheDocument();
    expect(screen.getByText('Las contraseñas no coinciden.')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Guardar contraseña' })).toBeDisabled();
    expect(calls.filter((c) => c.path === '/auth/set-password')).toHaveLength(0); // no se envía nada
  });

  it('envía el token y la contraseña sin sesión y confirma', async () => {
    const calls = mockFetch((c) => (c.path === '/auth/set-password' ? { status: 204 } : undefined));
    open();
    renderApp(page, '/crear-contrasena');
    await type('la tortuga corre por la azotea');
    await userEvent.click(screen.getByRole('button', { name: 'Guardar contraseña' }));
    expect(await screen.findByText(/contraseña quedó guardada/i)).toBeInTheDocument();
    const post = calls.find((c) => c.path === '/auth/set-password');
    expect(post?.body).toEqual({ token: TOKEN, password: 'la tortuga corre por la azotea' });
    expect(post?.headers.Authorization).toBeUndefined();
    await userEvent.click(screen.getByRole('link', { name: 'Ir a iniciar sesión' }));
    expect(await screen.findByText('Pantalla de login')).toBeInTheDocument();
  });

  it('muestra por qué se rechazó una contraseña débil', async () => {
    mockFetch((c) => (c.path === '/auth/set-password' ? err(400, 'WEAK_PASSWORD', 'débil', { problems: ['Es una contraseña demasiado común.'] }) : undefined));
    open();
    renderApp(page, '/crear-contrasena');
    await type('gymguerra2026');
    await userEvent.click(screen.getByRole('button', { name: 'Guardar contraseña' }));
    expect(await screen.findByRole('alert')).toHaveTextContent('Es una contraseña demasiado común.');
  });

  it('un enlace caducado o ya usado muestra el aviso del servidor', async () => {
    mockFetch((c) => (c.path === '/auth/set-password' ? err(400, 'INVALID_OR_EXPIRED_TOKEN', 'El enlace no es válido o ya caducó. Pide uno nuevo.') : undefined));
    open();
    renderApp(page, '/crear-contrasena');
    await type('la tortuga corre por la azotea');
    await userEvent.click(screen.getByRole('button', { name: 'Guardar contraseña' }));
    expect(await screen.findByRole('alert')).toHaveTextContent(/caducó/);
  });
});
