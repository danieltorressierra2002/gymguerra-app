import { screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Route, Routes } from 'react-router-dom';
import { beforeEach, describe, expect, it } from 'vitest';
import { err, mockFetch, renderApp, type Call, type Reply } from '../../test-utils';
import { CART_KEY } from '../../lib/cart';
import { ClientStore } from './Store';

const product = (id: string, name: string, price: string, currency = 'USD') => ({
  id, name, slug: name.toLowerCase(), description: 'Rico', price, currency, imageUrl: null, category: { name: 'Suplementos', slug: 'suplementos' },
});
const A = product('a1', 'Batido', '4.50');
const B = product('b2', 'Barra', '2.00');
const CUP = product('c3', 'Camiseta', '1500', 'CUP');

const store = (extra: (c: Call) => Reply | undefined = () => undefined) => (c: Call) =>
  extra(c) ??
  (c.path === '/public/categories' ? { body: { data: [{ id: 'k1', name: 'Suplementos', slug: 'suplementos' }] } } :
   c.path === '/public/products' ? { body: { items: [A, B, CUP], total: 3, page: 1, pageSize: 24 } } :
   undefined);

const page = (
  <Routes>
    <Route path="/app/tienda" element={<ClientStore />} />
    <Route path="/app/pedidos" element={<p>Pantalla de pedidos</p>} />
  </Routes>
);
const add = (name: string) => userEvent.click(screen.getByRole('button', { name: `Agregar ${name} al carrito` }));

describe('tienda del cliente', () => {
  beforeEach(() => localStorage.clear());

  it('lista los productos con su precio y no necesita sesión para ver el catálogo', async () => {
    const calls = mockFetch(store());
    renderApp(page, '/app/tienda');
    expect(await screen.findByText('Batido')).toBeInTheDocument();
    expect(calls.filter((c) => c.path.startsWith('/public')).every((c) => !c.headers.Authorization)).toBe(true);
  });

  it('agrega al carrito, cuenta las unidades y guarda el carrito en el navegador', async () => {
    mockFetch(store());
    renderApp(page, '/app/tienda');
    await screen.findByText('Batido');
    await add('Batido');
    await add('Batido');
    expect(screen.getByRole('button', { name: /Carrito \(2\)/ })).toBeInTheDocument();
    expect(JSON.parse(localStorage.getItem(CART_KEY)!)[0]).toMatchObject({ productId: 'a1', quantity: 2 });
  });

  it('no deja mezclar monedas distintas en el mismo pedido', async () => {
    mockFetch(store());
    renderApp(page, '/app/tienda');
    await screen.findByText('Batido');
    await add('Batido');
    await add('Camiseta');
    expect(await screen.findByText(/No puedes mezclar productos de distintas monedas/)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /Carrito \(1\)/ })).toBeInTheDocument();
  });

  it('exige aceptar las condiciones y envía SOLO productos y cantidades (sin precios)', async () => {
    const calls = mockFetch(store((c) => (c.path === '/orders' && c.method === 'POST' ? { status: 201, body: { data: { orderNumber: 7 } } } : undefined)));
    renderApp(page, '/app/tienda');
    await screen.findByText('Batido');
    await add('Batido');
    await add('Barra');
    await userEvent.click(screen.getByRole('button', { name: /Carrito/ }));
    const dialog = screen.getByRole('dialog', { name: 'Tu carrito' });
    expect(dialog).toHaveTextContent(/6,50/); // 4,50 + 2,00
    const confirm = within(dialog).getByRole('button', { name: 'Hacer pedido' });
    expect(confirm).toBeDisabled();
    await userEvent.click(within(dialog).getByRole('checkbox', { name: /acepto las condiciones/i }));
    await userEvent.click(confirm);

    expect(await screen.findByText('Pantalla de pedidos')).toBeInTheDocument();
    const post = calls.find((c) => c.path === '/orders');
    expect(post?.body).toEqual({ items: [{ productId: 'a1', quantity: 1 }, { productId: 'b2', quantity: 1 }], acceptStoreTerms: true });
    expect(localStorage.getItem(CART_KEY)).toBeNull(); // el carrito se vacía
  });

  it('si un producto ya no está disponible, lo quita del carrito y lo explica', async () => {
    mockFetch(store((c) => (c.path === '/orders' && c.method === 'POST' ? err(409, 'PRODUCT_UNAVAILABLE', 'Algunos productos ya no están disponibles', { productIds: ['a1'] }) : undefined)));
    renderApp(page, '/app/tienda');
    await screen.findByText('Batido');
    await add('Batido');
    await add('Barra');
    await userEvent.click(screen.getByRole('button', { name: /Carrito/ }));
    const dialog = screen.getByRole('dialog', { name: 'Tu carrito' });
    await userEvent.click(within(dialog).getByRole('checkbox', { name: /acepto las condiciones/i }));
    await userEvent.click(within(dialog).getByRole('button', { name: 'Hacer pedido' }));

    expect(await within(dialog).findByRole('alert')).toHaveTextContent(/Batido/);
    await waitFor(() => expect(within(dialog).queryByText('Batido')).not.toBeInTheDocument());
    expect(within(dialog).getByText('Barra')).toBeInTheDocument();
    expect(JSON.parse(localStorage.getItem(CART_KEY)!)).toHaveLength(1);
  });

  it('un carrito vacío lo dice y no ofrece hacer el pedido', async () => {
    mockFetch(store());
    renderApp(page, '/app/tienda');
    await screen.findByText('Batido');
    await userEvent.click(screen.getByRole('button', { name: /Carrito/ }));
    const dialog = screen.getByRole('dialog', { name: 'Tu carrito' });
    expect(within(dialog).getByText('Tu carrito está vacío')).toBeInTheDocument();
    expect(within(dialog).queryByRole('button', { name: 'Hacer pedido' })).not.toBeInTheDocument();
  });

  it('un carrito guardado y manipulado en el navegador se descarta', async () => {
    localStorage.setItem(CART_KEY, JSON.stringify([{ productId: 'a1', name: 'Batido', price: '0.01', currency: 'USD', quantity: 9999 }]));
    mockFetch(store());
    renderApp(page, '/app/tienda');
    await screen.findByText('Batido');
    expect(screen.getByRole('button', { name: /^Carrito$/ })).toBeInTheDocument();
  });
});
