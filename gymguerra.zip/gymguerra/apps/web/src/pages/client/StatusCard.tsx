import { useState } from 'react';
import { daysBetween } from '@gymguerra/shared';
import { legalValues } from '../../features/legal';
import { Button, Card, Empty, Modal } from '../../components/ui';
import { STATE_INFO, StatusBadge } from '../../components/StatusBadge';
import { formatDate } from '../../lib/format';
import type { Membership } from '../../lib/types';

const R = 54;
const C = 2 * Math.PI * R;

/** Semáforo de la membresía: anillo con los días restantes, estado con icono y texto, y fechas. */
export function StatusCard({ membership }: { membership: Membership | null }) {
  const [how, setHow] = useState(false);

  if (!membership) {
    return (
      <Card>
        <Empty title="Aún no tienes una membresía">Acércate al gimnasio para activarla.</Empty>
      </Card>
    );
  }

  const s = membership.semaforo;
  const info = STATE_INFO[s.state];
  const total = Math.max(1, daysBetween(membership.startDate, membership.endDate));
  const days = s.daysLeft ?? 0;
  const pct = s.state === 'CANCELLED' ? 0 : Math.min(1, Math.max(0, days) / total);
  const caption =
    s.state === 'EXPIRED' ? (Math.abs(days) === 1 ? 'día de retraso' : 'días de retraso')
    : s.state === 'FROZEN' ? 'días guardados (en pausa)'
    : s.state === 'CANCELLED' ? ''
    : days === 1 ? 'día restante' : 'días restantes';
  const endLine =
    s.state === 'EXPIRED' ? `Venció el ${formatDate(membership.endDate)}`
    : s.state === 'CANCELLED' ? 'Membresía cancelada'
    : `Vence el ${formatDate(membership.endDate)}`;

  return (
    <Card className="flex flex-col gap-4">
      <div className="flex items-center gap-5">
        <div className="relative h-[132px] w-[132px] shrink-0">
          <svg viewBox="0 0 140 140" className="h-full w-full -rotate-90" role="img"
            aria-label={`${info.label}: ${s.state === 'CANCELLED' ? 'sin días' : `${Math.abs(days)} ${caption}`}`}>
            <circle cx="70" cy="70" r={R} fill="none" stroke="rgb(var(--line))" strokeWidth="12" />
            <circle cx="70" cy="70" r={R} fill="none" stroke={info.ring} strokeWidth="12" strokeLinecap="round"
              strokeDasharray={`${pct * C} ${C}`} />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className="font-display text-5xl font-bold leading-none">{s.state === 'CANCELLED' ? '—' : Math.abs(days)}</span>
            <span className="max-w-[88px] text-center text-[11px] leading-tight text-muted">{caption}</span>
          </div>
        </div>
        <div className="flex flex-col gap-2">
          <StatusBadge state={s.state} />
          <p className="font-semibold">{membership.plan.name}</p>
          <p className="text-sm text-muted">{endLine}</p>
        </div>
      </div>

      <dl className="grid grid-cols-2 gap-3 border-t border-line pt-3 text-sm">
        <div><dt className="text-xs text-muted">Inicio</dt><dd className="font-semibold">{formatDate(membership.startDate)}</dd></div>
        <div><dt className="text-xs text-muted">Vencimiento</dt><dd className="font-semibold">{formatDate(membership.endDate)}</dd></div>
      </dl>

      <Button onClick={() => setHow(true)}>Cómo renovar</Button>
      <Modal open={how} onClose={() => setHow(false)} title="Cómo renovar">
        <div className="flex flex-col gap-3 text-sm">
          <p>La renovación se hace en el gimnasio: la administración registra tu pago y tu membresía se actualiza al instante.</p>
          {legalValues.TELEFONO && <p>Teléfono: <strong>{legalValues.TELEFONO}</strong></p>}
          <Button variant="secondary" onClick={() => setHow(false)}>Entendido</Button>
        </div>
      </Modal>
    </Card>
  );
}
