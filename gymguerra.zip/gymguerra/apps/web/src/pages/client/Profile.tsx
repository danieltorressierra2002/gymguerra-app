import { useState } from 'react';
import { CookieSettingsButton } from '../../features/legal';
import { AsyncView, Button, Card, FormDialog, PageTitle, TextField, useToast } from '../../components/ui';
import { api } from '../../lib/api';
import { useAuth } from '../../lib/auth';
import { errorText, formatDate } from '../../lib/format';
import type { MemberRow } from '../../lib/types';
import { useAsync } from '../../lib/useAsync';

const nullIfEmpty = (s: string) => (s.trim() === '' ? null : s.trim());

function EditContact({ m, open, onClose, onSaved }: { m: MemberRow; open: boolean; onClose: () => void; onSaved: () => void }) {
  const [phone, setPhone] = useState(m.phone ?? '');
  const [address, setAddress] = useState(m.address ?? '');
  const [ecName, setEcName] = useState(m.emergencyContactName ?? '');
  const [ecPhone, setEcPhone] = useState(m.emergencyContactPhone ?? '');
  const [ecRel, setEcRel] = useState(m.emergencyContactRelation ?? '');
  return (
    <FormDialog open={open} onClose={onClose} title="Editar mis datos" submitLabel="Guardar"
      onSubmit={async () => {
        const emergency = nullIfEmpty(ecName) && nullIfEmpty(ecPhone)
          ? { name: ecName.trim(), phone: ecPhone.trim(), ...(nullIfEmpty(ecRel) ? { relation: ecRel.trim() } : {}) }
          : null;
        await api.patch(`/members/${m.id}`, { phone: nullIfEmpty(phone), address: nullIfEmpty(address), emergencyContact: emergency });
        onSaved();
      }}>
      <TextField label="Teléfono" type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} />
      <TextField label="Dirección" value={address} onChange={(e) => setAddress(e.target.value)} />
      <fieldset className="flex flex-col gap-3 rounded-md border border-line p-3">
        <legend className="px-1 text-sm font-semibold">Contacto de emergencia</legend>
        <TextField label="Nombre" value={ecName} onChange={(e) => setEcName(e.target.value)} />
        <TextField label="Teléfono" type="tel" value={ecPhone} onChange={(e) => setEcPhone(e.target.value)} hint="Avísale a esa persona que nos diste su contacto." />
        <TextField label="Parentesco" value={ecRel} onChange={(e) => setEcRel(e.target.value)} />
      </fieldset>
    </FormDialog>
  );
}

function ChangePassword({ open, onClose }: { open: boolean; onClose: () => void }) {
  const toast = useToast();
  const [current, setCurrent] = useState('');
  const [next, setNext] = useState('');
  const [again, setAgain] = useState('');
  const mismatch = again.length > 0 && again !== next;
  return (
    <FormDialog open={open} onClose={onClose} title="Cambiar contraseña" submitLabel="Cambiar"
      onSubmit={async () => {
        if (next !== again) throw new Error('mismatch');
        await api.post('/account/change-password', { currentPassword: current, newPassword: next });
        setCurrent(''); setNext(''); setAgain('');
        toast('Contraseña cambiada. Se cerraron tus otras sesiones.');
      }}>
      <TextField label="Contraseña actual" type="password" autoComplete="current-password" value={current} onChange={(e) => setCurrent(e.target.value)} required />
      <TextField label="Nueva contraseña" type="password" autoComplete="new-password" value={next} onChange={(e) => setNext(e.target.value)}
        hint="Mínimo 10 caracteres." required />
      <TextField label="Repite la nueva contraseña" type="password" autoComplete="new-password" value={again}
        onChange={(e) => setAgain(e.target.value)} error={mismatch ? 'Las contraseñas no coinciden.' : null} required />
    </FormDialog>
  );
}

export function ClientProfile() {
  const { user, logout } = useAuth();
  const toast = useToast();
  const state = useAsync(() => api.get<{ data: MemberRow }>('/members/me'), []);
  const [editing, setEditing] = useState(false);
  const [pwd, setPwd] = useState(false);
  const [exporting, setExporting] = useState(false);

  async function downloadData() {
    setExporting(true);
    try {
      const data = await api.get('/members/me/export');
      const url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }));
      const a = document.createElement('a');
      a.href = url;
      a.download = 'mis-datos.json';
      a.click();
      URL.revokeObjectURL(url);
    } catch (e) {
      toast(errorText(e));
    } finally {
      setExporting(false);
    }
  }

  return (
    <div className="mx-auto flex max-w-2xl flex-col gap-4">
      <PageTitle>Mi perfil</PageTitle>
      <AsyncView state={state}>
        {({ data: m }) => (
          <>
            <Card className="flex flex-col gap-3">
              <div>
                <p className="text-lg font-bold">{m.user.name}</p>
                <p className="text-sm text-muted">{m.user.email}</p>
              </div>
              <dl className="grid grid-cols-2 gap-3 text-sm">
                <div><dt className="text-xs text-muted">Documento</dt><dd>{m.documentId}</dd></div>
                <div><dt className="text-xs text-muted">Teléfono</dt><dd>{m.phone ?? '—'}</dd></div>
                <div className="col-span-2"><dt className="text-xs text-muted">Dirección</dt><dd>{m.address ?? '—'}</dd></div>
                <div><dt className="text-xs text-muted">Nacimiento</dt><dd>{m.birthDate ? formatDate(m.birthDate) : '—'}</dd></div>
                <div><dt className="text-xs text-muted">Contacto de emergencia</dt>
                  <dd>{m.emergencyContactName ? `${m.emergencyContactName} · ${m.emergencyContactPhone ?? ''}` : '—'}</dd></div>
              </dl>
              <Button variant="secondary" onClick={() => setEditing(true)}>Editar mis datos</Button>
            </Card>
            {editing && <EditContact m={m} open onClose={() => setEditing(false)} onSaved={() => { toast('Datos guardados'); state.reload(); }} />}
          </>
        )}
      </AsyncView>

      <Card className="flex flex-col gap-3">
        <h2 className="font-display text-xl font-semibold uppercase">Mi cuenta</h2>
        <Button variant="secondary" onClick={() => setPwd(true)}>Cambiar contraseña</Button>
        <Button variant="secondary" busy={exporting} onClick={() => void downloadData()}>Descargar mis datos</Button>
        <CookieSettingsButton className="self-start text-sm text-muted underline hover:text-fg" />
        <Button variant="ghost" onClick={() => void logout()}>Cerrar sesión de {user?.email}</Button>
      </Card>
      <ChangePassword open={pwd} onClose={() => setPwd(false)} />
    </div>
  );
}
