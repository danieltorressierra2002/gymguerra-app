import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { describe, expect, it } from 'vitest';
import type { Membership, SemaforoState } from '../../lib/types';
import { StatusCard } from './StatusCard';

const make = (state: SemaforoState, daysLeft: number | null, over: Partial<Membership> = {}): Membership => ({
  id: 'm1', memberId: 'x', planId: 'p', status: state === 'FROZEN' ? 'FROZEN' : state === 'CANCELLED' ? 'CANCELLED' : 'ACTIVE',
  startDate: '2026-11-09', endDate: '2026-12-09', priceSnapshot: '25.00', currency: 'USD',
  semaforo: { state, daysLeft }, plan: { id: 'p', name: 'Plan Mensual' }, ...over,
});

describe('semáforo de la membresía (panel del cliente)', () => {
  it('Al día: estado con icono y texto, días restantes y fechas', () => {
    render(<StatusCard membership={make('OK', 19)} />);
    expect(screen.getByText('Al día')).toBeInTheDocument();
    expect(screen.getAllByText('19').length).toBeGreaterThan(0);
    expect(screen.getByText('días restantes')).toBeInTheDocument();
    expect(screen.getByText('Vence el 9 de diciembre de 2026')).toBeInTheDocument();
    expect(screen.getByRole('img', { name: /Al día: 19 días restantes/ })).toBeInTheDocument();
  });

  it('Por vencer', () => {
    render(<StatusCard membership={make('EXPIRING', 3)} />);
    expect(screen.getByText('Por vencer')).toBeInTheDocument();
    expect(screen.getByRole('img', { name: /Por vencer: 3 días restantes/ })).toBeInTheDocument();
  });

  it('un solo día restante usa el singular', () => {
    render(<StatusCard membership={make('EXPIRING', 1)} />);
    expect(screen.getByText('día restante')).toBeInTheDocument();
  });

  it('Vencido: muestra los días de retraso, no un número negativo', () => {
    render(<StatusCard membership={make('EXPIRED', -4)} />);
    expect(screen.getByText('Vencido')).toBeInTheDocument();
    expect(screen.getByText('días de retraso')).toBeInTheDocument();
    expect(screen.getByText('Venció el 9 de diciembre de 2026')).toBeInTheDocument();
    expect(screen.queryByText('-4')).not.toBeInTheDocument();
  });

  it('Pausada y Cancelada', () => {
    const { unmount } = render(<StatusCard membership={make('FROZEN', 12)} />);
    expect(screen.getByText('Pausada')).toBeInTheDocument();
    unmount();
    render(<StatusCard membership={make('CANCELLED', null)} />);
    expect(screen.getByText('Cancelada')).toBeInTheDocument();
    expect(screen.getByText('Membresía cancelada')).toBeInTheDocument();
  });

  it('sin membresía invita a acercarse al gimnasio', () => {
    render(<StatusCard membership={null} />);
    expect(screen.getByText('Aún no tienes una membresía')).toBeInTheDocument();
  });

  it('«Cómo renovar» explica que se paga en el gimnasio (no hay pago en línea)', async () => {
    render(<StatusCard membership={make('EXPIRING', 3)} />);
    await userEvent.click(screen.getByRole('button', { name: 'Cómo renovar' }));
    expect(screen.getByRole('dialog', { name: 'Cómo renovar' })).toHaveTextContent(/se hace en el gimnasio/);
  });
});
