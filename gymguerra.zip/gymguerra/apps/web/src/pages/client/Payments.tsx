import { useState } from 'react';
import { AsyncView, Button, Card, Empty, PageTitle } from '../../components/ui';
import { api } from '../../lib/api';
import type { Paged, Payment } from '../../lib/types';
import { useAsync } from '../../lib/useAsync';
import { PaymentRow } from './Home';
import { ReceiptDialog } from './Receipt';

export function ClientPayments() {
  const [page, setPage] = useState(1);
  const [receipt, setReceipt] = useState<string | null>(null);
  const state = useAsync(() => api.get<Paged<Payment>>('/payments', { page, pageSize: 15 }), [page]);
  return (
    <div className="mx-auto flex max-w-2xl flex-col gap-4">
      <PageTitle>Mis pagos</PageTitle>
      <AsyncView state={state} isEmpty={(d) => d.total === 0} empty={<Empty title="Aún no tienes pagos registrados" />}>
        {(d) => (
          <Card>
            <ul className="divide-y divide-line">{d.items.map((p) => <PaymentRow key={p.id} p={p} onReceipt={setReceipt} />)}</ul>
            <div className="mt-3 flex items-center justify-between text-sm text-muted">
              <Button variant="secondary" disabled={page <= 1} onClick={() => setPage(page - 1)}>Anterior</Button>
              <span>Página {d.page} de {Math.max(1, Math.ceil(d.total / d.pageSize))}</span>
              <Button variant="secondary" disabled={page * d.pageSize >= d.total} onClick={() => setPage(page + 1)}>Siguiente</Button>
            </div>
          </Card>
        )}
      </AsyncView>
      <ReceiptDialog paymentId={receipt} onClose={() => setReceipt(null)} />
    </div>
  );
}
