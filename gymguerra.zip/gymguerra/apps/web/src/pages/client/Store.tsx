import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { AsyncView, Button, CheckField, Empty, Modal, PageTitle, SelectField, TextAreaField, TextField, useToast } from '../../components/ui';
import { Icon } from '../../components/Icon';
import { ApiError, api } from '../../lib/api';
import { MAX_QTY, addToCart, cartTotal, loadCart, saveCart, setQuantity, type CartLine } from '../../lib/cart';
import { errorText, formatMoney } from '../../lib/format';
import type { Category, Order, Paged, Product } from '../../lib/types';
import { useAsync } from '../../lib/useAsync';
import { useDebounced } from '../../lib/useDebounced';

function ProductCard({ p, onAdd }: { p: Product; onAdd: (p: Product) => void }) {
  return (
    <li className="flex flex-col overflow-hidden rounded-lg border border-line bg-card">
      <div className="grid aspect-[4/3] place-items-center bg-surface text-muted">
        {p.imageUrl
          ? <img src={p.imageUrl} alt={p.name} loading="lazy" referrerPolicy="no-referrer" className="h-full w-full object-cover" />
          : <Icon name="bag" className="h-10 w-10" />}
      </div>
      <div className="flex flex-1 flex-col gap-1 p-3">
        <p className="text-xs text-muted">{p.category.name}</p>
        <h3 className="font-semibold">{p.name}</h3>
        {p.description && <p className="line-clamp-2 text-sm text-muted">{p.description}</p>}
        <p className="mt-auto pt-2 text-lg font-bold">{formatMoney(p.price, p.currency)}</p>
        <Button onClick={() => onAdd(p)} aria-label={`Agregar ${p.name} al carrito`}>Agregar</Button>
      </div>
    </li>
  );
}

function CartDialog({
  open, onClose, lines, setLines,
}: { open: boolean; onClose: () => void; lines: CartLine[]; setLines: (l: CartLine[]) => void }) {
  const navigate = useNavigate();
  const toast = useToast();
  const [accept, setAccept] = useState(false);
  const [notes, setNotes] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { total, currency } = cartTotal(lines);

  async function placeOrder() {
    setBusy(true);
    setError(null);
    try {
      // Solo se envían productos y cantidades: el servidor calcula nombres, precios y total
      const res = await api.post<{ data: Order }>('/orders', {
        items: lines.map((l) => ({ productId: l.productId, quantity: l.quantity })),
        acceptStoreTerms: true,
        ...(notes.trim() ? { notes: notes.trim() } : {}),
      });
      setLines([]);
      setAccept(false);
      setNotes('');
      onClose();
      toast(`Pedido #${res.data.orderNumber} creado. Pasa por el gimnasio para pagarlo.`);
      navigate('/app/pedidos');
    } catch (e) {
      if (e instanceof ApiError && e.code === 'PRODUCT_UNAVAILABLE') {
        const gone = new Set((e.details as { productIds: string[] } | undefined)?.productIds ?? []);
        const names = lines.filter((l) => gone.has(l.productId)).map((l) => l.name).join(', ');
        setLines(lines.filter((l) => !gone.has(l.productId)));
        setError(`Ya no están disponibles y los quitamos del carrito: ${names}. Revisa tu pedido y vuelve a confirmar.`);
      } else {
        setError(errorText(e));
      }
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal open={open} onClose={onClose} title="Tu carrito">
      {lines.length === 0 ? (
        <Empty title="Tu carrito está vacío" />
      ) : (
        <div className="flex flex-col gap-4">
          <ul className="divide-y divide-line">
            {lines.map((l) => (
              <li key={l.productId} className="flex items-center justify-between gap-3 py-3">
                <div className="min-w-0">
                  <p className="truncate font-semibold">{l.name}</p>
                  <p className="text-xs text-muted">{formatMoney(l.price, l.currency)} c/u</p>
                </div>
                <div className="flex items-center gap-1">
                  <button type="button" aria-label={`Quitar una unidad de ${l.name}`} onClick={() => setLines(setQuantity(lines, l.productId, l.quantity - 1))}
                    className="grid h-11 w-11 place-items-center rounded-md border border-line">−</button>
                  <span aria-label={`Cantidad de ${l.name}`} className="w-8 text-center">{l.quantity}</span>
                  <button type="button" aria-label={`Agregar una unidad de ${l.name}`} disabled={l.quantity >= MAX_QTY}
                    onClick={() => setLines(setQuantity(lines, l.productId, l.quantity + 1))}
                    className="grid h-11 w-11 place-items-center rounded-md border border-line disabled:opacity-40">+</button>
                </div>
              </li>
            ))}
          </ul>
          <p className="flex justify-between border-t border-line pt-3 text-lg font-bold"><span>Total</span><span>{currency && formatMoney(total, currency)}</span></p>
          <TextAreaField label="Notas (opcional)" value={notes} maxLength={300} onChange={(e) => setNotes(e.target.value)} />
          <CheckField checked={accept} onChange={(e) => setAccept(e.target.checked)}
            label="He leído y acepto las condiciones de la tienda." />
          <Link to="/legal/tienda" target="_blank" rel="noopener noreferrer" className="-mt-2 text-sm text-brand-text underline">Leer las condiciones de la tienda</Link>
          {error && <p role="alert" className="text-sm text-danger">{error}</p>}
          <Button busy={busy} disabled={!accept} onClick={() => void placeOrder()}>Hacer pedido</Button>
          <p className="text-xs text-muted">El pago se registra en el gimnasio. El precio final lo confirma el sistema al crear el pedido.</p>
        </div>
      )}
    </Modal>
  );
}

export function ClientStore() {
  const toast = useToast();
  const [lines, setLines] = useState<CartLine[]>(() => loadCart());
  useEffect(() => saveCart(lines), [lines]);
  const [q, setQ] = useState('');
  const dq = useDebounced(q);
  const [category, setCategory] = useState('');
  const [cartOpen, setCartOpen] = useState(false);

  const cats = useAsync(() => api.request<{ data: Category[] }>('/public/categories', { auth: false }), []);
  const products = useAsync(
    () => api.request<Paged<Product>>('/public/products', { auth: false, query: { q: dq, category, pageSize: 24 } }),
    [dq, category],
  );
  const count = lines.reduce((n, l) => n + l.quantity, 0);

  function add(p: Product) {
    const r = addToCart(lines, { productId: p.id, name: p.name, price: p.price, currency: p.currency, imageUrl: p.imageUrl });
    if (r.error) return toast(r.error);
    setLines(r.lines);
    toast(`${p.name} agregado al carrito`);
  }

  return (
    <div className="mx-auto flex max-w-4xl flex-col gap-4">
      <PageTitle action={
        <div className="flex gap-2">
          <Link to="/app/pedidos"><Button variant="secondary">Mis pedidos</Button></Link>
          <Button onClick={() => setCartOpen(true)}><Icon name="bag" />Carrito{count > 0 ? ` (${count})` : ''}</Button>
        </div>
      }>Tienda</PageTitle>

      <div className="grid gap-3 sm:grid-cols-2">
        <TextField label="Buscar" type="search" value={q} onChange={(e) => setQ(e.target.value)} />
        <SelectField label="Categoría" value={category} onChange={(e) => setCategory(e.target.value)}>
          <option value="">Todas</option>
          {cats.data?.data.map((c) => <option key={c.id} value={c.slug}>{c.name}</option>)}
        </SelectField>
      </div>

      <AsyncView state={products} isEmpty={(d) => d.items.length === 0}
        empty={<Empty title="No encontramos productos">Prueba con otra búsqueda o categoría.</Empty>}>
        {(d) => <ul className="grid grid-cols-2 gap-3 lg:grid-cols-3">{d.items.map((p) => <ProductCard key={p.id} p={p} onAdd={add} />)}</ul>}
      </AsyncView>

      <CartDialog open={cartOpen} onClose={() => setCartOpen(false)} lines={lines} setLines={setLines} />
    </div>
  );
}
