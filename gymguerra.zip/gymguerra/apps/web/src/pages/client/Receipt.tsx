import { AsyncView, Button, Modal } from '../../components/ui';
import { api } from '../../lib/api';
import { METHOD_LABELS, formatDateTime, formatMoney } from '../../lib/format';
import type { Receipt } from '../../lib/types';
import { useAsync } from '../../lib/useAsync';

function ReceiptBody({ id }: { id: string }) {
  const state = useAsync(() => api.get<{ data: Receipt }>(`/payments/${id}/receipt`), [id]);
  return (
    <AsyncView state={state}>
      {({ data: r }) => (
        <div className="flex flex-col gap-3 text-sm">
          <p className="font-display text-3xl font-bold">Recibo N.º {String(r.receiptNumber).padStart(6, '0')}</p>
          <dl className="grid grid-cols-2 gap-3">
            <div><dt className="text-xs text-muted">Fecha</dt><dd>{formatDateTime(r.issuedAt)}</dd></div>
            <div><dt className="text-xs text-muted">Método</dt><dd>{METHOD_LABELS[r.method]}</dd></div>
            <div className="col-span-2"><dt className="text-xs text-muted">Cliente</dt><dd>{r.customer.name ?? '—'}{r.customer.documentId ? ` · ${r.customer.documentId}` : ''}</dd></div>
            <div className="col-span-2"><dt className="text-xs text-muted">Concepto</dt><dd>{r.concept}</dd></div>
          </dl>
          <p className="border-t border-line pt-3 text-xl font-bold">{formatMoney(r.amount, r.currency)}</p>
          <Button variant="secondary" onClick={() => window.print()}>Imprimir</Button>
        </div>
      )}
    </AsyncView>
  );
}

export function ReceiptDialog({ paymentId, onClose }: { paymentId: string | null; onClose: () => void }) {
  return (
    <Modal open={paymentId !== null} onClose={onClose} title="Recibo">
      {paymentId && <ReceiptBody id={paymentId} />}
    </Modal>
  );
}
