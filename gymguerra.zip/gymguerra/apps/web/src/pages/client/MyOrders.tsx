import { useState } from 'react';
import { Link } from 'react-router-dom';
import { AsyncView, Card, Empty, FormDialog, PageTitle, useToast } from '../../components/ui';
import { api } from '../../lib/api';
import { ORDER_LABELS, formatDate, formatMoney } from '../../lib/format';
import type { Order, Paged } from '../../lib/types';
import { useAsync } from '../../lib/useAsync';

export function OrderCard({ o, children }: { o: Order; children?: React.ReactNode }) {
  return (
    <Card className="flex flex-col gap-2">
      <div className="flex items-center justify-between gap-2">
        <p className="font-semibold">Pedido #{o.orderNumber}{o.member ? ` · ${o.member.user.name}` : ''}</p>
        <span className="rounded-full bg-line/40 px-3 py-1 text-xs font-semibold">{ORDER_LABELS[o.status]}</span>
      </div>
      <p className="text-xs text-muted">{formatDate(o.createdAt.slice(0, 10))}</p>
      <ul className="text-sm">{o.items.map((i) => <li key={i.id}>{i.quantity} × {i.nameSnapshot}</li>)}</ul>
      <p className="font-bold">{formatMoney(o.total, o.currency)}</p>
      {children}
    </Card>
  );
}

export function ClientOrders() {
  const toast = useToast();
  const state = useAsync(() => api.get<Paged<Order>>('/orders', { pageSize: 30 }), []);
  const [cancelling, setCancelling] = useState<Order | null>(null);
  return (
    <div className="mx-auto flex max-w-2xl flex-col gap-4">
      <PageTitle>Mis pedidos</PageTitle>
      <AsyncView state={state} isEmpty={(d) => d.items.length === 0}
        empty={<Empty title="Aún no has hecho pedidos"><Link to="/app/tienda" className="text-brand-text underline">Ir a la tienda</Link></Empty>}>
        {(d) => (
          <div className="flex flex-col gap-3">
            {d.items.map((o) => (
              <OrderCard key={o.id} o={o}>
                {o.status === 'PENDING' && (
                  <button type="button" onClick={() => setCancelling(o)} className="self-start text-sm text-danger underline">Cancelar pedido</button>
                )}
                {o.status === 'PENDING' && <p className="text-xs text-muted">Pásate por el gimnasio para pagarlo.</p>}
              </OrderCard>
            ))}
          </div>
        )}
      </AsyncView>
      <FormDialog open={cancelling !== null} onClose={() => setCancelling(null)} danger
        title="Cancelar pedido" submitLabel="Sí, cancelar"
        onSubmit={async () => {
          await api.post(`/orders/${cancelling!.id}/cancel`, {});
          toast('Pedido cancelado');
          state.reload();
        }}>
        <p className="text-sm">¿Cancelar el pedido #{cancelling?.orderNumber}? Solo se puede mientras esté pendiente de pago.</p>
      </FormDialog>
    </div>
  );
}
