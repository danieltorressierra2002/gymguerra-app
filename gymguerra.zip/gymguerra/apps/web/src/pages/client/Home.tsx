import { useState } from 'react';
import { Link } from 'react-router-dom';
import { AsyncView, Button, Card, Empty, PageTitle } from '../../components/ui';
import { api } from '../../lib/api';
import { useAuth } from '../../lib/auth';
import { METHOD_LABELS, formatDate, formatMoney } from '../../lib/format';
import type { Membership, Paged, Payment } from '../../lib/types';
import { useAsync } from '../../lib/useAsync';
import { ReceiptDialog } from './Receipt';
import { StatusCard } from './StatusCard';

export function PaymentRow({ p, onReceipt }: { p: Payment; onReceipt: (id: string) => void }) {
  const concept = p.membership ? `Membresía · ${p.membership.plan.name}` : p.order ? `Pedido #${p.order.orderNumber}` : 'Pago';
  return (
    <li className="flex items-center justify-between gap-3 py-3">
      <div>
        <p className="text-sm font-semibold">{concept}</p>
        <p className="text-xs text-muted">{p.paidAt ? formatDate(p.paidAt.slice(0, 10)) : 'Sin fecha'} · {METHOD_LABELS[p.method]}{p.status !== 'PAID' ? ` · ${p.status === 'VOID' ? 'Anulado' : 'Pendiente'}` : ''}</p>
      </div>
      <div className="text-right">
        <p className="font-semibold">{formatMoney(p.amount, p.currency)}</p>
        {p.status === 'PAID' && <button type="button" onClick={() => onReceipt(p.id)} className="text-xs text-brand-text underline">Recibo</button>}
      </div>
    </li>
  );
}

export function ClientHome() {
  const { user } = useAuth();
  const membership = useAsync(() => api.get<{ data: Membership | null }>('/memberships/me'), []);
  const payments = useAsync(() => api.get<Paged<Payment>>('/payments', { pageSize: 3 }), []);
  const [receipt, setReceipt] = useState<string | null>(null);

  return (
    <div className="mx-auto flex max-w-2xl flex-col gap-4">
      <PageTitle>Hola, {user?.name.split(' ')[0]}</PageTitle>
      <AsyncView state={membership}>{({ data }) => <StatusCard membership={data} />}</AsyncView>

      <Card>
        <div className="mb-1 flex items-baseline justify-between">
          <h2 className="font-display text-xl font-semibold uppercase">Pagos recientes</h2>
          <Link to="/app/pagos" className="text-sm text-brand-text underline">Ver todo</Link>
        </div>
        <AsyncView state={payments} isEmpty={(d) => d.items.length === 0} empty={<Empty title="Aún no hay pagos" />}>
          {(d) => <ul className="divide-y divide-line">{d.items.map((p) => <PaymentRow key={p.id} p={p} onReceipt={setReceipt} />)}</ul>}
        </AsyncView>
      </Card>

      <Link to="/app/tienda"><Button variant="secondary" className="w-full">Ver la tienda</Button></Link>
      <ReceiptDialog paymentId={receipt} onClose={() => setReceipt(null)} />
    </div>
  );
}
