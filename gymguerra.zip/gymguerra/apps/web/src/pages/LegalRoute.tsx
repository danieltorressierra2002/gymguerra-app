import { Link, useParams } from 'react-router-dom';
import { LegalPage, type LegalSlug } from '../features/legal';
import { LEGAL_PAGES } from '../features/legal/legal-content';

export default function LegalRoute({ notFound }: { notFound: React.ReactNode }) {
  const { slug = '' } = useParams();
  if (!(slug in LEGAL_PAGES)) return <>{notFound}</>;
  return (
    <>
      <div className="mx-auto max-w-3xl px-4 pt-6">
        <Link to="/" className="text-sm text-brand-text underline">← Volver</Link>
      </div>
      <LegalPage slug={slug as LegalSlug} />
    </>
  );
}
