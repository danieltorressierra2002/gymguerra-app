import { screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Route, Routes } from 'react-router-dom';
import { describe, expect, it } from 'vitest';
import { err, mockFetch, renderApp } from '../test-utils';
import { Login } from './Login';

const routes = (
  <Routes>
    <Route path="/login" element={<Login />} />
    <Route path="/app" element={<p>Panel del cliente</p>} />
    <Route path="/admin" element={<p>Panel del administrador</p>} />
  </Routes>
);

const anonymous = (extra?: (c: { path: string }) => ReturnType<Parameters<typeof mockFetch>[0]>) =>
  mockFetch((c) => (c.path === '/auth/refresh' ? err(401, 'INVALID_SESSION') : extra?.(c)));

async function fill(email: string, password: string) {
  await userEvent.type(screen.getByLabelText('Correo electrónico'), email);
  await userEvent.type(screen.getByLabelText('Contraseña'), password);
}

describe('pantalla de inicio de sesión', () => {
  it('el botón espera a que haya correo y contraseña', async () => {
    anonymous();
    renderApp(routes, '/login');
    expect(screen.getByRole('button', { name: 'Entrar' })).toBeDisabled();
    await fill('ana@correo.cu', 'x');
    expect(screen.getByRole('button', { name: 'Entrar' })).toBeEnabled();
  });

  it('envía solo correo y contraseña y lleva al panel según el rol', async () => {
    const calls = anonymous((c) =>
      c.path === '/auth/login' ? { body: { data: { accessToken: 't', user: { id: '1', name: 'Dueño', email: 'd@x.cu', role: 'ADMIN' } } } } : undefined);
    renderApp(routes, '/login');
    await fill('  Dueno@Correo.cu ', 'una frase larga y segura');
    await userEvent.click(screen.getByRole('button', { name: 'Entrar' }));
    expect(await screen.findByText('Panel del administrador')).toBeInTheDocument();
    const login = calls.find((c) => c.path === '/auth/login');
    expect(login?.body).toEqual({ email: 'Dueno@Correo.cu', password: 'una frase larga y segura' });
  });

  it('con credenciales incorrectas muestra el error, no avanza y vacía la contraseña', async () => {
    anonymous((c) => (c.path === '/auth/login' ? err(401, 'INVALID_CREDENTIALS', 'Correo o contraseña incorrectos, o la cuenta está bloqueada temporalmente. Inténtalo más tarde.') : undefined));
    renderApp(routes, '/login');
    await fill('ana@correo.cu', 'equivocada');
    await userEvent.click(screen.getByRole('button', { name: 'Entrar' }));
    expect(await screen.findByRole('alert')).toHaveTextContent(/incorrectos/);
    expect(screen.queryByText('Panel del cliente')).not.toBeInTheDocument();
    expect(screen.getByLabelText('Contraseña')).toHaveValue('');
  });

  it('avisa si no hay conexión con el servidor', async () => {
    anonymous((c) => (c.path === '/auth/login' ? err(0 || 503, 'ERROR', 'Servicio no disponible') : undefined));
    renderApp(routes, '/login');
    await fill('ana@correo.cu', 'clave larga de prueba');
    await userEvent.click(screen.getByRole('button', { name: 'Entrar' }));
    expect(await screen.findByRole('alert')).toHaveTextContent(/no disponible/i);
  });

  it('explica cómo conseguir un enlace nuevo (el gimnasio no envía correos)', async () => {
    anonymous();
    renderApp(routes, '/login');
    await userEvent.click(screen.getByRole('button', { name: /olvidaste tu contraseña/i }));
    expect(screen.getByText(/La administración te lo entregará/)).toBeInTheDocument();
  });

  it('si ya hay una sesión válida, salta directo al panel', async () => {
    mockFetch((c) => {
      if (c.path === '/auth/refresh') return { body: { data: { accessToken: 't' } } };
      if (c.path === '/account/me') return { body: { data: { id: '1', name: 'Ana', email: 'a@x.cu', role: 'MEMBER' } } };
      return undefined;
    });
    renderApp(routes, '/login');
    await waitFor(() => expect(screen.getByText('Panel del cliente')).toBeInTheDocument());
  });
});
