import { useState } from 'react';
import { AsyncView, Button, Card, CheckField, Empty, FormDialog, PageTitle, SelectField, TextAreaField, TextField, useToast } from '../../components/ui';
import { api } from '../../lib/api';
import { formatMoney } from '../../lib/format';
import type { Plan } from '../../lib/types';
import { useAsync } from '../../lib/useAsync';

export const durationText = (d: Plan['duration']) =>
  'months' in d ? `${d.months} ${d.months === 1 ? 'mes' : 'meses'}` : `${d.days} ${d.days === 1 ? 'día' : 'días'}`;

function PlanForm({ plan, defaultCurrency, onClose, onSaved }: { plan: Plan | null; defaultCurrency: string; onClose: () => void; onSaved: () => void }) {
  const [f, setF] = useState({
    name: plan?.name ?? '', description: plan?.description ?? '', price: plan?.price ?? '', currency: plan?.currency ?? defaultCurrency,
    kind: plan && 'days' in plan.duration ? 'days' : 'months',
    amount: plan ? String('months' in plan.duration ? plan.duration.months : plan.duration.days) : '1',
    benefits: plan?.benefits.join('\n') ?? '', includesTrainer: plan?.includesTrainer ?? false, isActive: plan?.isActive ?? true,
  });
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => setF({ ...f, [k]: e.target.value });
  return (
    <FormDialog open onClose={onClose} title={plan ? 'Editar plan' : 'Nuevo plan'} submitLabel="Guardar" wide
      onSubmit={async () => {
        const body = {
          name: f.name.trim(), description: f.description.trim() || (plan ? null : undefined),
          price: f.price.trim().replace(',', '.'), currency: f.currency.trim().toUpperCase(),
          duration: f.kind === 'months' ? { months: Number(f.amount) } : { days: Number(f.amount) },
          benefits: f.benefits.split('\n').map((b) => b.trim()).filter(Boolean),
          includesTrainer: f.includesTrainer, isActive: f.isActive,
        };
        if (plan) await api.patch(`/plans/${plan.id}`, body);
        else await api.post('/plans', body);
        onSaved();
      }}>
      <div className="grid gap-3 sm:grid-cols-2">
        <TextField label="Nombre" value={f.name} onChange={set('name')} required />
        <TextField label="Precio" inputMode="decimal" value={f.price} onChange={set('price')} required />
        <TextField label="Moneda" value={f.currency} onChange={set('currency')} required maxLength={3} hint="Código de 3 letras, p. ej. USD o CUP." />
        <div className="grid grid-cols-2 gap-3">
          <SelectField label="Dura" value={f.kind} onChange={set('kind')}>
            <option value="months">Meses</option><option value="days">Días</option>
          </SelectField>
          <TextField label="Cantidad" type="number" min={1} value={f.amount} onChange={set('amount')} required />
        </div>
      </div>
      <p className="-mt-2 text-xs text-muted">Los meses son calendario: un plan de 1 mes que empieza el 9 de noviembre vence el 9 de diciembre.</p>
      <TextField label="Descripción (opcional)" value={f.description} onChange={set('description')} />
      <TextAreaField label="Beneficios (uno por línea)" value={f.benefits} onChange={set('benefits')} />
      <div className="flex flex-wrap gap-4">
        <CheckField label="Incluye entrenador" checked={f.includesTrainer} onChange={(e) => setF({ ...f, includesTrainer: e.target.checked })} />
        <CheckField label="Disponible para la venta" checked={f.isActive} onChange={(e) => setF({ ...f, isActive: e.target.checked })} />
      </div>
      {plan && <p className="text-xs text-muted">Cambiar el precio o la duración no afecta a las membresías ya vendidas.</p>}
    </FormDialog>
  );
}

export function AdminPlans() {
  const toast = useToast();
  const state = useAsync(() => api.get<{ data: Plan[] }>('/plans', { includeInactive: true }), []);
  const [editing, setEditing] = useState<Plan | 'new' | null>(null);
  const [deleting, setDeleting] = useState<Plan | null>(null);
  const saved = () => { setEditing(null); state.reload(); toast('Plan guardado'); };
  return (
    <div className="mx-auto flex max-w-4xl flex-col gap-4">
      <PageTitle action={<Button onClick={() => setEditing('new')}><span aria-hidden="true">+</span> Nuevo plan</Button>}>Planes</PageTitle>
      <AsyncView state={state} isEmpty={(d) => d.data.length === 0} empty={<Empty title="Aún no hay planes">Crea el primero para poder vender membresías.</Empty>}>
        {(d) => (
          <ul className="grid gap-3 sm:grid-cols-2">
            {d.data.map((p) => (
              <li key={p.id}>
                <Card className="flex h-full flex-col gap-2">
                  <div className="flex items-start justify-between gap-2">
                    <h2 className="font-semibold">{p.name}</h2>
                    {!p.isActive && <span className="rounded-full bg-line/40 px-2 py-0.5 text-xs">No disponible</span>}
                  </div>
                  <p className="text-2xl font-bold">{formatMoney(p.price, p.currency)}</p>
                  <p className="text-sm text-muted">{durationText(p.duration)}{p.includesTrainer ? ' · con entrenador' : ''}</p>
                  {p.benefits.length > 0 && <ul className="list-disc pl-5 text-sm">{p.benefits.map((b) => <li key={b}>{b}</li>)}</ul>}
                  <div className="mt-auto flex gap-2 pt-2">
                    <Button variant="secondary" onClick={() => setEditing(p)}>Editar</Button>
                    <Button variant="danger" onClick={() => setDeleting(p)}>Quitar</Button>
                  </div>
                </Card>
              </li>
            ))}
          </ul>
        )}
      </AsyncView>
      {editing && <PlanForm plan={editing === 'new' ? null : editing} defaultCurrency={state.data?.data[0]?.currency ?? ''} onClose={() => setEditing(null)} onSaved={saved} />}
      {deleting && (
        <FormDialog open onClose={() => setDeleting(null)} danger title="Quitar plan" submitLabel="Quitar"
          onSubmit={async () => {
            const r = await api.del<{ data: { activeMemberships: number } }>(`/plans/${deleting.id}`);
            toast(r.data.activeMemberships > 0 ? `Plan quitado. ${r.data.activeMemberships} membresía(s) vigentes lo siguen usando.` : 'Plan quitado');
            state.reload();
          }}>
          <p className="text-sm">¿Quitar el plan «{deleting.name}»? Deja de ofrecerse, pero las membresías que ya lo usan se conservan. Para renovarlas tendrás que elegir otro plan.</p>
        </FormDialog>
      )}
    </div>
  );
}
