import { useState } from 'react';
import { AsyncView, Button, Empty, PageTitle, SelectField, useToast } from '../../components/ui';
import { api } from '../../lib/api';
import { ORDER_LABELS, errorText } from '../../lib/format';
import type { Order, OrderStatus, Paged } from '../../lib/types';
import { useAsync } from '../../lib/useAsync';
import { OrderCard } from '../client/MyOrders';
import { PaymentDialog, ReasonDialog } from './Dialogs';

export function AdminOrders() {
  const toast = useToast();
  const [status, setStatus] = useState<'' | OrderStatus>('');
  const state = useAsync(() => api.get<Paged<Order>>('/orders', { status, pageSize: 40 }), [status]);
  const [pay, setPay] = useState<Order | null>(null);
  const [cancel, setCancel] = useState<Order | null>(null);

  async function advance(o: Order, next: 'PREPARED' | 'DELIVERED') {
    try {
      await api.patch(`/orders/${o.id}/status`, { status: next });
      toast(next === 'PREPARED' ? 'Pedido marcado como preparado' : 'Pedido entregado');
      state.reload();
    } catch (e) {
      toast(errorText(e));
    }
  }

  return (
    <div className="mx-auto flex max-w-4xl flex-col gap-4">
      <PageTitle>Pedidos</PageTitle>
      <SelectField label="Estado" value={status} onChange={(e) => setStatus(e.target.value as '' | OrderStatus)}>
        <option value="">Todos</option>
        {(Object.keys(ORDER_LABELS) as OrderStatus[]).map((s) => <option key={s} value={s}>{ORDER_LABELS[s]}</option>)}
      </SelectField>
      <AsyncView state={state} isEmpty={(d) => d.items.length === 0} empty={<Empty title="No hay pedidos con ese estado" />}>
        {(d) => (
          <div className="grid gap-3 md:grid-cols-2">
            {d.items.map((o) => (
              <OrderCard key={o.id} o={o}>
                <div className="flex flex-wrap gap-2">
                  {o.status === 'PENDING' && <Button onClick={() => setPay(o)}>Registrar pago</Button>}
                  {o.status === 'PENDING' && <Button variant="danger" onClick={() => setCancel(o)}>Cancelar</Button>}
                  {o.status === 'PAID' && <Button onClick={() => void advance(o, 'PREPARED')}>Marcar preparado</Button>}
                  {o.status === 'PREPARED' && <Button onClick={() => void advance(o, 'DELIVERED')}>Marcar entregado</Button>}
                </div>
              </OrderCard>
            ))}
          </div>
        )}
      </AsyncView>
      {pay && <PaymentDialog target={{ orderId: pay.id }} defaultAmount={pay.total} currency={pay.currency} onClose={() => setPay(null)} onDone={() => { setPay(null); state.reload(); toast('Pago registrado'); }} />}
      {cancel && (
        <ReasonDialog title={`Cancelar pedido #${cancel.orderNumber}`} label="Motivo (opcional)" danger submitLabel="Cancelar pedido" onClose={() => setCancel(null)}
          onSubmit={async (reason) => { await api.post(`/orders/${cancel.id}/cancel`, reason ? { reason } : {}); toast('Pedido cancelado'); state.reload(); }} />
      )}
    </div>
  );
}
