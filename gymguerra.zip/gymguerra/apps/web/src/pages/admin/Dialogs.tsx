import { useRef, useState } from 'react';
import { CheckField, FormDialog, SelectField, TextAreaField, TextField } from '../../components/ui';
import { api } from '../../lib/api';
import { METHOD_LABELS, formatMoney, uuid } from '../../lib/format';
import type { Membership, PaymentMethod, Plan } from '../../lib/types';
import { useAsync } from '../../lib/useAsync';

const money = (s: string) => s.trim().replace(',', '.');
const METHODS = Object.entries(METHOD_LABELS) as Array<[PaymentMethod, string]>;

export function MethodSelect({ value, onChange }: { value: PaymentMethod; onChange: (m: PaymentMethod) => void }) {
  return (
    <SelectField label="Método de pago" value={value} onChange={(e) => onChange(e.target.value as PaymentMethod)}>
      {METHODS.map(([k, label]) => <option key={k} value={k}>{label}</option>)}
    </SelectField>
  );
}

/** Registrar un pago manual de una membresía o de un pedido. La clave evita cobrar dos veces si se pulsa dos veces. */
export function PaymentDialog({
  target, defaultAmount, currency, onClose, onDone,
}: {
  target: { membershipId: string } | { orderId: string };
  defaultAmount?: string; currency?: string; onClose: () => void; onDone: () => void;
}) {
  const key = useRef(uuid());
  const [amount, setAmount] = useState(defaultAmount ?? '');
  const [method, setMethod] = useState<PaymentMethod>('CASH');
  const [notes, setNotes] = useState('');
  return (
    <FormDialog open onClose={onClose} title="Registrar pago" submitLabel="Registrar"
      onSubmit={async () => {
        await api.post('/payments', { ...target, amount: money(amount), method, ...(notes.trim() ? { notes: notes.trim() } : {}), idempotencyKey: key.current });
        onDone();
      }}>
      <TextField label={`Monto${currency ? ` (${currency})` : ''}`} inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} required
        hint={defaultAmount && currency ? `Total: ${formatMoney(defaultAmount, currency)}` : undefined} />
      <MethodSelect value={method} onChange={setMethod} />
      <TextAreaField label="Notas (opcional)" value={notes} maxLength={500} onChange={(e) => setNotes(e.target.value)} />
    </FormDialog>
  );
}

/** Acción que pide un motivo (cancelar, anular un pago, pausar). */
export function ReasonDialog({
  title, label, required, submitLabel, danger, onClose, onSubmit,
}: {
  title: string; label: string; required?: boolean; submitLabel: string; danger?: boolean;
  onClose: () => void; onSubmit: (reason: string) => Promise<void>;
}) {
  const [reason, setReason] = useState('');
  return (
    <FormDialog open onClose={onClose} title={title} submitLabel={submitLabel} danger={danger} onSubmit={() => onSubmit(reason.trim())}>
      <TextAreaField label={label} value={reason} maxLength={500} required={required} minLength={required ? 3 : undefined} onChange={(e) => setReason(e.target.value)} />
    </FormDialog>
  );
}

/** Crear una membresía nueva o renovar una existente, con el pago opcional en la misma operación. */
export function MembershipDialog({
  mode, memberId, membership, onClose, onDone,
}: { mode: 'create' | 'renew'; memberId: string; membership?: Membership; onClose: () => void; onDone: () => void }) {
  const plans = useAsync(() => api.get<{ data: Plan[] }>('/plans'), []);
  const [planId, setPlanId] = useState(membership?.planId ?? '');
  const [startDate, setStartDate] = useState('');
  const [pay, setPay] = useState(true);
  const [method, setMethod] = useState<PaymentMethod>('CASH');
  const [amount, setAmount] = useState('');
  const key = useRef(uuid());
  const chosen = plans.data?.data.find((p) => p.id === planId);

  return (
    <FormDialog open onClose={onClose} title={mode === 'create' ? 'Nueva membresía' : 'Renovar membresía'} submitLabel={mode === 'create' ? 'Crear' : 'Renovar'}
      onSubmit={async () => {
        const payment = pay ? { method, ...(amount.trim() ? { amount: money(amount) } : {}), idempotencyKey: key.current } : undefined;
        const body = { ...(planId ? { planId } : {}), ...(startDate ? { startDate } : {}), ...(payment ? { payment } : {}) };
        if (mode === 'create') await api.post('/memberships', { memberId, ...body });
        else await api.post(`/memberships/${membership!.id}/renew`, body);
        onDone();
      }}>
      <SelectField label="Plan" value={planId} onChange={(e) => setPlanId(e.target.value)} required={mode === 'create'}>
        {mode === 'create' && <option value="">Elige un plan…</option>}
        {plans.data?.data.map((p) => <option key={p.id} value={p.id}>{p.name} · {formatMoney(p.price, p.currency)}</option>)}
      </SelectField>
      <TextField label="Fecha de inicio (opcional)" type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)}
        hint={mode === 'renew' ? 'Si la dejas vacía, empieza cuando vence la actual (o hoy si ya venció).' : 'Si la dejas vacía, empieza hoy.'} />
      <CheckField label="Registrar el pago ahora" checked={pay} onChange={(e) => setPay(e.target.checked)} />
      {pay && (
        <>
          <MethodSelect value={method} onChange={setMethod} />
          <TextField label="Monto (opcional)" inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)}
            hint={chosen ? `Si lo dejas vacío se cobra el precio del plan: ${formatMoney(chosen.price, chosen.currency)}` : 'Si lo dejas vacío se cobra el precio del plan.'} />
        </>
      )}
    </FormDialog>
  );
}
