import { screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { describe, expect, it } from 'vitest';
import { err, mockFetch, renderApp } from '../../test-utils';
import { MembersPage } from './Members';

const row = (id: string, name: string, membership: object | null) => ({
  id, documentId: `DOC-${id}`, phone: null, address: null, birthDate: null, emergencyContactName: null, emergencyContactPhone: null,
  emergencyContactRelation: null, photoUrl: null, user: { name, email: `${id}@x.cu`, status: 'ACTIVE' }, currentMembership: membership,
});
const list = {
  items: [
    row('m1', 'Luis Pérez', { id: 'ms1', plan: 'Mensual', status: 'ACTIVE', startDate: '2026-11-09', endDate: '2026-12-09', semaforo: { state: 'EXPIRING', daysLeft: 3 } }),
    row('m2', 'Ana Gómez', null),
  ],
  total: 2, page: 1, pageSize: 20,
};
const LINK = 'https://gym.test/crear-contrasena#token=ABC123';

describe('lista de miembros', () => {
  it('muestra cada cliente con su estado (y «Sin membresía» cuando no tiene)', async () => {
    mockFetch((c) => (c.path === '/members' ? { body: list } : undefined));
    renderApp(<MembersPage base="/admin" />, '/admin/miembros');
    expect((await screen.findAllByText('Luis Pérez')).length).toBeGreaterThan(0);
    expect(screen.getAllByText('Por vencer').length).toBeGreaterThan(0);
    expect(screen.getAllByText('Sin membresía').length).toBeGreaterThan(0);
    expect(screen.getAllByRole('link', { name: /Luis Pérez/ })[0]).toHaveAttribute('href', '/admin/miembros/m1');
  });

  it('busca mientras se escribe, esperando un momento entre teclas', async () => {
    const calls = mockFetch((c) => (c.path === '/members' ? { body: list } : undefined));
    renderApp(<MembersPage base="/admin" />, '/admin/miembros');
    await screen.findAllByText('Luis Pérez');
    await userEvent.type(screen.getByLabelText(/Buscar por nombre/), 'luis');
    await waitFor(() => expect(calls.some((c) => c.url.includes('q=luis'))).toBe(true));
    expect(calls.filter((c) => c.path === '/members' && c.url.includes('q=')).length).toBeLessThanOrEqual(2); // no una por tecla
  });

  it('sin resultados lo dice, y sin miembros invita a crear el primero', async () => {
    mockFetch((c) => (c.path === '/members' ? { body: { items: [], total: 0, page: 1, pageSize: 20 } } : undefined));
    const { unmount } = renderApp(<MembersPage base="/admin" />, '/admin/miembros');
    expect(await screen.findByText('Aún no hay miembros')).toBeInTheDocument();
    unmount();
    mockFetch((c) => (c.path === '/members' ? { body: { items: [], total: 0, page: 1, pageSize: 20 } } : undefined));
    renderApp(<MembersPage base="/admin" />, '/admin/miembros');
    await userEvent.type(await screen.findByLabelText(/Buscar por nombre/), 'zzz');
    expect(await screen.findByText('No hay resultados')).toBeInTheDocument();
  });

  it('un error de la API se muestra con opción de reintentar', async () => {
    mockFetch((c) => (c.path === '/members' ? err(500, 'INTERNAL_ERROR', 'Ocurrió un error inesperado') : undefined));
    renderApp(<MembersPage base="/admin" />, '/admin/miembros');
    expect(await screen.findByRole('alert')).toHaveTextContent(/error inesperado/i);
    expect(screen.getByRole('button', { name: 'Reintentar' })).toBeInTheDocument();
  });

  it('el entrenador solo consulta: no hay botón para crear', async () => {
    mockFetch((c) => (c.path === '/members' ? { body: list } : undefined));
    renderApp(<MembersPage base="/entrenador" readOnly />, '/entrenador/miembros');
    await screen.findAllByText('Luis Pérez');
    expect(screen.getByRole('heading', { name: 'Mis clientes' })).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: /Nuevo miembro/ })).not.toBeInTheDocument();
  });
});

describe('crear un miembro', () => {
  const fillForm = async (dialog: HTMLElement) => {
    await userEvent.type(within(dialog).getByLabelText('Nombre completo'), 'Pedro Ruiz');
    await userEvent.type(within(dialog).getByLabelText('Documento de identidad'), '90010112345');
    await userEvent.type(within(dialog).getByLabelText('Correo electrónico'), 'pedro@x.cu');
  };

  it('crea la cuenta sin contraseña y entrega al administrador el enlace para compartirlo', async () => {
    const user = userEvent.setup();
    const calls = mockFetch((c) => {
      if (c.path === '/members' && c.method === 'POST') return { status: 201, body: { data: { setupLink: LINK, invitationSent: false } } };
      if (c.path === '/members') return { body: list };
      return undefined;
    });
    renderApp(<MembersPage base="/admin" />, '/admin/miembros');
    await screen.findAllByText('Luis Pérez');
    await user.click(screen.getByRole('button', { name: /Nuevo miembro/ }));
    const dialog = screen.getByRole('dialog', { name: 'Nuevo miembro' });
    await fillForm(dialog);
    await user.click(within(dialog).getByRole('button', { name: 'Crear miembro' }));

    const linkDialog = await screen.findByRole('dialog', { name: 'Enlace de activación' });
    expect(within(linkDialog).getByDisplayValue(LINK)).toBeInTheDocument();
    expect(linkDialog).toHaveTextContent(/Entrégalo solo a esa persona/);

    const post = calls.find((c) => c.method === 'POST' && c.path === '/members');
    expect(post?.body).toEqual({ name: 'Pedro Ruiz', email: 'pedro@x.cu', documentId: '90010112345' }); // sin contraseña ni campos vacíos
    expect(calls.filter((c) => c.path === '/members' && c.method === 'GET').length).toBeGreaterThanOrEqual(2); // recargó la lista

    await user.click(within(linkDialog).getByRole('button', { name: 'Copiar enlace' }));
    expect(await navigator.clipboard.readText()).toBe(LINK);
    const wa = within(linkDialog).getByRole('link', { name: /WhatsApp/ });
    expect(wa.getAttribute('href')).toMatch(/^https:\/\/wa\.me\/\?text=/);
    expect(decodeURIComponent(wa.getAttribute('href')!)).toContain(LINK);
    expect(wa).toHaveAttribute('rel', expect.stringContaining('noopener'));
  });

  it('muestra el error del servidor (p. ej. correo repetido) sin cerrar el formulario', async () => {
    mockFetch((c) => {
      if (c.path === '/members' && c.method === 'POST') return err(409, 'EMAIL_TAKEN', 'Ya existe una cuenta con ese correo');
      if (c.path === '/members') return { body: list };
      return undefined;
    });
    renderApp(<MembersPage base="/admin" />, '/admin/miembros');
    await screen.findAllByText('Luis Pérez');
    await userEvent.click(screen.getByRole('button', { name: /Nuevo miembro/ }));
    const dialog = screen.getByRole('dialog', { name: 'Nuevo miembro' });
    await fillForm(dialog);
    await userEvent.click(within(dialog).getByRole('button', { name: 'Crear miembro' }));
    expect(await within(dialog).findByRole('alert')).toHaveTextContent('Ya existe una cuenta con ese correo');
    expect(screen.queryByRole('dialog', { name: 'Enlace de activación' })).not.toBeInTheDocument();
  });

  it('abre el formulario directamente con ?nuevo=1 (acceso rápido del resumen)', async () => {
    mockFetch((c) => (c.path === '/members' ? { body: list } : undefined));
    renderApp(<MembersPage base="/admin" />, '/admin/miembros?nuevo=1');
    expect(await screen.findByRole('dialog', { name: 'Nuevo miembro' })).toBeInTheDocument();
  });
});
