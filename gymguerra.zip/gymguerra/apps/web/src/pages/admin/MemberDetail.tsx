import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { AsyncView, Button, Card, Empty, FormDialog, PageTitle, TextAreaField, TextField, useToast } from '../../components/ui';
import { StatusBadge } from '../../components/StatusBadge';
import { api } from '../../lib/api';
import { useAuth } from '../../lib/auth';
import { METHOD_LABELS, formatDate, formatMoney } from '../../lib/format';
import type { MemberRow, Membership, Paged, Payment } from '../../lib/types';
import { useAsync } from '../../lib/useAsync';
import { ReceiptDialog } from '../client/Receipt';
import { MembershipDialog, PaymentDialog, ReasonDialog } from './Dialogs';
import { SetupLinkDialog } from './SetupLinkDialog';

type Dlg =
  | { t: 'create' } | { t: 'renew'; m: Membership } | { t: 'pay'; m: Membership } | { t: 'freeze'; m: Membership }
  | { t: 'cancel'; m: Membership } | { t: 'void'; p: Payment } | { t: 'edit' } | { t: 'delete' }
  | { t: 'link'; link: string | null; sent: boolean };

const nul = (s: string) => (s.trim() === '' ? null : s.trim());

function EditMember({ m, onClose, onDone }: { m: MemberRow; onClose: () => void; onDone: () => void }) {
  const [f, setF] = useState({ name: m.user.name, documentId: m.documentId, phone: m.phone ?? '', address: m.address ?? '', notes: m.notes ?? '' });
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => setF({ ...f, [k]: e.target.value });
  return (
    <FormDialog open onClose={onClose} title="Editar miembro" submitLabel="Guardar"
      onSubmit={async () => {
        await api.patch(`/members/${m.id}`, { name: f.name.trim(), documentId: f.documentId.trim(), phone: nul(f.phone), address: nul(f.address), notes: nul(f.notes) });
        onDone();
      }}>
      <TextField label="Nombre completo" value={f.name} onChange={set('name')} required />
      <TextField label="Documento de identidad" value={f.documentId} onChange={set('documentId')} required />
      <TextField label="Teléfono" type="tel" value={f.phone} onChange={set('phone')} />
      <TextField label="Dirección" value={f.address} onChange={set('address')} />
      <TextAreaField label="Notas internas (el cliente no las ve en su perfil)" value={f.notes} onChange={set('notes')} />
    </FormDialog>
  );
}

export function MemberDetailPage({ base }: { base: '/admin' | '/entrenador' }) {
  const { id = '' } = useParams();
  const { user } = useAuth();
  const admin = user?.role === 'ADMIN';
  const navigate = useNavigate();
  const toast = useToast();
  const [params, setParams] = useSearchParams();
  const [dlg, setDlg] = useState<Dlg | null>(null);
  const [receipt, setReceipt] = useState<string | null>(null);

  const member = useAsync(() => api.get<{ data: MemberRow }>(`/members/${id}`), [id]);
  const memberships = useAsync(() => api.get<Paged<Membership>>('/memberships', { memberId: id, sort: 'startDate', dir: 'desc', pageSize: 50 }), [id]);
  const payments = useAsync(
    () => (admin ? api.get<Paged<Payment>>('/payments', { memberId: id, pageSize: 50 }) : Promise.resolve<Paged<Payment>>({ items: [], total: 0, page: 1, pageSize: 1 })),
    [id, admin],
  );
  const reloadAll = () => { member.reload(); memberships.reload(); payments.reload(); };
  const done = (msg: string) => () => { setDlg(null); reloadAll(); toast(msg); };

  // «Renovar» desde el resumen abre directamente el diálogo
  const renewId = params.get('renovar');
  useEffect(() => {
    if (!admin || !renewId || !memberships.data) return;
    const m = memberships.data.items.find((x) => x.id === renewId);
    if (m) setDlg({ t: 'renew', m });
    setParams({}, { replace: true });
  }, [admin, renewId, memberships.data, setParams]);

  async function invite() {
    try {
      const r = await api.post<{ data: { setupLink: string | null; sent: boolean } }>(`/members/${id}/invite`);
      setDlg({ t: 'link', link: r.data.setupLink, sent: r.data.sent });
    } catch {
      setDlg({ t: 'link', link: null, sent: false });
    }
  }

  return (
    <div className="mx-auto flex max-w-3xl flex-col gap-4">
      <Link to={`${base}/miembros`} className="text-sm text-brand-text underline">← Volver a la lista</Link>
      <AsyncView state={member}>
        {({ data: m }) => (
          <>
            <PageTitle action={m.currentMembership ? <StatusBadge state={m.currentMembership.semaforo.state} /> : undefined}>{m.user.name}</PageTitle>
            <Card className="flex flex-col gap-3">
              <dl className="grid grid-cols-2 gap-3 text-sm">
                <div><dt className="text-xs text-muted">Correo</dt><dd className="break-all">{m.user.email}</dd></div>
                <div><dt className="text-xs text-muted">Documento</dt><dd>{m.documentId}</dd></div>
                <div><dt className="text-xs text-muted">Teléfono</dt><dd>{m.phone ?? '—'}</dd></div>
                <div><dt className="text-xs text-muted">Dirección</dt><dd>{m.address ?? '—'}</dd></div>
                <div className="col-span-2"><dt className="text-xs text-muted">Contacto de emergencia</dt>
                  <dd>{m.emergencyContactName ? `${m.emergencyContactName} · ${m.emergencyContactPhone ?? ''}${m.emergencyContactRelation ? ` (${m.emergencyContactRelation})` : ''}` : '—'}</dd></div>
                {admin && m.notes && <div className="col-span-2"><dt className="text-xs text-muted">Notas internas</dt><dd>{m.notes}</dd></div>}
              </dl>
              {admin && (
                <div className="flex flex-wrap gap-2">
                  <Button variant="secondary" onClick={() => setDlg({ t: 'edit' })}>Editar</Button>
                  <Button variant="secondary" onClick={() => void invite()}>Enlace de activación</Button>
                  <Button variant="danger" onClick={() => setDlg({ t: 'delete' })}>Dar de baja</Button>
                </div>
              )}
            </Card>

            {dlg?.t === 'edit' && <EditMember m={m} onClose={() => setDlg(null)} onDone={done('Datos guardados')} />}
            {dlg?.t === 'delete' && (
              <FormDialog open onClose={() => setDlg(null)} danger title="Dar de baja" submitLabel="Dar de baja"
                onSubmit={async () => { await api.del(`/members/${id}`); toast('Cliente dado de baja'); navigate(`${base}/miembros`); }}>
                <p className="text-sm">¿Dar de baja a {m.user.name}? Se conserva su historial de pagos y pedidos. No se puede si tiene una membresía vigente: cancélala primero.</p>
              </FormDialog>
            )}
          </>
        )}
      </AsyncView>

      <Card>
        <div className="mb-2 flex items-center justify-between gap-2">
          <h2 className="font-display text-xl font-semibold uppercase">Membresías</h2>
          {admin && <Button onClick={() => setDlg({ t: 'create' })}><span aria-hidden="true">+</span> Nueva</Button>}
        </div>
        <AsyncView state={memberships} isEmpty={(d) => d.items.length === 0} empty={<Empty title="Sin membresías todavía" />}>
          {(d) => (
            <ul className="divide-y divide-line">
              {d.items.map((m) => (
                <li key={m.id} className="flex flex-col gap-2 py-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <p className="font-semibold">{m.plan.name}</p>
                    <StatusBadge state={m.semaforo.state} />
                  </div>
                  <p className="text-sm text-muted">{formatDate(m.startDate)} → {formatDate(m.endDate)} · {formatMoney(m.priceSnapshot, m.currency)}</p>
                  {admin && m.status !== 'CANCELLED' && (
                    <div className="flex flex-wrap gap-2">
                      {m.status === 'ACTIVE' && <Button variant="secondary" onClick={() => setDlg({ t: 'renew', m })}>Renovar</Button>}
                      <Button variant="secondary" onClick={() => setDlg({ t: 'pay', m })}>Registrar pago</Button>
                      {m.status === 'ACTIVE' && m.semaforo.state !== 'EXPIRED' && <Button variant="secondary" onClick={() => setDlg({ t: 'freeze', m })}>Pausar</Button>}
                      {m.status === 'FROZEN' && (
                        <Button variant="secondary" onClick={async () => { await api.post(`/memberships/${m.id}/unfreeze`, {}); done('Membresía reanudada')(); }}>Reanudar</Button>
                      )}
                      <Button variant="danger" onClick={() => setDlg({ t: 'cancel', m })}>Cancelar</Button>
                    </div>
                  )}
                </li>
              ))}
            </ul>
          )}
        </AsyncView>
      </Card>

      {admin && (
        <Card>
          <h2 className="mb-2 font-display text-xl font-semibold uppercase">Pagos</h2>
          <AsyncView state={payments} isEmpty={(d) => d.items.length === 0} empty={<Empty title="Sin pagos registrados" />}>
            {(d) => (
              <ul className="divide-y divide-line">
                {d.items.map((p) => (
                  <li key={p.id} className="flex items-center justify-between gap-3 py-3 text-sm">
                    <div>
                      <p className="font-semibold">{formatMoney(p.amount, p.currency)}{p.status === 'VOID' ? ' · Anulado' : ''}</p>
                      <p className="text-xs text-muted">{p.paidAt ? formatDate(p.paidAt.slice(0, 10)) : '—'} · {METHOD_LABELS[p.method]} · {p.membership?.plan.name ?? (p.order ? `Pedido #${p.order.orderNumber}` : '')}</p>
                    </div>
                    {p.status === 'PAID' && (
                      <div className="flex gap-3">
                        <button type="button" className="text-brand-text underline" onClick={() => setReceipt(p.id)}>Recibo</button>
                        <button type="button" className="text-danger underline" onClick={() => setDlg({ t: 'void', p })}>Anular</button>
                      </div>
                    )}
                  </li>
                ))}
              </ul>
            )}
          </AsyncView>
        </Card>
      )}

      {dlg?.t === 'create' && <MembershipDialog mode="create" memberId={id} onClose={() => setDlg(null)} onDone={done('Membresía creada')} />}
      {dlg?.t === 'renew' && <MembershipDialog mode="renew" memberId={id} membership={dlg.m} onClose={() => setDlg(null)} onDone={done('Membresía renovada')} />}
      {dlg?.t === 'pay' && <PaymentDialog target={{ membershipId: dlg.m.id }} defaultAmount={dlg.m.priceSnapshot} currency={dlg.m.currency} onClose={() => setDlg(null)} onDone={done('Pago registrado')} />}
      {dlg?.t === 'freeze' && (
        <ReasonDialog title="Pausar membresía" label="Motivo (opcional)" submitLabel="Pausar" onClose={() => setDlg(null)}
          onSubmit={async (reason) => { await api.post(`/memberships/${dlg.m.id}/freeze`, reason ? { reason } : {}); done('Membresía pausada')(); }} />
      )}
      {dlg?.t === 'cancel' && (
        <ReasonDialog title="Cancelar membresía" label="Motivo de la cancelación" required danger submitLabel="Cancelar membresía" onClose={() => setDlg(null)}
          onSubmit={async (reason) => { await api.post(`/memberships/${dlg.m.id}/cancel`, { reason }); done('Membresía cancelada')(); }} />
      )}
      {dlg?.t === 'void' && (
        <ReasonDialog title="Anular pago" label="Motivo de la anulación" required danger submitLabel="Anular pago" onClose={() => setDlg(null)}
          onSubmit={async (reason) => { await api.post(`/payments/${dlg.p.id}/void`, { reason }); done('Pago anulado')(); }} />
      )}
      {dlg?.t === 'link' && <SetupLinkDialog name={member.data?.data.user.name ?? ''} link={dlg.link} sent={dlg.sent} onClose={() => setDlg(null)} />}
      <ReceiptDialog paymentId={receipt} onClose={() => setReceipt(null)} />
    </div>
  );
}
