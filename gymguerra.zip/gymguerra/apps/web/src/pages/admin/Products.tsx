import { useState } from 'react';
import { Icon } from '../../components/Icon';
import { AsyncView, Button, Card, CheckField, Empty, FormDialog, Modal, PageTitle, SelectField, TextAreaField, TextField, useToast } from '../../components/ui';
import { api } from '../../lib/api';
import { errorText, formatMoney } from '../../lib/format';
import type { Category, Paged, Product } from '../../lib/types';
import { useAsync } from '../../lib/useAsync';
import { useDebounced } from '../../lib/useDebounced';

function ProductForm({ product, categories, defaultCurrency, onClose, onSaved }: {
  product: Product | null; categories: Category[]; defaultCurrency: string; onClose: () => void; onSaved: () => void;
}) {
  const [f, setF] = useState({
    categoryId: product?.categoryId ?? product?.category.id ?? '', name: product?.name ?? '', description: product?.description ?? '',
    price: product?.price ?? '', currency: product?.currency ?? defaultCurrency, imageUrl: product?.imageUrl ?? '', sku: product?.sku ?? '',
    isActive: product?.isActive ?? true,
  });
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => setF({ ...f, [k]: e.target.value });
  const nul = (s: string) => (s.trim() === '' ? null : s.trim());
  return (
    <FormDialog open onClose={onClose} title={product ? 'Editar producto' : 'Nuevo producto'} submitLabel="Guardar" wide
      onSubmit={async () => {
        const body = {
          categoryId: f.categoryId, name: f.name.trim(), price: f.price.trim().replace(',', '.'), currency: f.currency.trim().toUpperCase(),
          isActive: f.isActive,
          ...(product
            ? { description: nul(f.description), imageUrl: nul(f.imageUrl), sku: nul(f.sku) }
            : { ...(nul(f.description) ? { description: nul(f.description) } : {}), ...(nul(f.imageUrl) ? { imageUrl: nul(f.imageUrl) } : {}), ...(nul(f.sku) ? { sku: nul(f.sku) } : {}) }),
        };
        if (product) await api.patch(`/products/${product.id}`, body);
        else await api.post('/products', body);
        onSaved();
      }}>
      <div className="grid gap-3 sm:grid-cols-2">
        <TextField label="Nombre" value={f.name} onChange={set('name')} required />
        <SelectField label="Categoría" value={f.categoryId} onChange={set('categoryId')} required>
          <option value="">Elige una categoría…</option>
          {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
        </SelectField>
        <TextField label="Precio" inputMode="decimal" value={f.price} onChange={set('price')} required />
        <TextField label="Moneda" value={f.currency} onChange={set('currency')} required maxLength={3} hint="Código de 3 letras, p. ej. USD o CUP." />
        <TextField label="Código interno (opcional)" value={f.sku} onChange={set('sku')} />
        <TextField label="Imagen (dirección https)" type="url" value={f.imageUrl} onChange={set('imageUrl')} hint="Por ahora pega la dirección de la imagen. Pronto podrás subirla." />
      </div>
      <TextAreaField label="Descripción (opcional)" value={f.description} onChange={set('description')} />
      <CheckField label="Visible en la tienda" checked={f.isActive} onChange={(e) => setF({ ...f, isActive: e.target.checked })} />
      {product && <p className="text-xs text-muted">Cambiar el precio no afecta a los pedidos ya hechos.</p>}
    </FormDialog>
  );
}

function CategoriesDialog({ onClose, onChanged }: { onClose: () => void; onChanged: () => void }) {
  const toast = useToast();
  const state = useAsync(() => api.get<{ data: Category[] }>('/categories'), []);
  const [name, setName] = useState('');
  const [error, setError] = useState<string | null>(null);
  async function run(fn: () => Promise<unknown>, ok: string) {
    setError(null);
    try { await fn(); toast(ok); state.reload(); onChanged(); } catch (e) { setError(errorText(e)); }
  }
  return (
    <Modal open onClose={onClose} title="Categorías">
      <form className="mb-4 flex items-end gap-2" onSubmit={(e) => { e.preventDefault(); void run(() => api.post('/categories', { name: name.trim() }), 'Categoría creada').then(() => setName('')); }}>
        <div className="flex-1"><TextField label="Nueva categoría" value={name} onChange={(e) => setName(e.target.value)} required minLength={2} /></div>
        <Button type="submit">Agregar</Button>
      </form>
      {error && <p role="alert" className="mb-3 text-sm text-danger">{error}</p>}
      <AsyncView state={state} isEmpty={(d) => d.data.length === 0} empty={<Empty title="Aún no hay categorías" />}>
        {(d) => (
          <ul className="divide-y divide-line">
            {d.data.map((c) => (
              <li key={c.id} className="flex items-center justify-between py-2">
                <span>{c.name}</span>
                <button type="button" aria-label={`Eliminar la categoría ${c.name}`} className="grid h-11 w-11 place-items-center text-danger"
                  onClick={() => void run(() => api.del(`/categories/${c.id}`), 'Categoría eliminada')}><Icon name="trash" /></button>
              </li>
            ))}
          </ul>
        )}
      </AsyncView>
    </Modal>
  );
}

export function AdminProducts() {
  const toast = useToast();
  const [q, setQ] = useState('');
  const dq = useDebounced(q);
  const [categoryId, setCategoryId] = useState('');
  const [editing, setEditing] = useState<Product | 'new' | null>(null);
  const [removing, setRemoving] = useState<Product | null>(null);
  const [cats, setCats] = useState(false);
  const categories = useAsync(() => api.get<{ data: Category[] }>('/categories'), []);
  const state = useAsync(() => api.get<Paged<Product>>('/products', { q: dq, categoryId, pageSize: 50 }), [dq, categoryId]);
  const saved = () => { setEditing(null); state.reload(); toast('Producto guardado'); };

  return (
    <div className="mx-auto flex max-w-5xl flex-col gap-4">
      <PageTitle action={
        <div className="flex gap-2">
          <Button variant="secondary" onClick={() => setCats(true)}>Categorías</Button>
          <Button onClick={() => setEditing('new')} disabled={!categories.data?.data.length}><span aria-hidden="true">+</span> Nuevo producto</Button>
        </div>
      }>Productos</PageTitle>
      {categories.data && categories.data.data.length === 0 && <p className="text-sm text-muted">Crea primero una categoría para poder agregar productos.</p>}
      <div className="grid gap-3 sm:grid-cols-2">
        <TextField label="Buscar" type="search" value={q} onChange={(e) => setQ(e.target.value)} />
        <SelectField label="Categoría" value={categoryId} onChange={(e) => setCategoryId(e.target.value)}>
          <option value="">Todas</option>
          {categories.data?.data.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
        </SelectField>
      </div>
      <AsyncView state={state} isEmpty={(d) => d.items.length === 0} empty={<Empty title="No hay productos">Agrega el primero con «Nuevo producto».</Empty>}>
        {(d) => (
          <ul className="grid gap-3 sm:grid-cols-2">
            {d.items.map((p) => (
              <li key={p.id}>
                <Card className="flex gap-3">
                  <div className="grid h-20 w-20 shrink-0 place-items-center overflow-hidden rounded-md bg-surface text-muted">
                    {p.imageUrl ? <img src={p.imageUrl} alt="" loading="lazy" referrerPolicy="no-referrer" className="h-full w-full object-cover" /> : <Icon name="bag" className="h-8 w-8" />}
                  </div>
                  <div className="flex min-w-0 flex-1 flex-col gap-1">
                    <p className="truncate font-semibold">{p.name}</p>
                    <p className="text-xs text-muted">{p.category.name}{p.isActive ? '' : ' · Oculto'}</p>
                    <p className="font-bold">{formatMoney(p.price, p.currency)}</p>
                    <div className="mt-1 flex flex-wrap gap-2 text-sm">
                      <button type="button" className="text-brand-text underline" onClick={() => setEditing(p)}>Editar</button>
                      <button type="button" className="underline" onClick={async () => { await api.patch(`/products/${p.id}`, { isActive: !p.isActive }); state.reload(); }}>{p.isActive ? 'Ocultar' : 'Mostrar'}</button>
                      <button type="button" className="text-danger underline" onClick={() => setRemoving(p)}>Quitar</button>
                    </div>
                  </div>
                </Card>
              </li>
            ))}
          </ul>
        )}
      </AsyncView>
      {editing && <ProductForm product={editing === 'new' ? null : editing} categories={categories.data?.data ?? []} defaultCurrency={state.data?.items[0]?.currency ?? ''} onClose={() => setEditing(null)} onSaved={saved} />}
      {removing && (
        <FormDialog open onClose={() => setRemoving(null)} danger title="Quitar producto" submitLabel="Quitar"
          onSubmit={async () => { await api.del(`/products/${removing.id}`); toast('Producto quitado de la tienda'); state.reload(); }}>
          <p className="text-sm">¿Quitar «{removing.name}» de la tienda? Úsalo cuando se agote. Los pedidos anteriores conservan su historial. Si solo quieres esconderlo un tiempo, usa «Ocultar».</p>
        </FormDialog>
      )}
      {cats && <CategoriesDialog onClose={() => setCats(false)} onChanged={() => { categories.reload(); state.reload(); }} />}
    </div>
  );
}
