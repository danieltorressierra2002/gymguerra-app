import { describe, expect, it } from 'vitest';
import type { Summary } from '../../lib/types';
import { revenueView } from './Dashboard';

const base: Summary = {
  asOf: '2026-11-22', warningDays: 5,
  members: { total: 0, ok: 0, expiring: 0, expired: 0, frozen: 0, withoutMembership: 0 },
  attention: [], orders: { pendingPayment: 0, toPrepare: 0 },
  revenue: { months: ['2026-09', '2026-10', '2026-11'], series: [] },
};

describe('gráfico de ingresos', () => {
  it('sin pagos no hay moneda principal', () => {
    expect(revenueView(base).main).toBeNull();
  });

  it('dibuja la moneda con más ingresos y rellena con 0 los meses sin pagos', () => {
    const v = revenueView({ ...base, revenue: { months: base.revenue.months, series: [
      { month: '2026-10', currency: 'USD', total: '50.00' }, { month: '2026-11', currency: 'USD', total: '120.00' }, { month: '2026-11', currency: 'CUP', total: '9000.00' },
    ] } });
    expect(v.main).toBe('CUP'); // 9000 > 170: no se comparan monedas, solo se elige una para dibujar
    expect(v.bars.map((b) => b.total)).toEqual([0, 0, 9000]);
    expect(v.others).toEqual([{ month: '2026-11', currency: 'USD', total: '120.00' }]); // las demás se listan aparte
  });
});
