import { useEffect, useState } from 'react';
import { AsyncView, Button, Card, PageTitle, TextField, useToast } from '../../components/ui';
import { api } from '../../lib/api';
import { errorText } from '../../lib/format';
import { useAsync } from '../../lib/useAsync';

export function AdminSettings() {
  const toast = useToast();
  const state = useAsync(() => api.get<{ data: { warningDays: number } }>('/settings/membership'), []);
  const [days, setDays] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => { if (state.data) setDays(String(state.data.data.warningDays)); }, [state.data]);
  const n = Number(days);
  const valid = days !== '' && Number.isInteger(n) && n >= 0 && n <= 60;

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await api.put('/settings/membership', { warningDays: n });
      toast('Ajuste guardado');
      state.reload();
    } catch (err) {
      setError(errorText(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto flex max-w-xl flex-col gap-4">
      <PageTitle>Ajustes</PageTitle>
      <AsyncView state={state}>
        {() => (
          <Card>
            <form onSubmit={save} className="flex flex-col gap-4">
              <h2 className="font-display text-xl font-semibold uppercase">Aviso de «Por vencer»</h2>
              <TextField label="Días antes del vencimiento" type="number" min={0} max={60} value={days} onChange={(e) => setDays(e.target.value)}
                error={days !== '' && !valid ? 'Escribe un número entero entre 0 y 60.' : null}
                hint={valid ? `Un miembro aparece como «Por vencer» cuando le faltan ${n} día${n === 1 ? '' : 's'} o menos.` : undefined} />
              {error && <p role="alert" className="text-sm text-danger">{error}</p>}
              <Button type="submit" busy={busy} disabled={!valid}>Guardar</Button>
            </form>
          </Card>
        )}
      </AsyncView>
    </div>
  );
}
