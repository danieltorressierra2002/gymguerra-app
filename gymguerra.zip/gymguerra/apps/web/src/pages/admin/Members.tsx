import { useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { AsyncView, Button, Card, Empty, FormDialog, PageTitle, TextField } from '../../components/ui';
import { StatusBadge } from '../../components/StatusBadge';
import { api } from '../../lib/api';
import { formatShortDate } from '../../lib/format';
import type { MemberRow, Paged } from '../../lib/types';
import { useAsync } from '../../lib/useAsync';
import { useDebounced } from '../../lib/useDebounced';
import { SetupLinkDialog } from './SetupLinkDialog';

const opt = (s: string) => (s.trim() === '' ? undefined : s.trim());

function NewMemberDialog({ open, onClose, onCreated }: { open: boolean; onClose: () => void; onCreated: (r: { name: string; link: string | null; sent: boolean }) => void }) {
  const [f, setF] = useState({ name: '', email: '', documentId: '', phone: '', address: '', ecName: '', ecPhone: '', ecRel: '' });
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement>) => setF({ ...f, [k]: e.target.value });
  return (
    <FormDialog open={open} onClose={onClose} title="Nuevo miembro" submitLabel="Crear miembro" wide
      onSubmit={async () => {
        const res = await api.post<{ data: { setupLink: string | null; invitationSent: boolean } }>('/members', {
          name: f.name.trim(), email: f.email.trim(), documentId: f.documentId.trim(),
          phone: opt(f.phone), address: opt(f.address),
          ...(opt(f.ecName) && opt(f.ecPhone) ? { emergencyContact: { name: f.ecName.trim(), phone: f.ecPhone.trim(), ...(opt(f.ecRel) ? { relation: f.ecRel.trim() } : {}) } } : {}),
        });
        onCreated({ name: f.name.trim(), link: res.data.setupLink, sent: res.data.invitationSent });
        setF({ name: '', email: '', documentId: '', phone: '', address: '', ecName: '', ecPhone: '', ecRel: '' });
      }}>
      <div className="grid gap-3 sm:grid-cols-2">
        <TextField label="Nombre completo" value={f.name} onChange={set('name')} required />
        <TextField label="Documento de identidad" value={f.documentId} onChange={set('documentId')} required />
        <TextField label="Correo electrónico" type="email" value={f.email} onChange={set('email')} required hint="Es su usuario para entrar." />
        <TextField label="Teléfono" type="tel" value={f.phone} onChange={set('phone')} />
        <div className="sm:col-span-2"><TextField label="Dirección" value={f.address} onChange={set('address')} /></div>
      </div>
      <fieldset className="grid gap-3 rounded-md border border-line p-3 sm:grid-cols-3">
        <legend className="px-1 text-sm font-semibold">Contacto de emergencia (opcional)</legend>
        <TextField label="Nombre" value={f.ecName} onChange={set('ecName')} />
        <TextField label="Teléfono" type="tel" value={f.ecPhone} onChange={set('ecPhone')} />
        <TextField label="Parentesco" value={f.ecRel} onChange={set('ecRel')} />
      </fieldset>
      <p className="text-xs text-muted">Al crearlo recibirás un enlace para que el cliente cree su contraseña.</p>
    </FormDialog>
  );
}

function stateOf(m: MemberRow) {
  return m.currentMembership ? <StatusBadge state={m.currentMembership.semaforo.state} /> : <span className="text-sm text-muted">Sin membresía</span>;
}

/** Lista de clientes. El administrador crea y gestiona; el entrenador solo consulta a los suyos. */
export function MembersPage({ base, readOnly = false }: { base: '/admin' | '/entrenador'; readOnly?: boolean }) {
  const [params, setParams] = useSearchParams();
  const [q, setQ] = useState('');
  const dq = useDebounced(q);
  const [page, setPage] = useState(1);
  const [creating, setCreating] = useState(!readOnly && params.get('nuevo') === '1');
  const [link, setLink] = useState<{ name: string; link: string | null; sent: boolean } | null>(null);
  const state = useAsync(() => api.get<Paged<MemberRow>>('/members', { q: dq, page, pageSize: 20 }), [dq, page]);

  function closeCreate() {
    setCreating(false);
    if (params.has('nuevo')) setParams({}, { replace: true });
  }

  return (
    <div className="mx-auto flex max-w-5xl flex-col gap-4">
      <PageTitle action={!readOnly && <Button onClick={() => setCreating(true)}><span aria-hidden="true">+</span> Nuevo miembro</Button>}>
        {readOnly ? 'Mis clientes' : 'Miembros'}
      </PageTitle>
      <TextField label="Buscar por nombre, documento, teléfono o correo" type="search" value={q}
        onChange={(e) => { setQ(e.target.value); setPage(1); }} />

      <AsyncView state={state} isEmpty={(d) => d.items.length === 0}
        empty={<Empty title={dq ? 'No hay resultados' : 'Aún no hay miembros'}>{dq ? 'Prueba con otro nombre o documento.' : readOnly ? 'Aún no tienes clientes asignados.' : 'Crea el primero con «Nuevo miembro».'}</Empty>}>
        {(d) => (
          <Card className="p-0">
            <table className="hidden w-full text-left text-sm md:table">
              <thead className="text-xs text-muted"><tr><th className="p-3">Nombre</th><th className="p-3">Documento</th><th className="p-3">Plan</th><th className="p-3">Vence</th><th className="p-3">Estado</th></tr></thead>
              <tbody className="divide-y divide-line">
                {d.items.map((m) => (
                  <tr key={m.id}>
                    <td className="p-3"><Link className="font-semibold hover:underline" to={`${base}/miembros/${m.id}`}>{m.user.name}</Link><p className="text-xs text-muted">{m.user.email}</p></td>
                    <td className="p-3">{m.documentId}</td>
                    <td className="p-3">{m.currentMembership?.plan ?? '—'}</td>
                    <td className="p-3">{m.currentMembership ? formatShortDate(m.currentMembership.endDate) : '—'}</td>
                    <td className="p-3">{stateOf(m)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <ul className="divide-y divide-line md:hidden">
              {d.items.map((m) => (
                <li key={m.id}>
                  <Link to={`${base}/miembros/${m.id}`} className="flex flex-col gap-1 p-4">
                    <span className="font-semibold">{m.user.name}</span>
                    <span className="text-xs text-muted">{m.documentId} · {m.currentMembership?.plan ?? 'Sin plan'}{m.currentMembership ? ` · vence ${formatShortDate(m.currentMembership.endDate)}` : ''}</span>
                    <span className="mt-1">{stateOf(m)}</span>
                  </Link>
                </li>
              ))}
            </ul>
            <div className="flex items-center justify-between border-t border-line p-3 text-sm text-muted">
              <Button variant="secondary" disabled={page <= 1} onClick={() => setPage(page - 1)}>Anterior</Button>
              <span>{d.total} en total · página {d.page}</span>
              <Button variant="secondary" disabled={page * d.pageSize >= d.total} onClick={() => setPage(page + 1)}>Siguiente</Button>
            </div>
          </Card>
        )}
      </AsyncView>

      {!readOnly && <NewMemberDialog open={creating} onClose={closeCreate} onCreated={(r) => { setLink(r); state.reload(); }} />}
      {link && <SetupLinkDialog name={link.name} link={link.link} sent={link.sent} onClose={() => setLink(null)} />}
    </div>
  );
}
