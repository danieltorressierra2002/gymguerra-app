import { Button, Modal, useToast } from '../../components/ui';

/**
 * Muestra el enlace de activación para que el administrador se lo entregue al cliente
 * (no se envían correos). El enlace da acceso a la cuenta: un solo uso y caduca a las 72 horas.
 */
export function SetupLinkDialog({
  name, link, sent, onClose,
}: { name: string; link: string | null; sent: boolean; onClose: () => void }) {
  const toast = useToast();
  const message = link ? `Hola ${name}, este es tu enlace para crear tu contraseña en Gimnasio Guerra (válido 72 horas, un solo uso): ${link}` : '';

  async function copy() {
    try {
      await navigator.clipboard.writeText(link ?? '');
      toast('Enlace copiado');
    } catch {
      toast('No se pudo copiar: selecciona el texto y cópialo a mano.');
    }
  }

  return (
    <Modal open onClose={onClose} title="Enlace de activación">
      {link ? (
        <div className="flex flex-col gap-3 text-sm">
          <p>Entrégale este enlace a <strong>{name}</strong> para que cree su contraseña.{sent ? ' También se envió por correo.' : ''}</p>
          <label className="flex flex-col gap-1">
            <span className="font-semibold">Enlace</span>
            <input readOnly value={link} onFocus={(e) => e.currentTarget.select()} className="min-h-11 w-full rounded-md border border-line bg-surface px-3 text-xs" />
          </label>
          <div className="flex flex-col gap-2 sm:flex-row">
            <Button onClick={() => void copy()}>Copiar enlace</Button>
            <a href={`https://wa.me/?text=${encodeURIComponent(message)}`} target="_blank" rel="noopener noreferrer"
              className="inline-flex min-h-11 items-center justify-center rounded-md border border-line px-4 text-sm font-semibold hover:border-brand">
              Compartir por WhatsApp
            </a>
          </div>
          <p className="rounded-md border border-warn/40 p-3 text-xs text-warn">
            Entrégalo solo a esa persona: quien tenga el enlace puede crear la contraseña de la cuenta. Se puede usar una sola vez y caduca en 72 horas.
          </p>
        </div>
      ) : (
        <p role="alert" className="text-sm text-danger">No se pudo generar el enlace. Ábrelo de nuevo desde la ficha del cliente con «Enlace de activación».</p>
      )}
    </Modal>
  );
}
