import { Link } from 'react-router-dom';
import { AsyncView, Card, Empty, PageTitle } from '../../components/ui';
import { StatusBadge } from '../../components/StatusBadge';
import { Button } from '../../components/ui';
import { api } from '../../lib/api';
import { formatMoney, formatShortDate } from '../../lib/format';
import type { Summary } from '../../lib/types';
import { useAsync } from '../../lib/useAsync';

const MONTHS = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];
const monthLabel = (m: string) => MONTHS[Number(m.slice(5)) - 1] ?? m;

function Kpi({ label, value, tone = '' }: { label: string; value: string | number; tone?: string }) {
  return (
    <Card>
      <p className="text-sm text-muted">{label}</p>
      <p className={`font-display text-4xl font-bold ${tone}`}>{value}</p>
    </Card>
  );
}

/** Moneda con más ingresos: es la que se dibuja. Las demás se listan aparte (nunca se suman monedas distintas). */
export function revenueView(s: Summary) {
  const byCurrency = new Map<string, number>();
  for (const r of s.revenue.series) byCurrency.set(r.currency, (byCurrency.get(r.currency) ?? 0) + Number(r.total));
  const main = [...byCurrency.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] ?? null;
  const bars = s.revenue.months.map((m) => ({
    month: m,
    total: Number(s.revenue.series.find((r) => r.month === m && r.currency === main)?.total ?? 0),
  }));
  const current = s.revenue.months[s.revenue.months.length - 1];
  const others = s.revenue.series.filter((r) => r.month === current && r.currency !== main);
  return { main, bars, others };
}

export function AdminDashboard() {
  const state = useAsync(() => api.get<{ data: Summary }>('/admin/summary'), []);
  return (
    <div className="mx-auto flex max-w-5xl flex-col gap-4">
      <PageTitle action={<Link to="/admin/miembros?nuevo=1"><Button><span aria-hidden="true">+</span> Nuevo miembro</Button></Link>}>Resumen</PageTitle>
      <AsyncView state={state}>
        {({ data: s }) => {
          const { main, bars, others } = revenueView(s);
          const max = Math.max(1, ...bars.map((b) => b.total));
          const thisMonth = bars[bars.length - 1]?.total ?? 0;
          return (
            <>
              <div className="grid grid-cols-2 gap-3 lg:grid-cols-3">
                <Kpi label="Miembros activos" value={s.members.ok + s.members.expiring} />
                <Kpi label="Por vencer" value={s.members.expiring} tone="text-warn" />
                <Kpi label="Vencidos" value={s.members.expired} tone="text-danger" />
                <Kpi label="Ingresos del mes" value={main ? formatMoney(thisMonth, main) : '—'} />
                <Kpi label="Pedidos pendientes de pago" value={s.orders.pendingPayment} />
                <Kpi label="Pedidos por preparar" value={s.orders.toPrepare} />
              </div>

              <div className="grid gap-4 lg:grid-cols-5">
                <Card className="lg:col-span-3">
                  <h2 className="mb-3 font-display text-xl font-semibold uppercase">Ingresos, últimos 6 meses{main ? ` (${main})` : ''}</h2>
                  {main ? (
                    <>
                      <div className="flex h-36 items-end gap-3" aria-hidden="true">
                        {bars.map((b, i) => (
                          <div key={b.month} className="flex-1 rounded-t-md" style={{ height: `${Math.max(4, (b.total / max) * 100)}%`, background: i === bars.length - 1 ? 'rgb(var(--brand))' : 'rgb(var(--line))' }} />
                        ))}
                      </div>
                      <div className="mt-1 flex gap-3 text-xs text-muted" aria-hidden="true">{bars.map((b) => <span key={b.month} className="flex-1 text-center">{monthLabel(b.month)}</span>)}</div>
                      <table className="sr-only"><caption>Ingresos por mes</caption><tbody>
                        {bars.map((b) => <tr key={b.month}><th scope="row">{b.month}</th><td>{formatMoney(b.total, main)}</td></tr>)}
                      </tbody></table>
                      {others.length > 0 && <p className="mt-3 text-sm text-muted">Este mes también: {others.map((o) => formatMoney(o.total, o.currency)).join(' · ')}</p>}
                    </>
                  ) : <Empty title="Aún no hay pagos registrados" />}
                </Card>

                <Card className="lg:col-span-2">
                  <h2 className="mb-3 font-display text-xl font-semibold uppercase">Miembros por estado</h2>
                  <dl className="flex flex-col gap-2 text-sm">
                    {([['Al día', s.members.ok], ['Por vencer', s.members.expiring], ['Vencidos', s.members.expired], ['Pausadas', s.members.frozen], ['Sin membresía', s.members.withoutMembership]] as const)
                      .map(([k, v]) => <div key={k} className="flex justify-between"><dt>{k}</dt><dd className="font-semibold">{v}</dd></div>)}
                    <div className="flex justify-between border-t border-line pt-2"><dt>Total</dt><dd className="font-semibold">{s.members.total}</dd></div>
                  </dl>
                </Card>
              </div>

              <Card>
                <h2 className="mb-2 font-display text-xl font-semibold uppercase">Requieren atención</h2>
                {s.attention.length === 0 ? <Empty title="Nadie por vencer ni vencido reciente" /> : (
                  <ul className="divide-y divide-line">
                    {s.attention.map((a) => (
                      <li key={a.membershipId} className="flex flex-wrap items-center justify-between gap-2 py-3">
                        <div>
                          <Link to={`/admin/miembros/${a.memberId}`} className="font-semibold underline-offset-2 hover:underline">{a.name}</Link>
                          <p className="text-xs text-muted">{a.plan} · vence {formatShortDate(a.endDate)}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <StatusBadge state={a.state} />
                          <Link to={`/admin/miembros/${a.memberId}?renovar=${a.membershipId}`}><Button variant="secondary">Renovar</Button></Link>
                        </div>
                      </li>
                    ))}
                  </ul>
                )}
              </Card>
              <p className="text-xs text-muted">Umbral de «Por vencer»: {s.warningDays} días. Se cambia en Ajustes.</p>
            </>
          );
        }}
      </AsyncView>
    </div>
  );
}
