import { screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { describe, expect, it } from 'vitest';
import { AppRoutes } from './App';
import { err, mockFetch, renderApp, sessionOf, type Call, type Reply } from './test-utils';

const VERSIONS = { TERMS: { version: '1.0' }, PRIVACY: { version: '1.0' }, STORE_TERMS: { version: '1.0' } };
const consents = (pending: string[] = []) => ({ body: { data: { current: VERSIONS, accepted: [], pending } } });
const ana = { id: 'u1', name: 'Ana Pérez', email: 'ana@x.cu', role: 'MEMBER', memberId: 'm1' };
const boss = { id: 'u2', name: 'Dueño', email: 'd@x.cu', role: 'ADMIN' };
const coach = { id: 'u3', name: 'Coach', email: 'c@x.cu', role: 'TRAINER', trainerId: 't1' };
const membership = {
  id: 'ms1', memberId: 'm1', planId: 'p', status: 'ACTIVE', startDate: '2026-11-09', endDate: '2026-12-09', priceSnapshot: '25.00',
  currency: 'USD', semaforo: { state: 'OK', daysLeft: 17 }, plan: { id: 'p', name: 'Plan Mensual' },
};
const summary = {
  asOf: '2026-11-22', warningDays: 5,
  members: { total: 20, ok: 12, expiring: 3, expired: 2, frozen: 1, withoutMembership: 2 },
  attention: [{ memberId: 'm9', name: 'Luis Gómez', membershipId: 'ms9', plan: 'Mensual', endDate: '2026-11-24', state: 'EXPIRING', daysLeft: 2 }],
  revenue: { months: ['2026-06', '2026-07', '2026-08', '2026-09', '2026-10', '2026-11'], series: [{ month: '2026-11', currency: 'USD', total: '150.00' }] },
  orders: { pendingPayment: 2, toPrepare: 4 },
};

const server = (user: object, extra: (c: Call) => Reply | undefined = () => undefined) => (c: Call) =>
  sessionOf(user)(c) ??
  extra(c) ??
  (c.path === '/consents/me' ? consents() :
   c.path === '/memberships/me' ? { body: { data: membership } } :
   c.path === '/payments' ? { body: { items: [], total: 0, page: 1, pageSize: 3 } } :
   c.path === '/admin/summary' ? { body: { data: summary } } :
   c.path === '/members' ? { body: { items: [], total: 0, page: 1, pageSize: 20 } } :
   undefined);

describe('rutas y protección por rol', () => {
  it('sin sesión, cualquier panel lleva al inicio de sesión', async () => {
    mockFetch((c) => (c.path === '/auth/refresh' ? err(401, 'INVALID_SESSION') : undefined));
    renderApp(<AppRoutes />, '/admin');
    expect(await screen.findByText('Inicia sesión para ver tu membresía')).toBeInTheDocument();
  });

  it('un cliente que intenta abrir /admin vuelve a su propio panel', async () => {
    mockFetch(server(ana));
    renderApp(<AppRoutes />, '/admin');
    expect(await screen.findByRole('heading', { name: 'Hola, Ana' })).toBeInTheDocument();
    expect(await screen.findByText('Al día')).toBeInTheDocument();
    expect(screen.queryByText('Resumen')).not.toBeInTheDocument();
  });

  it('un entrenador que intenta abrir /admin va a su lista de clientes', async () => {
    mockFetch(server(coach));
    renderApp(<AppRoutes />, '/admin');
    expect(await screen.findByRole('heading', { name: 'Mis clientes' })).toBeInTheDocument();
  });

  it('el administrador ve el resumen con sus cifras y quién requiere atención', async () => {
    mockFetch(server(boss));
    renderApp(<AppRoutes />, '/admin');
    expect(await screen.findByRole('heading', { name: 'Resumen' })).toBeInTheDocument();
    expect((await screen.findByText('Miembros activos')).parentElement).toHaveTextContent('15'); // 12 al día + 3 por vencer
    expect(screen.getAllByText('Vencidos')[0]!.parentElement).toHaveTextContent('2'); // la tarjeta, no la lista de estados
    expect(screen.getByText('Pedidos por preparar').parentElement).toHaveTextContent('4');
    expect(screen.getByRole('link', { name: 'Luis Gómez' })).toHaveAttribute('href', '/admin/miembros/m9');
  });

  it('mientras falten documentos legales por aceptar, solo se ve la pantalla de aceptación', async () => {
    let accepted = false;
    const calls = mockFetch(server(ana, (c) => {
      if (c.path === '/consents/me') return consents(accepted ? [] : ['TERMS', 'PRIVACY']);
      if (c.path === '/consents' && c.method === 'POST') { accepted = true; return { status: 201, body: {} }; }
      return undefined;
    }));
    renderApp(<AppRoutes />, '/app');
    const dialog = await screen.findByRole('dialog', { name: 'Antes de continuar' });
    expect(screen.queryByRole('heading', { name: 'Hola, Ana' })).not.toBeInTheDocument(); // el panel no se muestra

    await userEvent.click(within(dialog).getByRole('checkbox'));
    await userEvent.click(within(dialog).getByRole('button', { name: 'Aceptar y continuar' }));
    expect(await screen.findByRole('heading', { name: 'Hola, Ana' })).toBeInTheDocument();
    expect(calls.find((c) => c.path === '/consents' && c.method === 'POST')?.body).toEqual({
      documents: [{ type: 'TERMS', version: '1.0' }, { type: 'PRIVACY', version: '1.0' }],
    });
  });

  it('si no se puede comprobar la aceptación legal, no se abre el panel', async () => {
    mockFetch(server(ana, (c) => (c.path === '/consents/me' ? err(500, 'INTERNAL_ERROR', 'Ocurrió un error inesperado') : undefined)));
    renderApp(<AppRoutes />, '/app');
    expect(await screen.findByRole('alert')).toHaveTextContent(/error inesperado/i);
    expect(screen.queryByRole('heading', { name: 'Hola, Ana' })).not.toBeInTheDocument();
  });

  it('las páginas legales son públicas y las desconocidas dan 404', async () => {
    mockFetch((c) => (c.path === '/auth/refresh' ? err(401, 'INVALID_SESSION') : undefined));
    const { unmount } = renderApp(<AppRoutes />, '/legal/privacidad');
    expect(await screen.findByRole('heading', { level: 1, name: 'Política de Privacidad' })).toBeInTheDocument();
    unmount();
    mockFetch((c) => (c.path === '/auth/refresh' ? err(401, 'INVALID_SESSION') : undefined));
    renderApp(<AppRoutes />, '/legal/inventada');
    expect(await screen.findByText('404')).toBeInTheDocument();
  });

  it('cerrar sesión devuelve al inicio de sesión', async () => {
    mockFetch(server(ana, (c) => (c.path === '/auth/logout' ? { status: 204 } : undefined)));
    renderApp(<AppRoutes />, '/app');
    await screen.findByRole('heading', { name: 'Hola, Ana' });
    await userEvent.click(screen.getAllByRole('button', { name: /Salir/ })[0]!);
    await waitFor(() => expect(screen.getByText('Inicia sesión para ver tu membresía')).toBeInTheDocument());
  });
});
