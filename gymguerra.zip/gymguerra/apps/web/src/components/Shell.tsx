import { NavLink, Outlet } from 'react-router-dom';
import { LegalLinks } from '../features/legal';
import { useAuth } from '../lib/auth';
import { applyTheme, getTheme } from '../lib/theme';
import { useState } from 'react';
import { Icon, type IconName } from './Icon';

export interface NavItem { to: string; label: string; icon: IconName; end?: boolean }

function ThemeToggle() {
  const [theme, setTheme] = useState(getTheme());
  const next = theme === 'dark' ? 'light' : 'dark';
  return (
    <button
      type="button"
      aria-label={`Cambiar a tema ${next === 'dark' ? 'oscuro' : 'claro'}`}
      onClick={() => { applyTheme(next); setTheme(next); }}
      className="grid min-h-11 min-w-11 place-items-center rounded-md text-muted hover:text-fg"
    >
      <Icon name={theme === 'dark' ? 'sun' : 'moon'} />
    </button>
  );
}

const linkClass = ({ isActive }: { isActive: boolean }) =>
  `flex min-h-11 items-center gap-3 rounded-md px-3 text-sm ${isActive ? 'bg-brand/15 font-semibold text-brand-text' : 'text-muted hover:text-fg'}`;
const tabClass = ({ isActive }: { isActive: boolean }) =>
  `flex min-h-14 flex-1 flex-col items-center justify-center gap-0.5 text-[11px] ${isActive ? 'font-semibold text-brand-text' : 'text-muted'}`;

/** Marco común: barra superior, menú lateral (escritorio) o barra inferior (móvil). */
export function AppShell({ nav, roleLabel }: { nav: NavItem[]; roleLabel: string }) {
  const { user, logout } = useAuth();
  return (
    <div className="flex min-h-dvh flex-col md:flex-row">
      <aside className="hidden w-60 shrink-0 flex-col gap-1 border-r border-line bg-surface p-4 md:flex">
        <p className="px-3 pb-4 font-display text-2xl font-bold uppercase"><span className="text-brand">Gym</span>Guerra</p>
        <nav aria-label="Principal" className="flex flex-col gap-1">
          {nav.map((n) => (
            <NavLink key={n.to} to={n.to} end={n.end} className={linkClass}><Icon name={n.icon} />{n.label}</NavLink>
          ))}
        </nav>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex items-center justify-between gap-2 border-b border-line px-4 py-2">
          <p className="font-display text-xl font-bold uppercase md:hidden"><span className="text-brand">Gym</span>Guerra</p>
          <p className="hidden text-sm text-muted md:block">{roleLabel} · {user?.name}</p>
          <div className="flex items-center">
            <ThemeToggle />
            <button type="button" onClick={() => void logout()} className="flex min-h-11 items-center gap-2 rounded-md px-3 text-sm text-muted hover:text-fg">
              <Icon name="logout" className="h-4 w-4" />Salir
            </button>
          </div>
        </header>
        <main className="flex-1 p-4 pb-24 md:p-8 md:pb-8"><Outlet /></main>
        <footer className="border-t border-line p-4 pb-20 md:pb-4"><LegalLinks /></footer>
      </div>

      <nav aria-label="Principal" className="fixed inset-x-0 bottom-0 z-30 flex border-t border-line bg-surface pb-[env(safe-area-inset-bottom)] md:hidden">
        {nav.map((n) => (
          <NavLink key={n.to} to={n.to} end={n.end} className={tabClass}><Icon name={n.icon} />{n.label}</NavLink>
        ))}
      </nav>
    </div>
  );
}
