import {
  createContext, useCallback, useContext, useEffect, useId, useRef, useState,
  type ButtonHTMLAttributes, type InputHTMLAttributes, type ReactNode, type SelectHTMLAttributes, type TextareaHTMLAttributes,
} from 'react';
import { ApiError } from '../lib/api';
import { errorText } from '../lib/format';
import { Icon } from './Icon';

// ───────── botones ─────────
const VARIANTS = {
  primary: 'bg-brand text-brand-on hover:bg-brand-hover',
  secondary: 'border border-line text-fg hover:border-brand',
  danger: 'border border-danger text-danger hover:bg-danger/10',
  ghost: 'text-muted hover:text-fg',
} as const;

export function Button({
  variant = 'primary', busy, className = '', children, disabled, ...rest
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: keyof typeof VARIANTS; busy?: boolean }) {
  return (
    <button
      type="button"
      {...rest}
      disabled={disabled || busy}
      aria-busy={busy || undefined}
      className={`inline-flex min-h-11 items-center justify-center gap-2 rounded-md px-4 text-sm font-semibold transition disabled:cursor-not-allowed disabled:opacity-50 ${VARIANTS[variant]} ${className}`}
    >
      {busy ? 'Un momento…' : children}
    </button>
  );
}

// ───────── campos de formulario (etiqueta visible, error asociado) ─────────
const CONTROL =
  'min-h-11 w-full rounded-md border border-line bg-surface px-3 text-base text-fg placeholder:text-muted focus:border-brand disabled:opacity-60';

interface FieldProps { label: string; error?: string | null; hint?: string }

function useFieldIds(error?: string | null, hint?: string) {
  const id = useId();
  const describedBy = [error ? `${id}-err` : null, hint ? `${id}-hint` : null].filter(Boolean).join(' ') || undefined;
  return { id, describedBy };
}

function FieldShell({ id, label, error, hint, children }: FieldProps & { id: string; children: ReactNode }) {
  return (
    <div className="flex flex-col gap-1">
      <label htmlFor={id} className="text-sm font-semibold">{label}</label>
      {children}
      {hint && <p id={`${id}-hint`} className="text-xs text-muted">{hint}</p>}
      {error && <p id={`${id}-err`} role="alert" className="flex items-center gap-1 text-sm text-danger"><Icon name="alert" className="h-4 w-4" />{error}</p>}
    </div>
  );
}

export function TextField({ label, error, hint, className = '', ...rest }: FieldProps & InputHTMLAttributes<HTMLInputElement>) {
  const { id, describedBy } = useFieldIds(error, hint);
  return (
    <FieldShell id={id} label={label} error={error} hint={hint}>
      <input id={id} aria-invalid={error ? true : undefined} aria-describedby={describedBy} className={`${CONTROL} ${className}`} {...rest} />
    </FieldShell>
  );
}

export function SelectField({ label, error, hint, children, ...rest }: FieldProps & SelectHTMLAttributes<HTMLSelectElement>) {
  const { id, describedBy } = useFieldIds(error, hint);
  return (
    <FieldShell id={id} label={label} error={error} hint={hint}>
      <select id={id} aria-invalid={error ? true : undefined} aria-describedby={describedBy} className={CONTROL} {...rest}>{children}</select>
    </FieldShell>
  );
}

export function TextAreaField({ label, error, hint, ...rest }: FieldProps & TextareaHTMLAttributes<HTMLTextAreaElement>) {
  const { id, describedBy } = useFieldIds(error, hint);
  return (
    <FieldShell id={id} label={label} error={error} hint={hint}>
      <textarea id={id} aria-invalid={error ? true : undefined} aria-describedby={describedBy} className={`${CONTROL} py-2`} rows={3} {...rest} />
    </FieldShell>
  );
}

export function CheckField({ label, ...rest }: { label: string } & InputHTMLAttributes<HTMLInputElement>) {
  return (
    <label className="flex min-h-11 items-center gap-3 text-sm">
      <input type="checkbox" className="h-5 w-5" {...rest} />
      <span>{label}</span>
    </label>
  );
}

// ───────── contenedores y estados ─────────
export function Card({ children, className = '' }: { children: ReactNode; className?: string }) {
  return <section className={`rounded-lg border border-line bg-card p-4 shadow-card ${className}`}>{children}</section>;
}

export function PageTitle({ children, action }: { children: ReactNode; action?: ReactNode }) {
  return (
    <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
      <h1 className="font-display text-3xl font-bold uppercase">{children}</h1>
      {action}
    </div>
  );
}

export const Loading = () => <div role="status" className="animate-pulse p-6 text-muted">Cargando…</div>;

export function ErrorBox({ error, retry }: { error: unknown; retry?: () => void }) {
  return (
    <div role="alert" className="flex flex-col items-start gap-3 rounded-lg border border-danger p-4 text-sm">
      <p className="flex items-center gap-2 text-danger"><Icon name="alert" />{errorText(error)}</p>
      {retry && <Button variant="secondary" onClick={retry}>Reintentar</Button>}
    </div>
  );
}

export function Empty({ title, children }: { title: string; children?: ReactNode }) {
  return (
    <div className="rounded-lg border border-dashed border-line p-8 text-center">
      <p className="font-semibold">{title}</p>
      {children && <div className="mt-2 text-sm text-muted">{children}</div>}
    </div>
  );
}

/** Pinta carga / error / vacío / contenido a partir del resultado de useAsync. */
export function AsyncView<T>({
  state, children, isEmpty, empty,
}: {
  state: { data?: T; error?: unknown; loading: boolean; reload: () => void };
  children: (data: T) => ReactNode;
  isEmpty?: (data: T) => boolean;
  empty?: ReactNode;
}) {
  if (state.error && state.data === undefined) return <ErrorBox error={state.error} retry={state.reload} />;
  if (state.data === undefined) return <Loading />;
  if (isEmpty?.(state.data)) return <>{empty}</>;
  return <>{children(state.data)}</>;
}

// ───────── modal accesible ─────────
export function Modal({ open, onClose, title, children, wide }: { open: boolean; onClose: () => void; title: string; children: ReactNode; wide?: boolean }) {
  const titleId = useId();
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const previous = document.activeElement as HTMLElement | null;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    document.addEventListener('keydown', onKey);
    ref.current?.querySelector<HTMLElement>('input, select, textarea, button')?.focus();
    return () => {
      document.removeEventListener('keydown', onKey);
      previous?.focus();
    };
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-40 grid place-items-end bg-black/60 p-0 sm:place-items-center sm:p-4" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div ref={ref} role="dialog" aria-modal="true" aria-labelledby={titleId}
        className={`max-h-[92dvh] w-full overflow-y-auto rounded-t-lg bg-card p-5 text-fg shadow-pop sm:rounded-lg ${wide ? 'sm:max-w-2xl' : 'sm:max-w-md'}`}>
        <div className="mb-4 flex items-start justify-between gap-3">
          <h2 id={titleId} className="font-display text-2xl font-bold uppercase">{title}</h2>
          <button type="button" aria-label="Cerrar" onClick={onClose} className="min-h-11 min-w-11 text-muted hover:text-fg"><Icon name="x" /></button>
        </div>
        {children}
      </div>
    </div>
  );
}

/** Formulario dentro de un modal: gestiona «enviando» y muestra el error del servidor. */
export function FormDialog({
  open, onClose, title, submitLabel, onSubmit, children, wide, danger,
}: {
  open: boolean; onClose: () => void; title: string; submitLabel: string; wide?: boolean; danger?: boolean;
  onSubmit: () => Promise<void>; children: ReactNode;
}) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  useEffect(() => { if (open) setError(null); }, [open]);
  return (
    <Modal open={open} onClose={onClose} title={title} wide={wide}>
      <form
        className="flex flex-col gap-4"
        onSubmit={async (e) => {
          e.preventDefault();
          setBusy(true);
          setError(null);
          try {
            await onSubmit();
            onClose();
          } catch (err) {
            setError(err);
          } finally {
            setBusy(false);
          }
        }}
      >
        {children}
        {error != null && (
          <p role="alert" className="flex items-start gap-2 text-sm text-danger"><Icon name="alert" className="mt-0.5 h-4 w-4" />{errorText(error)}</p>
        )}
        <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
          <Button variant="secondary" onClick={onClose}>Cancelar</Button>
          <Button type="submit" variant={danger ? 'danger' : 'primary'} busy={busy}>{submitLabel}</Button>
        </div>
      </form>
    </Modal>
  );
}

// ───────── avisos ─────────
type ToastFn = (message: string) => void;
const ToastContext = createContext<ToastFn>(() => undefined);
export const useToast = () => useContext(ToastContext);

export function ToastProvider({ children }: { children: ReactNode }) {
  const [message, setMessage] = useState('');
  const timer = useRef<number>(undefined);
  const toast = useCallback((m: string) => {
    setMessage(m);
    window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => setMessage(''), 5000);
  }, []);
  return (
    <ToastContext.Provider value={toast}>
      {children}
      <div aria-live="polite" role="status" className="pointer-events-none fixed inset-x-0 bottom-20 z-50 flex justify-center px-4 md:bottom-6">
        {message && <p className="pointer-events-auto rounded-md border border-line bg-card px-4 py-3 text-sm shadow-pop">{message}</p>}
      </div>
    </ToastContext.Provider>
  );
}

export { ApiError };
