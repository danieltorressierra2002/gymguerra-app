import type { SemaforoState } from '../lib/types';
import { Icon, type IconName } from './Icon';

/** El estado SIEMPRE se comunica con icono y texto, nunca solo con el color. */
export const STATE_INFO: Record<SemaforoState, { label: string; tone: string; ring: string; icon: IconName }> = {
  OK: { label: 'Al día', tone: 'text-ok bg-ok/15', ring: 'rgb(var(--ok))', icon: 'check' },
  EXPIRING: { label: 'Por vencer', tone: 'text-warn bg-warn/15', ring: 'rgb(var(--warn))', icon: 'clock' },
  EXPIRED: { label: 'Vencido', tone: 'text-danger bg-danger/15', ring: 'rgb(var(--danger))', icon: 'alert' },
  FROZEN: { label: 'Pausada', tone: 'text-muted bg-line/40', ring: 'rgb(var(--muted))', icon: 'pause' },
  CANCELLED: { label: 'Cancelada', tone: 'text-muted bg-line/40', ring: 'rgb(var(--muted))', icon: 'x' },
};

export function StatusBadge({ state }: { state: SemaforoState }) {
  const s = STATE_INFO[state];
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-sm font-semibold ${s.tone}`}>
      <Icon name={s.icon} className="h-4 w-4" />
      {s.label}
    </span>
  );
}
