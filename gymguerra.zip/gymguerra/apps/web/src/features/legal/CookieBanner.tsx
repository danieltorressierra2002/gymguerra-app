import { useEffect, useId, useState } from 'react';
import {
  acceptAll,
  customConsent,
  rejectAll,
  type ConsentState,
  type OptionalCategory,
} from '@gymguerra/shared';
import { COOKIE_CONFIG } from './legal-config';
import { CONSENT_REOPEN_EVENT, readConsent, reopenConsentSettings, writeConsent } from './consent-storage';

const LABELS: Record<OptionalCategory, { name: string; help: string }> = {
  preferences: { name: 'Preferencias', help: 'Recuerdan ajustes opcionales de la interfaz.' },
  analytics: { name: 'Analítica', help: 'Nos ayudan a medir el uso del sitio para mejorarlo.' },
  marketing: { name: 'Marketing', help: 'Publicidad y seguimiento entre sitios.' },
};

// Aceptar y Rechazar comparten EXACTAMENTE el mismo estilo: rechazar no puede ser menos visible.
const BTN_MAIN =
  'min-h-11 rounded-md bg-brand px-5 text-sm font-semibold text-brand-on transition hover:bg-brand-hover';
const BTN_SECONDARY =
  'min-h-11 rounded-md border border-line px-5 text-sm font-semibold text-fg transition hover:border-brand';

type Choices = Record<OptionalCategory, boolean>;
const NONE: Choices = { preferences: false, analytics: false, marketing: false };

interface Props {
  optionalInUse?: OptionalCategory[];
  policyHref?: string;
}

/**
 * - Sin categorías opcionales en uso: aviso informativo (solo almacenamiento técnico).
 * - Con categorías opcionales: Aceptar todas / Rechazar todas / Configurar en la primera capa,
 *   casillas apagadas por defecto y nada opcional se carga hasta que se acepte.
 */
export function CookieBanner({
  optionalInUse = COOKIE_CONFIG.optionalInUse,
  policyHref = COOKIE_CONFIG.policyHref,
}: Props) {
  const titleId = useId();
  const [consent, setConsent] = useState<ConsentState | null>(() => readConsent());
  const [reopened, setReopened] = useState(false);
  const [customizing, setCustomizing] = useState(false);
  const [choices, setChoices] = useState<Choices>(NONE);

  useEffect(() => {
    const onReopen = () => {
      const current = readConsent();
      setConsent(current);
      setChoices(current ? { preferences: current.preferences, analytics: current.analytics, marketing: current.marketing } : NONE);
      setCustomizing(true);
      setReopened(true);
    };
    window.addEventListener(CONSENT_REOPEN_EVENT, onReopen);
    return () => window.removeEventListener(CONSENT_REOPEN_EVENT, onReopen);
  }, []);

  if (consent !== null && !reopened) return null;

  const save = (state: ConsentState) => {
    writeConsent(state);
    setConsent(state);
    setReopened(false);
    setCustomizing(false);
  };

  const shell =
    'fixed inset-x-0 bottom-0 z-50 border-t border-line bg-surface p-4 text-fg shadow-pop sm:p-5';

  if (optionalInUse.length === 0) {
    return (
      <section role="region" aria-labelledby={titleId} className={shell}>
        <div className="mx-auto flex max-w-5xl flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 id={titleId} className="font-display text-lg font-semibold uppercase">
              Cookies y almacenamiento
            </h2>
            <p className="text-sm text-muted">
              Usamos únicamente almacenamiento técnico necesario (sesión, tema y carrito). No usamos cookies de
              analítica ni de publicidad. <a className="text-brand-text underline" href={policyHref}>Más información</a>.
            </p>
          </div>
          <button type="button" className={BTN_MAIN} onClick={() => save(rejectAll())}>
            Entendido
          </button>
        </div>
      </section>
    );
  }

  return (
    <section role="region" aria-labelledby={titleId} className={shell}>
      <div className="mx-auto flex max-w-5xl flex-col gap-4">
        <div>
          <h2 id={titleId} className="font-display text-lg font-semibold uppercase">
            Tu privacidad
          </h2>
          <p className="text-sm text-muted">
            Usamos cookies técnicas, necesarias para que el sitio funcione, y, si lo permites, otras opcionales. Puedes
            cambiar tu elección cuando quieras. <a className="text-brand-text underline" href={policyHref}>Política de cookies</a>.
          </p>
        </div>

        {customizing && (
          <fieldset className="grid gap-3 sm:grid-cols-2">
            <legend className="sr-only">Categorías de cookies</legend>
            <label className="flex items-start gap-3 rounded-md border border-line p-3">
              <input type="checkbox" checked disabled aria-describedby={`${titleId}-nec`} className="mt-1 h-5 w-5" />
              <span>
                <span className="block text-sm font-semibold">Técnicas (siempre activas)</span>
                <span id={`${titleId}-nec`} className="block text-sm text-muted">
                  Imprescindibles para iniciar sesión, la tienda y recordar esta elección.
                </span>
              </span>
            </label>
            {optionalInUse.map((cat) => (
              <label key={cat} className="flex items-start gap-3 rounded-md border border-line p-3">
                <input
                  type="checkbox"
                  className="mt-1 h-5 w-5"
                  checked={choices[cat]}
                  onChange={(e) => setChoices((c) => ({ ...c, [cat]: e.target.checked }))}
                />
                <span>
                  <span className="block text-sm font-semibold">{LABELS[cat].name}</span>
                  <span className="block text-sm text-muted">{LABELS[cat].help}</span>
                </span>
              </label>
            ))}
          </fieldset>
        )}

        <div className="flex flex-col gap-2 sm:flex-row">
          {customizing ? (
            <button type="button" className={BTN_MAIN} onClick={() => save(customConsent(choices))}>
              Guardar selección
            </button>
          ) : null}
          <button type="button" className={BTN_MAIN} onClick={() => save(acceptAll())}>
            Aceptar todas
          </button>
          <button type="button" className={BTN_MAIN} onClick={() => save(rejectAll())}>
            Rechazar todas
          </button>
          {customizing ? null : (
            <button type="button" className={BTN_SECONDARY} onClick={() => setCustomizing(true)}>
              Configurar
            </button>
          )}
        </div>
      </div>
    </section>
  );
}

/** Enlace permanente del pie de página: retirar o cambiar el consentimiento es tan fácil como darlo. */
export function CookieSettingsButton({ className }: { className?: string }) {
  return (
    <button type="button" className={className ?? 'text-sm text-muted underline hover:text-fg'} onClick={reopenConsentSettings}>
      Preferencias de cookies
    </button>
  );
}
