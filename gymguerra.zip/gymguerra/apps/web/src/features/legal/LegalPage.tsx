import { useMemo } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { LEGAL_DOCUMENTS, fillPlaceholders } from '@gymguerra/shared';
import { INFORMATIVE_EFFECTIVE_DATE, INFORMATIVE_VERSION, legalValues } from './legal-config';
import { LEGAL_PAGES, type LegalSlug } from './legal-content';

function longDate(iso: string): string {
  return new Date(`${iso}T00:00:00Z`).toLocaleDateString('es', { dateStyle: 'long', timeZone: 'UTC' });
}

interface Props {
  slug: LegalSlug;
  values?: Record<string, string>;
}

/**
 * Muestra un documento legal. El contenido se renderiza como Markdown seguro (sin HTML crudo).
 * En desarrollo avisa de los datos y notas de revisión que faltan; antes de publicar,
 * `npm run legal:check` debe pasar sin pendientes.
 */
export function LegalPage({ slug, values = legalValues }: Props) {
  const page = LEGAL_PAGES[slug];
  const info = page.doc ? LEGAL_DOCUMENTS[page.doc] : undefined;

  const filled = useMemo(
    () =>
      fillPlaceholders(page.source, {
        ...values,
        VERSION: info?.version ?? INFORMATIVE_VERSION,
        FECHA_VIGENCIA: longDate(info?.effectiveDate ?? INFORMATIVE_EFFECTIVE_DATE),
      }),
    [page.source, values, info],
  );

  const pending = filled.missing.length + filled.reviewNotes.length;

  return (
    <main className="mx-auto max-w-3xl px-4 py-10 text-fg">
      {import.meta.env.DEV && pending > 0 && (
        <aside role="status" className="mb-6 rounded-md border border-warn p-4 text-sm text-warn">
          <strong>Faltan datos por completar antes de publicar este documento.</strong>
          {filled.missing.length > 0 && <p>Datos: {filled.missing.join(', ')}.</p>}
          {filled.reviewNotes.length > 0 && <p>Notas de revisión pendientes: {filled.reviewNotes.length}.</p>}
        </aside>
      )}
      <article className="flex flex-col gap-3">
        <ReactMarkdown
          remarkPlugins={[remarkGfm]}
          components={{
            h1: (p) => <h1 className="font-display text-4xl font-bold uppercase" {...p} />,
            h2: (p) => <h2 className="mt-6 font-display text-2xl font-semibold uppercase" {...p} />,
            p: (p) => <p className="text-base leading-relaxed" {...p} />,
            ul: (p) => <ul className="list-disc space-y-1 pl-6" {...p} />,
            ol: (p) => <ol className="list-decimal space-y-1 pl-6" {...p} />,
            a: ({ href, ...p }) => (
              <a
                className="text-brand-text underline"
                href={href}
                {...(href?.startsWith('http') ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
                {...p}
              />
            ),
            table: (p) => (
              <div className="overflow-x-auto">
                <table className="w-full border-collapse text-left text-sm" {...p} />
              </div>
            ),
            th: (p) => <th className="border border-line bg-surface p-2 font-semibold" {...p} />,
            td: (p) => <td className="border border-line p-2 align-top" {...p} />,
            code: (p) => <code className="rounded bg-surface px-1" {...p} />,
          }}
        >
          {filled.text}
        </ReactMarkdown>
      </article>
    </main>
  );
}
