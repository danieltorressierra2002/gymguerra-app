import type { LegalDocumentType } from '@gymguerra/shared';
import avisoLegal from './content/aviso-legal.md?raw';
import cookies from './content/cookies.md?raw';
import privacidad from './content/privacidad.md?raw';
import terminos from './content/terminos.md?raw';
import tienda from './content/tienda.md?raw';

export type LegalSlug = 'privacidad' | 'cookies' | 'terminos' | 'tienda' | 'aviso-legal';

export interface LegalPageDef {
  title: string;
  source: string;
  /** Si el documento se acepta y se versiona (ver LEGAL_DOCUMENTS) */
  doc?: LegalDocumentType;
}

export const LEGAL_PAGES: Record<LegalSlug, LegalPageDef> = {
  privacidad: { title: 'Política de Privacidad', source: privacidad, doc: 'PRIVACY' },
  cookies: { title: 'Política de Cookies', source: cookies },
  terminos: { title: 'Términos y Condiciones de Uso', source: terminos, doc: 'TERMS' },
  tienda: { title: 'Condiciones de la Tienda', source: tienda, doc: 'STORE_TERMS' },
  'aviso-legal': { title: 'Aviso Legal', source: avisoLegal },
};

export { LEGAL_SLUG_BY_DOC } from './legal-config';
