import {
  CONSENT_COOKIE,
  CONSENT_MAX_AGE_SECONDS,
  parseConsent,
  serializeConsent,
  type ConsentState,
} from '@gymguerra/shared';

export const CONSENT_EVENT = 'gg-consent-change';
export const CONSENT_REOPEN_EVENT = 'gg-consent-reopen';

export function readConsent(now: Date = new Date()): ConsentState | null {
  const entry = document.cookie.split('; ').find((c) => c.startsWith(`${CONSENT_COOKIE}=`));
  return parseConsent(entry ? entry.slice(CONSENT_COOKIE.length + 1) : null, now);
}

/** Cookie propia y técnica; el resto de scripts deben leer esta decisión antes de cargarse. */
export function writeConsent(state: ConsentState): void {
  const secure = window.location.protocol === 'https:' ? '; Secure' : '';
  document.cookie = `${CONSENT_COOKIE}=${serializeConsent(state)}; Max-Age=${CONSENT_MAX_AGE_SECONDS}; Path=/; SameSite=Lax${secure}`;
  window.dispatchEvent(new Event(CONSENT_EVENT));
}

/** Abre de nuevo el panel para cambiar o retirar la elección. */
export function reopenConsentSettings(): void {
  window.dispatchEvent(new Event(CONSENT_REOPEN_EVENT));
}
