export { ConsentGate } from './ConsentGate';
export { CookieBanner, CookieSettingsButton } from './CookieBanner';
export { LegalLinks } from './LegalLinks';
export { LegalPage } from './LegalPage';
export { COOKIE_CONFIG, legalValues } from './legal-config';
export { readConsent } from './consent-storage';
export type { LegalSlug } from './legal-content';
