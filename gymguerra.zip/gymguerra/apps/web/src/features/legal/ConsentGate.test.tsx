import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { describe, expect, it, vi } from 'vitest';
import { ConsentGate } from './ConsentGate';

describe('ConsentGate', () => {
  it('no muestra nada si no hay documentos pendientes', () => {
    render(<ConsentGate pending={[]} onAccept={async () => {}} />);
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
  });

  it('enlaza cada documento pendiente y exige marcar la casilla', async () => {
    const onAccept = vi.fn(async () => {});
    render(<ConsentGate pending={['TERMS', 'PRIVACY']} onAccept={onAccept} />);

    expect(screen.getByRole('dialog')).toBeInTheDocument();
    expect(screen.getByRole('link', { name: /términos y condiciones/i })).toHaveAttribute('href', '/legal/terminos');
    expect(screen.getByRole('link', { name: /política de privacidad/i })).toHaveAttribute('href', '/legal/privacidad');

    const button = screen.getByRole('button', { name: 'Aceptar y continuar' });
    expect(button).toBeDisabled();
    await userEvent.click(screen.getByRole('checkbox'));
    expect(button).toBeEnabled();
    await userEvent.click(button);
    expect(onAccept).toHaveBeenCalledTimes(1);
  });

  it('pone el foco en la casilla al abrirse (teclado y lector de pantalla)', () => {
    render(<ConsentGate pending={['PRIVACY']} onAccept={async () => {}} />);
    expect(screen.getByRole('checkbox')).toHaveFocus();
  });

  it('si falla el registro muestra un error y no se cierra', async () => {
    render(<ConsentGate pending={['TERMS']} onAccept={async () => Promise.reject(new Error('red'))} />);
    await userEvent.click(screen.getByRole('checkbox'));
    await userEvent.click(screen.getByRole('button', { name: 'Aceptar y continuar' }));
    expect(await screen.findByRole('alert')).toHaveTextContent(/no pudimos registrar/i);
    expect(screen.getByRole('dialog')).toBeInTheDocument();
  });
});
