import type { LegalDocumentType, OptionalCategory } from '@gymguerra/shared';

/** Ruta (/legal/…) de cada documento que se acepta. Vive aquí para no cargar los textos completos. */
export const LEGAL_SLUG_BY_DOC: Record<LegalDocumentType, string> = {
  PRIVACY: 'privacidad',
  TERMS: 'terminos',
  STORE_TERMS: 'tienda',
};

/**
 * DATOS DEL GIMNASIO que se insertan en los documentos legales ({{CLAVE}}).
 * Complétalos antes de publicar: lo que quede vacío se muestra como «[COMPLETAR: CLAVE]»
 * y `npm run legal:check` falla mientras haya datos o notas pendientes.
 */
export const legalValues: Record<string, string> = {
  NOMBRE_COMERCIAL: 'Gimnasio Guerra',
  NOMBRE_LEGAL: '', // razón social o nombre completo del titular
  DOCUMENTO_FISCAL: '', // NIT, RUC, CIF... según el país
  DIRECCION: '',
  CORREO_CONTACTO: '',
  TELEFONO: '',
  SITIO_WEB: '',
  PAIS: 'Cuba',
  JURISDICCION: '', // p. ej. «los tribunales de La Habana»
  AUTORIDAD_DATOS: 'el Ministerio de Justicia', // [CONFIRMAR con un abogado] autoridad de protección de datos de la Ley 149/2022
  PLAZO_CONSERVACION_PAGOS: '', // p. ej. «durante 5 años»
  PROVEEDOR_ALOJAMIENTO: '', // proveedor cuyo servidor está EN CUBA (Resolución 58/2022, art. 7)
};

/** Fecha de vigencia de los documentos que no se aceptan con versión (cookies, aviso legal). */
export const INFORMATIVE_EFFECTIVE_DATE = '2026-11-21';
export const INFORMATIVE_VERSION = '1.0';

export const COOKIE_CONFIG: {
  /**
   * Categorías OPCIONALES que el sitio usa de verdad. Vacío = solo almacenamiento técnico:
   * se muestra un aviso informativo. Si añades analítica o publicidad, agrégalas aquí y
   * sus scripts solo deben cargarse con hasConsent(...) verdadero.
   */
  optionalInUse: OptionalCategory[];
  policyHref: string;
} = {
  optionalInUse: [],
  policyHref: '/legal/cookies',
};
