import { useEffect, useId, useRef, useState } from 'react';
import type { LegalDocumentType } from '@gymguerra/shared';
import { LEGAL_SLUG_BY_DOC } from './legal-config';

const NAMES: Record<LegalDocumentType, string> = {
  TERMS: 'los Términos y Condiciones',
  PRIVACY: 'la Política de Privacidad',
  STORE_TERMS: 'las Condiciones de la Tienda',
};

interface Props {
  /** Documentos pendientes: los devuelve GET /api/consents/me */
  pending: LegalDocumentType[];
  /** Debe llamar a POST /api/consents con las versiones vigentes y volver a cargar el estado */
  onAccept: () => Promise<void>;
}

/** Pantalla que se muestra tras iniciar sesión mientras haya documentos legales sin aceptar. */
export function ConsentGate({ pending, onAccept }: Props) {
  const titleId = useId();
  const checkId = useId();
  const [checked, setChecked] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const firstRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    firstRef.current?.focus();
  }, [pending.length]);

  if (pending.length === 0) return null;

  const accept = async () => {
    setBusy(true);
    setError(null);
    try {
      await onAccept();
    } catch {
      setError('No pudimos registrar tu aceptación. Inténtalo de nuevo.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-bg/80 p-4" role="presentation">
      <div role="dialog" aria-modal="true" aria-labelledby={titleId} className="w-full max-w-md rounded-lg bg-card p-6 text-fg shadow-pop">
        <h2 id={titleId} className="font-display text-2xl font-bold uppercase">
          Antes de continuar
        </h2>
        <p className="mt-2 text-sm text-muted">Para usar tu cuenta necesitamos que leas y aceptes estos documentos:</p>
        <ul className="mt-3 list-disc pl-5 text-sm">
          {pending.map((doc) => (
            <li key={doc}>
              <a className="text-brand-text underline" href={`/legal/${LEGAL_SLUG_BY_DOC[doc]}`} target="_blank" rel="noopener noreferrer">
                {NAMES[doc]}
              </a>
            </li>
          ))}
        </ul>
        <label htmlFor={checkId} className="mt-4 flex items-start gap-3 text-sm">
          <input
            id={checkId}
            ref={firstRef}
            type="checkbox"
            className="mt-1 h-5 w-5"
            checked={checked}
            onChange={(e) => setChecked(e.target.checked)}
          />
          <span>He leído y acepto {pending.map((d) => NAMES[d]).join(' y ')}.</span>
        </label>
        {error && (
          <p role="alert" className="mt-3 text-sm text-danger">
            {error}
          </p>
        )}
        <button
          type="button"
          disabled={!checked || busy}
          onClick={accept}
          className="mt-5 min-h-11 w-full rounded-md bg-brand px-5 text-sm font-semibold text-brand-on disabled:cursor-not-allowed disabled:opacity-50"
        >
          {busy ? 'Guardando…' : 'Aceptar y continuar'}
        </button>
      </div>
    </div>
  );
}
