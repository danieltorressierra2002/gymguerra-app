import { readdirSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import { legalValues } from './legal-config';

const dir = join(import.meta.dirname, 'content');
const files = readdirSync(dir).filter((f) => f.endsWith('.md'));
const AUTO = new Set(['VERSION', 'FECHA_VIGENCIA']);

describe('contenido legal', () => {
  it('hay un documento por cada página legal', () => {
    expect(files.sort()).toEqual(['aviso-legal.md', 'cookies.md', 'privacidad.md', 'terminos.md', 'tienda.md']);
  });

  for (const file of files) {
    const text = readFileSync(join(dir, file), 'utf8');

    it(`${file}: todos los {{DATOS}} existen en legal-config (sin errores de escritura)`, () => {
      const keys = [...text.matchAll(/\{\{([A-Z_]+)\}\}/g)].map((m) => m[1]!);
      const unknown = keys.filter((k) => !(k in legalValues) && !AUTO.has(k));
      expect(unknown).toEqual([]);
    });

    it(`${file}: empieza con un título y trae versión y fecha de vigencia`, () => {
      expect(text.startsWith('# ')).toBe(true);
      expect(text).toContain('{{VERSION}}');
      expect(text).toContain('{{FECHA_VIGENCIA}}');
    });

    it(`${file}: es una plantilla con notas de revisión pendientes (no se publica sin revisar)`, () => {
      expect(text).toMatch(/\[\[REVISAR:/);
    });
  }

  it('la política de privacidad cubre los derechos y la retención', () => {
    const text = readFileSync(join(dir, 'privacidad.md'), 'utf8');
    for (const word of ['Acceder', 'Rectificar', 'Cancelar', 'Oponerte', 'Cuánto tiempo los conservamos']) {
      expect(text).toContain(word);
    }
  });

  it('la privacidad cumple lo que exige la normativa cubana de datos en soporte electrónico', () => {
    const text = readFileSync(join(dir, 'privacidad.md'), 'utf8');
    expect(text).toContain('Ley 149/2022'); // base legal
    expect(text).toContain('servidores **ubicados en Cuba**'); // art. 7: alojamiento nacional
    expect(text).toContain('Dónde se guardan'); // art. 8 a): dónde se almacenan
    expect(text).toContain('Cuánto tiempo los conservamos'); // art. 8 a): plazo de conservación
    expect(text).toContain('Cookies y rastreo'); // art. 8 c): aviso de rastreo
    expect(text).toContain('3 meses de antelación'); // art. 8 d): aviso de cambios
    expect(text).toContain('incidente de ciberseguridad'); // art. 4 c): notificar incidentes
  });

  it('los términos también avisan los cambios con 3 meses de antelación', () => {
    expect(readFileSync(join(dir, 'terminos.md'), 'utf8')).toContain('3 meses de antelación');
  });

  it('no se exige edad mínima', () => {
    expect(readFileSync(join(dir, 'privacidad.md'), 'utf8')).toContain('No exigimos una edad mínima');
  });

  it('la política de cookies lista el almacenamiento real y la gestión del consentimiento', () => {
    const text = readFileSync(join(dir, 'cookies.md'), 'utf8');
    for (const word of ['gg_consent', 'Preferencias de cookies', 'Rechazar todas']) {
      expect(text).toContain(word);
    }
  });

  it('las condiciones de la tienda explican que no hay control automático de existencias', () => {
    const text = readFileSync(join(dir, 'tienda.md'), 'utf8');
    expect(text).toContain('no lleva un control automático de existencias');
    expect(text).toContain('íntegramente');
  });
});
