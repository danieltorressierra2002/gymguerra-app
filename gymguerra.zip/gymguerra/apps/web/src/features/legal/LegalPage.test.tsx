import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import { LegalPage } from './LegalPage';
import { LEGAL_PAGES, type LegalSlug } from './legal-content';

const complete = {
  NOMBRE_COMERCIAL: 'Gimnasio Guerra',
  NOMBRE_LEGAL: 'Guerra Fitness S.A.',
  DOCUMENTO_FISCAL: '123456',
  DIRECCION: 'Calle Falsa 123',
  CORREO_CONTACTO: 'legal@guerra.test',
  TELEFONO: '555-0000',
  SITIO_WEB: 'https://guerra.test',
  PAIS: 'Atlantis',
  JURISDICCION: 'los tribunales de Atlantis',
  AUTORIDAD_DATOS: 'la Agencia de Datos',
  PLAZO_CONSERVACION_PAGOS: 'durante 5 años',
  PROVEEDOR_ALOJAMIENTO: 'ProveedorX',
};

describe('LegalPage', () => {
  it('renderiza los cinco documentos con su título', () => {
    for (const slug of Object.keys(LEGAL_PAGES) as LegalSlug[]) {
      const { unmount } = render(<LegalPage slug={slug} values={complete} />);
      expect(screen.getByRole('heading', { level: 1 })).toHaveTextContent(LEGAL_PAGES[slug].title);
      unmount();
    }
  });

  it('inserta los datos del gimnasio y la versión', () => {
    render(<LegalPage slug="privacidad" values={complete} />);
    expect(screen.getAllByText(/Guerra Fitness S\.A\./).length).toBeGreaterThan(0);
    expect(screen.getByText(/Versión 1\.0/)).toBeInTheDocument();
  });

  it('con datos vacíos deja marcas visibles y avisa en desarrollo (nunca huecos silenciosos)', () => {
    render(<LegalPage slug="aviso-legal" values={{ NOMBRE_COMERCIAL: 'Gimnasio Guerra' }} />);
    expect(screen.getAllByText(/\[COMPLETAR: NOMBRE_LEGAL\]/).length).toBeGreaterThan(0);
    expect(screen.getByRole('status')).toHaveTextContent(/faltan datos por completar/i);
  });

  it('muestra las tablas (política de cookies)', () => {
    render(<LegalPage slug="cookies" values={complete} />);
    expect(screen.getByRole('table')).toBeInTheDocument();
    expect(screen.getByText('gg_consent')).toBeInTheDocument();
  });

  it('no ejecuta HTML incrustado en el contenido (Markdown seguro)', () => {
    render(<LegalPage slug="terminos" values={{ ...complete, NOMBRE_LEGAL: '<img src=x onerror=alert(1)>' }} />);
    expect(document.querySelector('img')).toBeNull();
  });

  it('los enlaces entre documentos apuntan a rutas internas', () => {
    render(<LegalPage slug="aviso-legal" values={complete} />);
    expect(screen.getByRole('link', { name: 'Política de Privacidad' })).toHaveAttribute('href', '/legal/privacidad');
  });
});
