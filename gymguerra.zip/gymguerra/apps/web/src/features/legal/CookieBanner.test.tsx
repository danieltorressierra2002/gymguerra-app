import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { describe, expect, it } from 'vitest';
import { CONSENT_COOKIE, parseConsent } from '@gymguerra/shared';
import { CookieBanner, CookieSettingsButton } from './CookieBanner';

const saved = () => {
  const entry = document.cookie.split('; ').find((c) => c.startsWith(`${CONSENT_COOKIE}=`));
  return parseConsent(entry ? entry.slice(CONSENT_COOKIE.length + 1) : null);
};

describe('CookieBanner: solo almacenamiento técnico (sin categorías opcionales)', () => {
  it('muestra un aviso informativo, sin botones de aceptar/rechazar', () => {
    render(<CookieBanner optionalInUse={[]} />);
    expect(screen.getByText(/únicamente almacenamiento técnico/i)).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: /aceptar todas/i })).not.toBeInTheDocument();
  });

  it('«Entendido» lo cierra y guarda que no hay nada opcional permitido', async () => {
    render(<CookieBanner optionalInUse={[]} />);
    await userEvent.click(screen.getByRole('button', { name: 'Entendido' }));
    expect(screen.queryByRole('region')).not.toBeInTheDocument();
    expect(saved()).toMatchObject({ preferences: false, analytics: false, marketing: false });
  });
});

describe('CookieBanner: con categorías opcionales', () => {
  const props = { optionalInUse: ['analytics', 'marketing'] as const };

  it('ofrece Aceptar, Rechazar y Configurar en la primera capa', () => {
    render(<CookieBanner optionalInUse={[...props.optionalInUse]} />);
    expect(screen.getByRole('button', { name: 'Aceptar todas' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Rechazar todas' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Configurar' })).toBeInTheDocument();
  });

  it('Rechazar tiene exactamente el mismo estilo que Aceptar (no está «escondido»)', () => {
    render(<CookieBanner optionalInUse={[...props.optionalInUse]} />);
    const accept = screen.getByRole('button', { name: 'Aceptar todas' });
    const reject = screen.getByRole('button', { name: 'Rechazar todas' });
    expect(reject.className).toBe(accept.className);
  });

  it('no guarda nada hasta que la persona decide', () => {
    render(<CookieBanner optionalInUse={[...props.optionalInUse]} />);
    expect(saved()).toBeNull();
  });

  it('Rechazar todas deja todo lo opcional apagado y oculta el aviso', async () => {
    render(<CookieBanner optionalInUse={[...props.optionalInUse]} />);
    await userEvent.click(screen.getByRole('button', { name: 'Rechazar todas' }));
    expect(saved()).toMatchObject({ analytics: false, marketing: false });
    expect(screen.queryByRole('region')).not.toBeInTheDocument();
  });

  it('Aceptar todas enciende todo', async () => {
    render(<CookieBanner optionalInUse={[...props.optionalInUse]} />);
    await userEvent.click(screen.getByRole('button', { name: 'Aceptar todas' }));
    expect(saved()).toMatchObject({ analytics: true, marketing: true });
  });

  it('Configurar muestra casillas apagadas (la técnica fija y deshabilitada) y guarda la selección', async () => {
    render(<CookieBanner optionalInUse={[...props.optionalInUse]} />);
    await userEvent.click(screen.getByRole('button', { name: 'Configurar' }));

    const analytics = screen.getByRole('checkbox', { name: /analítica/i });
    const marketing = screen.getByRole('checkbox', { name: /marketing/i });
    const technical = screen.getByRole('checkbox', { name: /técnicas/i });
    expect(analytics).not.toBeChecked();
    expect(marketing).not.toBeChecked();
    expect(technical).toBeChecked();
    expect(technical).toBeDisabled();

    await userEvent.click(analytics);
    await userEvent.click(screen.getByRole('button', { name: 'Guardar selección' }));
    expect(saved()).toMatchObject({ analytics: true, marketing: false });
  });

  it('una cookie corrupta se ignora y se vuelve a preguntar', () => {
    document.cookie = `${CONSENT_COOKIE}=%%%; Path=/`;
    render(<CookieBanner optionalInUse={[...props.optionalInUse]} />);
    expect(screen.getByRole('region')).toBeInTheDocument();
  });

  it('retirar el consentimiento es tan fácil como darlo: el enlace del pie reabre el panel con la elección actual', async () => {
    render(
      <>
        <CookieBanner optionalInUse={[...props.optionalInUse]} />
        <CookieSettingsButton />
      </>,
    );
    await userEvent.click(screen.getByRole('button', { name: 'Aceptar todas' }));
    expect(screen.queryByRole('region')).not.toBeInTheDocument();

    await userEvent.click(screen.getByRole('button', { name: 'Preferencias de cookies' }));
    const analytics = screen.getByRole('checkbox', { name: /analítica/i });
    expect(analytics).toBeChecked(); // muestra lo que había elegido

    await userEvent.click(analytics);
    await userEvent.click(screen.getByRole('button', { name: 'Guardar selección' }));
    expect(saved()).toMatchObject({ analytics: false, marketing: true });
  });
});
