# Condiciones de la Tienda

**Versión {{VERSION}} · Vigente desde {{FECHA_VIGENCIA}}**

[[REVISAR: esto es una plantilla. Debe revisarla un abogado de {{PAIS}} y ajustarla a la ley de consumo y de comercio electrónico locales.]]

Estas condiciones regulan las compras de productos que haces a **{{NOMBRE_LEGAL}}** ({{NOMBRE_COMERCIAL}}) a través de la tienda de la aplicación. Se suman a los [Términos y Condiciones de Uso](/legal/terminos).

## 1. Productos y precios

- Mostramos el precio y la moneda de cada producto. [[REVISAR: indica si los precios incluyen impuestos.]]
- El precio que pagas es el que aparece cuando haces el pedido; si luego lo cambiamos, tu pedido no se ve afectado.
- Las fotos son orientativas.

## 2. Disponibilidad

La tienda **no lleva un control automático de existencias**: el gimnasio retira de la tienda los productos que se agotan. Por eso, puede ocurrir que un producto que pediste ya no esté disponible. En ese caso te avisaremos, podrás cancelar el pedido y te devolveremos **íntegramente** lo que hayas pagado.

## 3. Cómo funciona un pedido

1. Eliges productos y confirmas el pedido, y aceptas estas condiciones.
2. El pedido queda **Pendiente** hasta que se registra tu pago.
3. Con el pago pasa a **Pagado**; luego **Preparado** y, al recogerlo, **Entregado**.
4. Puedes ver el estado de tus pedidos en tu cuenta.

## 4. Pago

Puedes pagar con los métodos que se te indiquen. Cada pago genera un recibo. No guardamos los datos de tu tarjeta.

## 5. Entrega

Los pedidos se entregan en el gimnasio. [[REVISAR: indica si hay envío a domicilio, plazos y costos.]]

## 6. Cancelaciones

- **Mientras el pedido esté Pendiente** puedes cancelarlo tú mismo desde tu cuenta, sin costo.
- **Si ya lo pagaste**, contáctanos en {{CORREO_CONTACTO}} para gestionarlo.

## 7. Devoluciones, cambios y garantía

[[REVISAR: define la política de devoluciones, cambios y garantía conforme a la ley de consumo de {{PAIS}}, incluidos los plazos, el estado del producto y las excepciones, por ejemplo suplementos o productos de higiene abiertos.]]

Esto no limita los derechos que la ley te reconozca como consumidor.

## 8. Tus datos

Usamos los datos de tus pedidos para gestionarlos y cumplir obligaciones legales, como explica la [Política de Privacidad](/legal/privacidad). Guardamos la fecha, la IP y la versión de estas condiciones que aceptaste al comprar.

## 9. Reclamaciones

Escríbenos a {{CORREO_CONTACTO}} o llama al {{TELEFONO}}. [[REVISAR: indica si existe libro o canal oficial de reclamaciones en {{PAIS}}.]]

## 10. Ley aplicable

Estas condiciones se rigen por las leyes de {{PAIS}}. Serán competentes {{JURISDICCION}}, sin perjuicio de tus derechos como consumidor.
