# Términos y Condiciones de Uso

**Versión {{VERSION}} · Vigente desde {{FECHA_VIGENCIA}}**

[[REVISAR: esto es una plantilla. Debe revisarla un abogado cubano y ajustarla a la normativa de protección al consumidor vigente antes de publicarla.]]

## 1. Quiénes somos y qué aceptas

Estos términos regulan el uso del sitio web, de la aplicación y de los servicios de **{{NOMBRE_LEGAL}}** ({{NOMBRE_COMERCIAL}}). Al crear tu cuenta o usar el servicio, aceptas estos términos y la [Política de Privacidad](/legal/privacidad).

## 2. Tu cuenta

- Los datos que nos des deben ser verdaderos y estar al día.
- Tu cuenta es personal: no la compartas. Eres responsable de lo que ocurra con ella.
- Creamos tu acceso sin contraseña: tú la defines con un enlace de un solo uso que te entrega el gimnasio.
- Avísanos de inmediato si sospechas que alguien más accede a tu cuenta.

## 3. Membresías

- **Planes.** Cada plan indica su precio, sus beneficios y su duración, que puede ser en **meses calendario** o en días.
- **Vencimiento.** La fecha de vencimiento es el último día en que tu membresía sigue vigente. Por ejemplo, un plan de 1 mes que empieza el 9 de noviembre vence el 9 de diciembre.
- **Estados.** La aplicación te muestra «Al día», «Por vencer» o «Vencido» como orientación. Son informativos: lo que vale es la fecha de vencimiento.
- **Renovación.** Renovar es una decisión tuya; no renovamos ni cobramos automáticamente. [[REVISAR: confirma si habrá cobro automático.]]
- **Pausas.** Puedes pedir pausar tu membresía; al reanudarla, el vencimiento se corre los días pausados. [[REVISAR: define condiciones, duración máxima y costos de las pausas.]]
- **Cancelación y reembolsos.** [[REVISAR: define la política de cancelación y reembolso de membresías conforme a la ley de consumo de {{PAIS}}.]]

## 4. Pagos

Puedes pagar en las formas que se te indiquen (efectivo, transferencia, tarjeta o en línea, cuando estén disponibles). Cada pago genera un recibo con número correlativo. [[REVISAR: indica si los precios incluyen impuestos.]]

## 5. Normas de uso

- Respeta al personal, a otros socios y las instalaciones y equipos.
- Sigue las indicaciones de los entrenadores y las normas internas del gimnasio.
- No uses la aplicación para fines ilícitos ni intentes acceder a datos de otras personas.
- Podemos suspender o dar de baja una cuenta que incumpla estas normas.

## 6. Tu salud y los riesgos

La actividad física implica riesgos. Al inscribirte declaras que estás en condiciones de practicarla. Si tienes dudas sobre tu salud, **consulta a un médico antes de empezar**. Los consejos de los entrenadores y los contenidos de la aplicación no sustituyen una valoración médica.

## 7. Responsabilidad

Respondemos de los daños que la ley nos obligue a cubrir. En lo demás, y en la medida que la ley de {{PAIS}} lo permita, no respondemos por daños indirectos, por pérdida de objetos personales ni por interrupciones del servicio ajenas a nuestro control. Esto no limita derechos que la ley no te permita renunciar. [[REVISAR: ajusta esta cláusula a la ley de consumo local.]]

## 8. Propiedad intelectual

El nombre, el logotipo, los diseños y los contenidos del sitio pertenecen a {{NOMBRE_LEGAL}} o a quienes nos los licencian. No puedes copiarlos ni usarlos sin permiso.

## 9. Cambios

Podemos actualizar estos términos. Te lo comunicaremos con al menos **3 meses de antelación** por los medios de contacto que nos diste (correo, mensaje o notificación en la aplicación), subiremos su versión y te pediremos aceptarlos de nuevo.

## 10. Ley aplicable y jurisdicción

Estos términos se rigen por las leyes de {{PAIS}}. Para cualquier conflicto serán competentes {{JURISDICCION}}, sin perjuicio de los derechos que la ley te reconozca como consumidor.

## 11. Contacto

{{NOMBRE_LEGAL}} · {{DIRECCION}} · {{CORREO_CONTACTO}} · {{TELEFONO}}
