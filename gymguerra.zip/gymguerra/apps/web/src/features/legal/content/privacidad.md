# Política de Privacidad

**Versión {{VERSION}} · Vigente desde {{FECHA_VIGENCIA}}**

[[REVISAR: esto es una plantilla. Debe revisarla un abogado cubano antes de publicarla, para confirmar que cumple la Ley 149/2022 de Protección de Datos Personales y la Resolución 58/2022 del Ministerio de Comunicaciones.]]

Esta política explica qué datos personales tratamos cuando usas el sitio y la aplicación de {{NOMBRE_COMERCIAL}}, para qué los usamos, dónde los guardamos, cuánto tiempo los conservamos y qué derechos tienes. La elaboramos conforme a la Ley 149/2022 «De Protección de Datos Personales» y a su normativa complementaria.

## 1. Quién es el responsable

El responsable del tratamiento de tus datos es **{{NOMBRE_LEGAL}}** (nombre comercial: {{NOMBRE_COMERCIAL}}), con documento fiscal {{DOCUMENTO_FISCAL}} y domicilio en {{DIRECCION}}, {{PAIS}}.

Puedes contactarnos en {{CORREO_CONTACTO}} o en el teléfono {{TELEFONO}}.

## 2. Qué datos tratamos y para qué

Te informamos del propósito en el momento en que te pedimos cada dato:

| Datos | Para qué los pedimos |
|---|---|
| Nombre y correo electrónico | Crear tu cuenta, que puedas entrar y enviarte avisos del servicio. Tu contraseña se guarda transformada con un algoritmo irreversible (hash) y nadie del gimnasio puede verla. |
| Documento de identidad, teléfono, dirección y fecha de nacimiento | Identificarte como socio y gestionar tu inscripción |
| Foto de perfil (opcional) | Reconocerte en el gimnasio. Puedes quitarla cuando quieras. |
| Nombre, teléfono y parentesco de tu contacto de emergencia | Avisar a esa persona si te ocurre algo en el gimnasio |
| Plan, fechas de inicio y vencimiento, pagos, método de pago y recibos | Gestionar tu membresía y cobrarla. No guardamos números de tarjeta. |
| Productos, cantidades, importes y estado de tus pedidos | Gestionar tus compras en la tienda |
| Dirección IP, navegador y fecha de acciones importantes | Seguridad del servicio y registro de cambios administrativos |
| Qué documentos legales aceptaste, en qué versión y cuándo | Poder demostrar tu aceptación |

**No pedimos datos de salud.** Si nos das el contacto de otra persona (emergencia), te pedimos que antes le informes de que nos lo has dado.

No vendemos tus datos ni los usamos para decisiones automatizadas que te afecten de forma significativa.

[[REVISAR: confirma con un abogado el fundamento legal de cada finalidad según la Ley 149/2022.]]

## 3. Dónde se guardan

Tus datos se guardan en servidores **ubicados en Cuba**, de {{PROVEEDOR_ALOJAMIENTO}}, y se hacen copias de respaldo para protegerlos de pérdidas. No los alojamos ni replicamos fuera del país, salvo los casos que prevea la ley.

[[REVISAR: antes de publicar, confirma que la base de datos y sus copias estén realmente en un servidor nacional (Resolución 58/2022, artículo 7).]]

## 4. Con quién los compartimos

Solo compartimos datos con quienes nos prestan un servicio necesario para atenderte, y únicamente los que ese servicio requiere:

| Quién | Para qué |
|---|---|
| Proveedor de alojamiento en Cuba ({{PROVEEDOR_ALOJAMIENTO}}) | Guardar la información de la aplicación |
| Pasarela de pago nacional, si se activa los pagos en línea | Procesar el pago |

[[REVISAR: deja en esta tabla solo los servicios que realmente uses.]]

También podemos comunicar datos a las autoridades cuando una ley nos obligue.

## 5. Cuánto tiempo los conservamos

- **Mientras tengas cuenta activa:** los datos de tu perfil, membresías y pedidos.
- **Tras tu baja o cuando pidas cancelar tus datos:** los eliminamos, salvo los que debamos conservar por razones legales o administrativas. Los datos de pagos y recibos, {{PLAZO_CONSERVACION_PAGOS}}.
- **Pruebas de aceptación de documentos:** el tiempo necesario para acreditar que los aceptaste.
- **Copias de respaldo:** se sobrescriben de forma periódica. [[REVISAR: indica cada cuánto.]]

Cuando termina el plazo, eliminamos o anonimizamos los datos.

## 6. Tus derechos

Puedes, en cualquier momento:

- **Acceder** a tus datos y saber para qué los usamos.
- **Rectificar y actualizar** los que sean inexactos o hayan cambiado.
- **Cancelar** (eliminar) tus datos cuando se haya cumplido su propósito, cuando lo estimes conveniente o cuando creas que se tratan de forma que vulnera tus derechos, salvo lo que debamos conservar por ley.
- **Oponerte** a ciertos usos de tus datos y pedir que no se divulguen.
- **Conocer las opciones de privacidad** del servicio y configurarlas.
- Recibir una **copia de tus datos**.

Para ejercerlos escribe a {{CORREO_CONTACTO}}, o descarga una copia desde tu perfil con la opción «Descargar mis datos». Procuraremos atenderte con la mayor brevedad y transparencia posibles. [[REVISAR: confirma que la opción «Descargar mis datos» exista en el panel antes de publicar.]]

Si no estás conforme con nuestra respuesta, puedes reclamar ante {{AUTORIDAD_DATOS}}. [[REVISAR: confirma la autoridad competente y el procedimiento de reclamación.]]

## 7. Seguridad

Protegemos tus datos con conexiones cifradas (HTTPS), contraseñas protegidas con hash, bloqueo tras intentos fallidos, acceso limitado por roles, registro de acciones administrativas y copias de respaldo. Mantenemos la confidencialidad e integridad de los datos y evitamos accesos, cambios o transferencias no autorizados. Si ocurre un incidente de ciberseguridad que afecte tus datos, lo notificaremos a las autoridades competentes y te informaremos a ti.

## 8. Menores de edad

No exigimos una edad mínima para inscribirse. Si eres menor de 18 años, tu madre, padre o tutor debe inscribirte y autorizar el tratamiento de tus datos.

## 9. Cookies y rastreo

No usamos elementos que rastreen tu actividad, ni propios ni de terceros. Solo usamos almacenamiento técnico necesario. Consulta los detalles en la [Política de Cookies](/legal/cookies).

## 10. Cambios en esta política

Si cambiamos esta política, te lo comunicaremos con al menos **3 meses de antelación** por los medios de contacto que nos diste (correo, mensaje o notificación en la aplicación), subiremos su versión y te pediremos que la aceptes de nuevo. La fecha de vigencia está al inicio.

## 11. Contacto

{{NOMBRE_LEGAL}} · {{DIRECCION}} · {{CORREO_CONTACTO}} · {{TELEFONO}}
