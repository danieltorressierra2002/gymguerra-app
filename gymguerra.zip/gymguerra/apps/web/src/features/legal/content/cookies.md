# Política de Cookies

**Versión {{VERSION}} · Vigente desde {{FECHA_VIGENCIA}}**

[[REVISAR: esta tabla debe coincidir con lo que realmente guarda el sitio publicado. Audítala con las herramientas del navegador antes de publicar.]]

## 1. Qué son

Las cookies y tecnologías parecidas (como el almacenamiento local del navegador) guardan pequeños datos en tu dispositivo. Algunas son imprescindibles para que el sitio funcione; otras sirven para medir su uso o para publicidad.

## 2. Qué usamos hoy

| Nombre | Tipo | Para qué sirve | Duración | ¿Necesita tu consentimiento? |
|---|---|---|---|---|
| `gg_consent` | Cookie propia | Recordar tu elección sobre cookies | 180 días | No (técnica) |
| `gg_rt` | Cookie propia (HttpOnly) | Mantener tu sesión iniciada y renovarla de forma segura | Hasta 30 días o hasta que cierres sesión | No (técnica) |
| `gg-theme` | Almacenamiento local propio | Recordar si prefieres tema claro u oscuro | Hasta que lo borres | No (preferencia que eliges tú) |
| `gg-cart` | Almacenamiento local propio | Guardar el contenido de tu carrito | Hasta que lo vacíes o termines la compra | No (técnica) |

**Actualmente no usamos cookies de analítica ni de publicidad ni ningún elemento que rastree tu actividad, propio o de terceros**, y no cargamos contenido de terceros (mapas, vídeos) que instale cookies. Si algún día lo hacemos, actualizaremos esta política y te pediremos permiso **antes** de activarlas.

## 3. Cómo gestionar tus preferencias

- En el pie de cada página encontrarás **«Preferencias de cookies»**: desde ahí puedes cambiar o retirar tu elección en cualquier momento, tan fácilmente como la diste.
- Puedes borrar o bloquear cookies desde los ajustes de tu navegador. Si bloqueas las técnicas, partes del sitio (como iniciar sesión o el carrito) dejarán de funcionar.

## 4. Cuando pidamos tu consentimiento

Si usamos cookies que no son imprescindibles, verás un aviso con las opciones **Aceptar todas**, **Rechazar todas** y **Configurar**. Rechazar es tan fácil como aceptar y ninguna casilla viene marcada de antemano. No instalamos esas cookies hasta que las aceptes. Guardamos tu elección durante 180 días y después te volveremos a preguntar.

## 5. Más información

Consulta nuestra [Política de Privacidad](/legal/privacidad) para saber cómo tratamos tus datos personales, o escríbenos a {{CORREO_CONTACTO}}.
