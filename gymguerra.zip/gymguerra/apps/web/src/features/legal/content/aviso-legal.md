# Aviso Legal

**Versión {{VERSION}} · Vigente desde {{FECHA_VIGENCIA}}**

[[REVISAR: plantilla. Un abogado de {{PAIS}} debe confirmar qué datos del titular son obligatorios en el sitio web.]]

## 1. Titular del sitio

- **Titular:** {{NOMBRE_LEGAL}}
- **Nombre comercial:** {{NOMBRE_COMERCIAL}}
- **Documento fiscal:** {{DOCUMENTO_FISCAL}}
- **Domicilio:** {{DIRECCION}}, {{PAIS}}
- **Correo:** {{CORREO_CONTACTO}}
- **Teléfono:** {{TELEFONO}}
- **Sitio web:** {{SITIO_WEB}}

## 2. Objeto

Este sitio y su aplicación permiten gestionar las membresías del gimnasio, consultar el estado de tu cuenta, ver pagos y comprar productos de la tienda.

## 3. Uso del sitio

Quien accede al sitio se compromete a usarlo conforme a la ley, a la buena fe y a estos textos legales, y a no dañar su funcionamiento ni acceder a datos de otras personas.

## 4. Propiedad intelectual e industrial

Los contenidos, diseños, logotipos y marcas del sitio pertenecen a {{NOMBRE_LEGAL}} o a terceros que nos los han licenciado. Queda prohibida su reproducción o distribución sin autorización.

## 5. Enlaces

Si enlazamos a sitios de terceros, no controlamos su contenido ni respondemos de él.

## 6. Exclusión de responsabilidad

Hacemos lo posible por que la información sea exacta y el servicio esté disponible, pero no garantizamos que no haya errores o interrupciones. No respondemos de daños derivados de causas ajenas a nuestro control, en la medida que la ley lo permita.

## 7. Documentos relacionados

- [Política de Privacidad](/legal/privacidad)
- [Política de Cookies](/legal/cookies)
- [Términos y Condiciones de Uso](/legal/terminos)
- [Condiciones de la Tienda](/legal/tienda)

## 8. Ley aplicable

Este aviso se rige por las leyes de {{PAIS}}. Serán competentes {{JURISDICCION}}.
