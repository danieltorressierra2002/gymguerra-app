import { CookieSettingsButton } from './CookieBanner';

const LINKS = [
  { href: '/legal/privacidad', label: 'Privacidad' },
  { href: '/legal/cookies', label: 'Cookies' },
  { href: '/legal/terminos', label: 'Términos' },
  { href: '/legal/tienda', label: 'Condiciones de la tienda' },
  { href: '/legal/aviso-legal', label: 'Aviso legal' },
] as const;

/** Pie de página legal: enlaces + acceso permanente a las preferencias de cookies. */
export function LegalLinks() {
  return (
    <nav aria-label="Información legal" className="flex flex-wrap items-center gap-x-4 gap-y-2 text-sm text-muted">
      {LINKS.map((l) => (
        <a key={l.href} className="underline hover:text-fg" href={l.href}>
          {l.label}
        </a>
      ))}
      <CookieSettingsButton />
    </nav>
  );
}
