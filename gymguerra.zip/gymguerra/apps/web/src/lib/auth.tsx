import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { api } from './api';
import type { Role, User } from './types';

interface AuthValue {
  status: 'loading' | 'anonymous' | 'authenticated';
  user: User | null;
  login: (email: string, password: string) => Promise<User>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<Pick<AuthValue, 'status' | 'user'>>({ status: 'loading', user: null });

  useEffect(() => {
    let alive = true;
    api.setOnSessionLost(() => setState({ status: 'anonymous', user: null }));
    api.restore().then((user) => {
      if (alive) setState(user ? { status: 'authenticated', user } : { status: 'anonymous', user: null });
    });
    return () => {
      alive = false;
      api.setOnSessionLost(null);
    };
  }, []);

  const login = useCallback(async (email: string, password: string) => {
    const user = await api.login(email, password);
    setState({ status: 'authenticated', user });
    return user;
  }, []);

  const logout = useCallback(async () => {
    await api.logout().catch(() => undefined);
    setState({ status: 'anonymous', user: null });
  }, []);

  const value = useMemo(() => ({ ...state, login, logout }), [state, login, logout]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth debe usarse dentro de <AuthProvider>');
  return ctx;
}

export const homePathFor = (role: Role) => (role === 'ADMIN' ? '/admin' : role === 'TRAINER' ? '/entrenador' : '/app');

/** Protege rutas: sin sesión → login; con otro rol → a su propio panel. */
export function RequireRole({ roles, children }: { roles: Role[]; children: ReactNode }) {
  const { status, user } = useAuth();
  const location = useLocation();
  if (status === 'loading') return <div role="status" className="p-8 text-muted">Cargando…</div>;
  if (!user) return <Navigate to="/login" replace state={{ from: location.pathname }} />;
  if (!roles.includes(user.role)) return <Navigate to={homePathFor(user.role)} replace />;
  return <>{children}</>;
}
