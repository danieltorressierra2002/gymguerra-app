import { useEffect, useState } from 'react';

/** Devuelve `value` con retraso: evita una petición por cada tecla al buscar. */
export function useDebounced<T>(value: T, ms = 300): T {
  const [v, setV] = useState(value);
  useEffect(() => {
    const t = window.setTimeout(() => setV(value), ms);
    return () => window.clearTimeout(t);
  }, [value, ms]);
  return v;
}
