import type { User } from './types';

export class ApiError extends Error {
  constructor(
    public status: number,
    public code: string,
    message: string,
    public details?: unknown,
  ) {
    super(message);
    this.name = 'ApiError';
  }
}

type Query = Record<string, string | number | boolean | null | undefined>;
export interface RequestOptions { method?: string; body?: unknown; query?: Query; auth?: boolean }

/**
 * Cliente de la API con sesión segura:
 *  - El token de acceso (15 min) vive SOLO en memoria: no se guarda en localStorage ni cookies legibles,
 *    así un script malicioso no puede robarlo del almacenamiento.
 *  - Si caduca, se renueva solo con la cookie HttpOnly y se repite la petición una vez.
 *  - Varias peticiones a la vez comparten UNA renovación (el token de renovación rota en cada uso).
 */
export function createApiClient(opts: { baseUrl?: string } = {}) {
  const base = opts.baseUrl ?? import.meta.env?.VITE_API_URL ?? '/api';
  let token: string | null = null;
  let refreshing: Promise<boolean> | null = null;
  let onSessionLost: (() => void) | null = null;

  function url(path: string, query?: Query) {
    const qs = new URLSearchParams();
    for (const [k, v] of Object.entries(query ?? {})) if (v !== undefined && v !== null && v !== '') qs.set(k, String(v));
    const s = qs.toString();
    return `${base}${path}${s ? `?${s}` : ''}`;
  }

  async function send(path: string, o: RequestOptions, withToken: boolean): Promise<Response> {
    const headers: Record<string, string> = { Accept: 'application/json' };
    if (o.body !== undefined) headers['Content-Type'] = 'application/json';
    if (withToken && token) headers.Authorization = `Bearer ${token}`;
    try {
      return await fetch(url(path, o.query), {
        method: o.method ?? 'GET',
        headers,
        credentials: 'include',
        body: o.body !== undefined ? JSON.stringify(o.body) : undefined,
      });
    } catch {
      throw new ApiError(0, 'NETWORK', 'No hay conexión con el servidor. Revisa tu red e inténtalo de nuevo.');
    }
  }

  async function parse<T>(res: Response): Promise<T> {
    if (res.status === 204) return undefined as T;
    const isJson = res.headers.get('content-type')?.includes('application/json');
    const data = isJson ? await res.json().catch(() => null) : null;
    if (!res.ok) {
      const e = data?.error;
      throw new ApiError(res.status, e?.code ?? 'ERROR', e?.message ?? `Error ${res.status}`, e?.details);
    }
    return data as T;
  }

  async function doRefresh(): Promise<boolean> {
    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        const body = await parse<{ data: { accessToken: string } }>(await send('/auth/refresh', { method: 'POST' }, false));
        token = body.data.accessToken;
        return true;
      } catch (e) {
        // Otra pestaña renovó justo antes: su cookie nueva ya está disponible, se reintenta una vez
        if (e instanceof ApiError && e.code === 'REFRESH_RETRY' && attempt === 0) {
          await new Promise((r) => setTimeout(r, 400));
          continue;
        }
        break;
      }
    }
    token = null;
    return false;
  }

  function refreshOnce(): Promise<boolean> {
    refreshing ??= doRefresh().finally(() => {
      refreshing = null;
    });
    return refreshing;
  }

  async function request<T>(path: string, o: RequestOptions = {}): Promise<T> {
    const auth = o.auth !== false;
    let res = await send(path, o, auth);
    if (auth && res.status === 401) {
      if (await refreshOnce()) res = await send(path, o, true);
      else onSessionLost?.();
    }
    return parse<T>(res);
  }

  return {
    request,
    get: <T>(path: string, query?: Query) => request<T>(path, { query }),
    post: <T>(path: string, body?: unknown) => request<T>(path, { method: 'POST', body: body ?? {} }),
    patch: <T>(path: string, body: unknown) => request<T>(path, { method: 'PATCH', body }),
    put: <T>(path: string, body: unknown) => request<T>(path, { method: 'PUT', body }),
    del: <T>(path: string) => request<T>(path, { method: 'DELETE' }),

    /** Al abrir la página: si la cookie de sesión sigue vigente, recupera el usuario sin pedir la contraseña. */
    async restore(): Promise<User | null> {
      if (!(await refreshOnce())) return null;
      try {
        return (await request<{ data: User }>('/account/me')).data;
      } catch {
        token = null;
        return null;
      }
    },
    async login(email: string, password: string): Promise<User> {
      const res = await parse<{ data: { accessToken: string; user: User } }>(
        await send('/auth/login', { method: 'POST', body: { email, password } }, false),
      );
      token = res.data.accessToken;
      return res.data.user;
    },
    async logout(): Promise<void> {
      try {
        await parse(await send('/auth/logout', { method: 'POST' }, false));
      } finally {
        token = null;
      }
    },
    setOnSessionLost(fn: (() => void) | null) {
      onSessionLost = fn;
    },
    /** Olvida la sesión en memoria (se usa al cerrar sesión y en las pruebas). */
    reset() {
      token = null;
      refreshing = null;
      onSessionLost = null;
    },
  };
}

export type ApiClient = ReturnType<typeof createApiClient>;
export const api = createApiClient();
