export type Role = 'ADMIN' | 'TRAINER' | 'MEMBER';
export interface User { id: string; name: string; email: string; role: Role; memberId?: string | null; trainerId?: string | null }
export interface Paged<T> { items: T[]; total: number; page: number; pageSize: number }
export type SemaforoState = 'OK' | 'EXPIRING' | 'EXPIRED' | 'FROZEN' | 'CANCELLED';
export interface Semaforo { state: SemaforoState; daysLeft: number | null }
export type PaymentMethod = 'CASH' | 'TRANSFER' | 'CARD' | 'ONLINE';
export type OrderStatus = 'PENDING' | 'PAID' | 'PREPARED' | 'DELIVERED' | 'CANCELLED';

export interface Membership {
  id: string; memberId: string; planId: string; status: 'ACTIVE' | 'FROZEN' | 'CANCELLED';
  startDate: string; endDate: string; priceSnapshot: string; currency: string; semaforo: Semaforo;
  plan: { id: string; name: string };
}
export interface MemberRow {
  id: string; documentId: string; phone: string | null; address: string | null; birthDate: string | null;
  emergencyContactName: string | null; emergencyContactPhone: string | null; emergencyContactRelation: string | null;
  notes?: string | null; photoUrl: string | null;
  user: { name: string; email: string; status: string };
  currentMembership: { id: string; plan: string; status: string; startDate: string; endDate: string; semaforo: Semaforo } | null;
}
export interface Plan {
  id: string; name: string; description: string | null; price: string; currency: string;
  duration: { months: number } | { days: number }; benefits: string[]; includesTrainer: boolean; isActive: boolean; sortOrder: number;
}
export interface Category { id: string; name: string; slug: string; isActive?: boolean }
export interface Product {
  id: string; name: string; slug: string; description: string | null; price: string; currency: string; imageUrl: string | null;
  category: { name: string; slug: string; id?: string }; categoryId?: string; sku?: string | null; isActive?: boolean;
}
export interface Payment {
  id: string; receiptNumber: number; amount: string; currency: string; method: PaymentMethod;
  status: 'PENDING' | 'PAID' | 'FAILED' | 'REFUNDED' | 'VOID'; paidAt: string | null;
  membership: { id: string; plan: { name: string } } | null; order: { id: string; orderNumber: number } | null;
}
export interface Receipt {
  receiptNumber: number; issuedAt: string; customer: { name: string | null; documentId: string | null };
  concept: string; amount: string; currency: string; method: PaymentMethod;
}
export interface OrderItem { id: string; productId: string; nameSnapshot: string; unitPrice: string; quantity: number; lineTotal: string }
export interface Order {
  id: string; orderNumber: number; status: OrderStatus; currency: string; total: string; notes: string | null; createdAt: string;
  items: OrderItem[]; member?: { id: string; documentId: string; user: { name: string } };
}
export interface Summary {
  asOf: string; warningDays: number;
  members: { total: number; ok: number; expiring: number; expired: number; frozen: number; withoutMembership: number };
  attention: Array<{ memberId: string; name: string; membershipId: string; plan: string; endDate: string; state: SemaforoState; daysLeft: number | null }>;
  revenue: { months: string[]; series: Array<{ month: string; currency: string; total: string }> };
  orders: { pendingPayment: number; toPrepare: number };
}
