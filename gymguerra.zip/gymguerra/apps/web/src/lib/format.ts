import { ApiError } from './api';

const DATE_OPTS: Intl.DateTimeFormatOptions = { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' };

/** «2026-12-09» → «9 de diciembre de 2026» (las fechas de membresía no llevan hora). */
export const formatDate = (iso: string) => new Date(`${iso}T00:00:00Z`).toLocaleDateString('es', DATE_OPTS);
export const formatShortDate = (iso: string) =>
  new Date(`${iso}T00:00:00Z`).toLocaleDateString('es', { day: 'numeric', month: 'short', timeZone: 'UTC' });
export const formatDateTime = (iso: string) =>
  new Date(iso).toLocaleString('es', { dateStyle: 'medium', timeStyle: 'short' });

/** Dinero en céntimos enteros: evita errores de coma flotante al sumar. */
export function toCents(amount: string): number {
  const [i = '0', d = ''] = amount.split('.');
  return parseInt(i, 10) * 100 + parseInt((d + '00').slice(0, 2), 10);
}
export const fromCents = (c: number) => `${Math.trunc(c / 100)}.${String(c % 100).padStart(2, '0')}`;

export function formatMoney(amount: string | number, currency: string): string {
  try {
    return new Intl.NumberFormat('es', { style: 'currency', currency }).format(Number(amount));
  } catch {
    return `${amount} ${currency}`;
  }
}

export const METHOD_LABELS = { CASH: 'Efectivo', TRANSFER: 'Transferencia', CARD: 'Tarjeta', ONLINE: 'En línea' } as const;
export const ORDER_LABELS = {
  PENDING: 'Pendiente de pago', PAID: 'Pagado', PREPARED: 'Preparado', DELIVERED: 'Entregado', CANCELLED: 'Cancelado',
} as const;

/** Mensaje legible para mostrar al usuario a partir de cualquier error. */
export function errorText(e: unknown): string {
  if (e instanceof ApiError) {
    if (e.code === 'VALIDATION_ERROR' && Array.isArray(e.details)) {
      return (e.details as Array<{ path: string; message: string }>)
        .map((d) => (d.path ? `${d.path}: ${d.message}` : d.message))
        .join(' · ');
    }
    if (e.code === 'WEAK_PASSWORD' && e.details && typeof e.details === 'object' && 'problems' in e.details) {
      return (e.details as { problems: string[] }).problems.join(' ');
    }
    return e.message;
  }
  return 'Ocurrió un error inesperado. Inténtalo de nuevo.';
}

export function uuid(): string {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) return crypto.randomUUID();
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    return (c === 'x' ? r : (r & 3) | 8).toString(16);
  });
}
