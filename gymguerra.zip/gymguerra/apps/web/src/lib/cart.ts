import { fromCents, toCents } from './format';

/** Carrito en el navegador (clave «gg-cart», declarada en la política de cookies). El servidor recalcula los precios. */
export interface CartLine { productId: string; name: string; price: string; currency: string; quantity: number; imageUrl: string | null }
export const MAX_QTY = 20;
export const CART_KEY = 'gg-cart';

export function addToCart(lines: CartLine[], p: Omit<CartLine, 'quantity'>): { lines: CartLine[]; error?: string } {
  if (lines.length > 0 && lines[0]!.currency !== p.currency) {
    return { lines, error: 'No puedes mezclar productos de distintas monedas en un mismo pedido.' };
  }
  const found = lines.find((l) => l.productId === p.productId);
  if (found) {
    return { lines: lines.map((l) => (l === found ? { ...l, quantity: Math.min(MAX_QTY, l.quantity + 1) } : l)) };
  }
  return { lines: [...lines, { ...p, quantity: 1 }] };
}

export function setQuantity(lines: CartLine[], productId: string, quantity: number): CartLine[] {
  if (quantity <= 0) return lines.filter((l) => l.productId !== productId);
  return lines.map((l) => (l.productId === productId ? { ...l, quantity: Math.min(MAX_QTY, quantity) } : l));
}

export function cartTotal(lines: CartLine[]): { total: string; currency: string | null } {
  const cents = lines.reduce((sum, l) => sum + toCents(l.price) * l.quantity, 0);
  return { total: fromCents(cents), currency: lines[0]?.currency ?? null };
}

export function loadCart(storage: Pick<Storage, 'getItem'> = localStorage): CartLine[] {
  try {
    const raw: unknown = JSON.parse(storage.getItem(CART_KEY) ?? '[]');
    if (!Array.isArray(raw)) return [];
    return raw.filter(
      (l): l is CartLine =>
        !!l && typeof l.productId === 'string' && typeof l.name === 'string' && /^\d+(\.\d{1,2})?$/.test(String(l.price)) &&
        typeof l.currency === 'string' && Number.isInteger(l.quantity) && l.quantity >= 1 && l.quantity <= MAX_QTY,
    );
  } catch {
    return [];
  }
}

export function saveCart(lines: CartLine[], storage: Pick<Storage, 'setItem' | 'removeItem'> = localStorage) {
  try {
    if (lines.length === 0) storage.removeItem(CART_KEY);
    else storage.setItem(CART_KEY, JSON.stringify(lines));
  } catch {
    /* almacenamiento no disponible: el carrito sigue funcionando en memoria */
  }
}
