import { describe, expect, it, vi } from 'vitest';
import { ApiError, createApiClient } from './api';
import { err, mockFetch } from '../test-utils';

const ok = (data: unknown = {}) => ({ body: { data } });
const user = { id: 'u1', name: 'Ana', email: 'ana@x.cu', role: 'MEMBER' };

describe('cliente de la API', () => {
  it('guarda el token solo en memoria: nada en localStorage, sessionStorage ni cookies', async () => {
    mockFetch((c) => (c.path === '/auth/login' ? ok({ accessToken: 'SECRETO-123', user }) : ok()));
    const api = createApiClient();
    await api.login('ana@x.cu', 'clave');
    expect(JSON.stringify({ ...localStorage })).not.toContain('SECRETO-123');
    expect(JSON.stringify({ ...sessionStorage })).not.toContain('SECRETO-123');
    expect(document.cookie).not.toContain('SECRETO-123');
  });

  it('envía el token en la cabecera y la cookie de sesión con credentials: include', async () => {
    const calls = mockFetch((c) => (c.path === '/auth/login' ? ok({ accessToken: 'abc', user }) : ok({ ok: true })));
    const api = createApiClient();
    await api.login('ana@x.cu', 'clave');
    await api.get('/members/me');
    expect(calls[1]?.headers.Authorization).toBe('Bearer abc');
    expect(calls[1]?.credentials).toBe('include');
  });

  it('no manda token al iniciar sesión ni al crear la contraseña', async () => {
    const calls = mockFetch(() => ok({ accessToken: 'abc', user }));
    const api = createApiClient();
    await api.login('ana@x.cu', 'clave');
    await api.request('/auth/set-password', { method: 'POST', body: {}, auth: false });
    expect(calls.every((c) => !c.headers.Authorization)).toBe(true);
  });

  it('si el token caducó, renueva UNA vez y repite la petición', async () => {
    let token = 'viejo';
    const calls = mockFetch((c) => {
      if (c.path === '/auth/refresh') { token = 'nuevo'; return ok({ accessToken: 'nuevo' }); }
      if (c.path === '/datos') return c.headers.Authorization === 'Bearer nuevo' ? ok({ v: 1 }) : err(401, 'INVALID_TOKEN');
      return ok({ accessToken: 'viejo', user });
    });
    const api = createApiClient();
    await api.login('ana@x.cu', 'clave');
    expect(await api.get('/datos')).toEqual({ data: { v: 1 } });
    expect(calls.filter((c) => c.path === '/auth/refresh')).toHaveLength(1);
    expect(token).toBe('nuevo');
  });

  it('varias peticiones a la vez comparten una sola renovación (el token rota en cada uso)', async () => {
    const calls = mockFetch((c) => {
      if (c.path === '/auth/refresh') return ok({ accessToken: 'nuevo' });
      if (c.path === '/auth/login') return ok({ accessToken: 'viejo', user });
      return c.headers.Authorization === 'Bearer nuevo' ? ok({ v: 1 }) : err(401, 'INVALID_TOKEN');
    });
    const api = createApiClient();
    await api.login('ana@x.cu', 'clave');
    await Promise.all([api.get('/a'), api.get('/b'), api.get('/c')]);
    expect(calls.filter((c) => c.path === '/auth/refresh')).toHaveLength(1);
  });

  it('si no se puede renovar, avisa de que se perdió la sesión', async () => {
    mockFetch((c) => (c.path === '/auth/login' ? ok({ accessToken: 'viejo', user }) : err(401, c.path === '/auth/refresh' ? 'INVALID_SESSION' : 'INVALID_TOKEN')));
    const api = createApiClient();
    const lost = vi.fn();
    api.setOnSessionLost(lost);
    await api.login('ana@x.cu', 'clave');
    await expect(api.get('/datos')).rejects.toMatchObject({ status: 401 });
    expect(lost).toHaveBeenCalledTimes(1);
  });

  it('si otra pestaña renovó a la vez (REFRESH_RETRY), reintenta una vez', async () => {
    let tries = 0;
    mockFetch((c) => {
      if (c.path === '/auth/refresh') return ++tries === 1 ? err(401, 'REFRESH_RETRY') : ok({ accessToken: 'nuevo' });
      return ok({ id: 'u1' });
    });
    const api = createApiClient();
    vi.useFakeTimers();
    const p = api.restore();
    await vi.advanceTimersByTimeAsync(500);
    const result = await p;
    vi.useRealTimers();
    expect(result).toEqual({ id: 'u1' });
    expect(tries).toBe(2);
  });

  it('restore: sin cookie de sesión devuelve null', async () => {
    mockFetch(() => err(401, 'INVALID_SESSION'));
    expect(await createApiClient().restore()).toBeNull();
  });

  it('traduce errores del servidor, de red y respuestas sin contenido', async () => {
    mockFetch((c) => {
      if (c.path === '/boom') return err(409, 'CONFLICT', 'Ya existe', { x: 1 });
      if (c.path === '/vacio') return { status: 204 };
      return ok();
    });
    const api = createApiClient();
    await expect(api.request('/boom', { auth: false })).rejects.toMatchObject({ status: 409, code: 'CONFLICT', message: 'Ya existe', details: { x: 1 } });
    expect(await api.request('/vacio', { auth: false })).toBeUndefined();

    vi.stubGlobal('fetch', vi.fn(async () => { throw new TypeError('fallo'); }));
    await expect(api.request('/x', { auth: false })).rejects.toBeInstanceOf(ApiError);
    await expect(api.request('/x', { auth: false })).rejects.toMatchObject({ code: 'NETWORK' });
  });

  it('arma la consulta sin parámetros vacíos', async () => {
    const calls = mockFetch(() => ok());
    await createApiClient().get('/members', { q: 'ana', page: 2, vacio: '', nulo: null, indef: undefined });
    expect(calls[0]?.url).toBe('/api/members?q=ana&page=2');
  });
});
