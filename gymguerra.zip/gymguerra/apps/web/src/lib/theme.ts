export type Theme = 'dark' | 'light';
export const THEME_KEY = 'gg-theme';

export function getTheme(): Theme {
  try {
    return localStorage.getItem(THEME_KEY) === 'light' ? 'light' : 'dark'; // oscuro por defecto
  } catch {
    return 'dark';
  }
}

export function applyTheme(theme: Theme) {
  document.documentElement.dataset.theme = theme;
  try {
    localStorage.setItem(THEME_KEY, theme);
  } catch {
    /* sin almacenamiento: el tema vale solo para esta visita */
  }
}
