import { describe, expect, it } from 'vitest';
import { CART_KEY, MAX_QTY, addToCart, cartTotal, loadCart, saveCart, setQuantity, type CartLine } from './cart';
import { errorText, formatMoney, fromCents, toCents } from './format';
import { ApiError } from './api';

const p = (id: string, price = '4.50', currency = 'USD') => ({ productId: id, name: `Producto ${id}`, price, currency, imageUrl: null });
const store = () => {
  const m = new Map<string, string>();
  return { getItem: (k: string) => m.get(k) ?? null, setItem: (k: string, v: string) => void m.set(k, v), removeItem: (k: string) => void m.delete(k), m };
};

describe('dinero', () => {
  it('convierte a céntimos enteros sin errores de coma flotante', () => {
    expect(toCents('4.50')).toBe(450);
    expect(toCents('0.1') + toCents('0.2')).toBe(30);
    expect(toCents('12')).toBe(1200);
    expect(fromCents(30)).toBe('0.30');
    expect(fromCents(1205)).toBe('12.05');
  });

  it('da formato de moneda en español y no falla con monedas raras', () => {
    expect(formatMoney('4.5', 'USD')).toMatch(/4,50/);
    expect(formatMoney('10', 'CUP')).toContain('10');
    expect(formatMoney('10', 'xx')).toBe('10 xx');
  });
});

describe('carrito', () => {
  it('suma unidades y respeta el máximo por producto', () => {
    let lines: CartLine[] = [];
    for (let i = 0; i < MAX_QTY + 5; i++) lines = addToCart(lines, p('a')).lines;
    expect(lines).toHaveLength(1);
    expect(lines[0]?.quantity).toBe(MAX_QTY);
  });

  it('no mezcla monedas en un mismo pedido', () => {
    const first = addToCart([], p('a', '4.50', 'USD')).lines;
    const second = addToCart(first, p('b', '100', 'CUP'));
    expect(second.error).toMatch(/monedas/);
    expect(second.lines).toEqual(first);
  });

  it('cantidad 0 quita la línea y el total es exacto', () => {
    let lines = addToCart(addToCart([], p('a', '0.10')).lines, p('b', '0.20')).lines;
    expect(cartTotal(lines)).toEqual({ total: '0.30', currency: 'USD' });
    lines = setQuantity(lines, 'a', 0);
    expect(lines.map((l) => l.productId)).toEqual(['b']);
    expect(cartTotal([])).toEqual({ total: '0.00', currency: null });
  });

  it('guarda y recupera el carrito; sin líneas borra la clave', () => {
    const s = store();
    const lines = addToCart([], p('a')).lines;
    saveCart(lines, s);
    expect(s.m.has(CART_KEY)).toBe(true);
    expect(loadCart(s)).toEqual(lines);
    saveCart([], s);
    expect(s.m.has(CART_KEY)).toBe(false);
  });

  it('descarta datos corruptos o manipulados del almacenamiento', () => {
    const s = store();
    s.setItem(CART_KEY, 'no es json');
    expect(loadCart(s)).toEqual([]);
    s.setItem(CART_KEY, JSON.stringify([{ productId: 'a', name: 'X', price: '-5', currency: 'USD', quantity: 1 }, { productId: 'b', name: 'Y', price: '3.00', currency: 'USD', quantity: 999 }, p('ok')]));
    expect(loadCart(s)).toEqual([]);
    s.setItem(CART_KEY, JSON.stringify([{ ...p('ok'), quantity: 2 }]));
    expect(loadCart(s)).toHaveLength(1);
  });
});

describe('mensajes de error', () => {
  it('muestra los problemas de la contraseña y los de validación de forma legible', () => {
    expect(errorText(new ApiError(400, 'WEAK_PASSWORD', 'x', { problems: ['Es demasiado común.', 'Muy corta.'] }))).toBe('Es demasiado común. Muy corta.');
    expect(errorText(new ApiError(400, 'VALIDATION_ERROR', 'x', [{ path: 'price', message: 'Monto inválido' }]))).toBe('price: Monto inválido');
    expect(errorText(new ApiError(409, 'CONFLICT', 'Ya existe'))).toBe('Ya existe');
    expect(errorText(new Error('interno secreto'))).not.toContain('secreto');
  });
});
