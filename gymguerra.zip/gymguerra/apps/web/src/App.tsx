import { lazy, Suspense, type ReactNode } from 'react';
import { Link, Navigate, Route, Routes } from 'react-router-dom';
import { AppShell, type NavItem } from './components/Shell';
import { ErrorBox, Loading, ToastProvider } from './components/ui';
import { ConsentGate, CookieBanner } from './features/legal';
import { api } from './lib/api';
import { AuthProvider, RequireRole, homePathFor, useAuth } from './lib/auth';
import type { Role } from './lib/types';
import { useAsync } from './lib/useAsync';
import { AdminDashboard } from './pages/admin/Dashboard';
import { MemberDetailPage } from './pages/admin/MemberDetail';
import { MembersPage } from './pages/admin/Members';
import { AdminOrders } from './pages/admin/Orders';
import { AdminPlans } from './pages/admin/Plans';
import { AdminProducts } from './pages/admin/Products';
import { AdminSettings } from './pages/admin/Settings';
import { ClientHome } from './pages/client/Home';
import { ClientOrders } from './pages/client/MyOrders';
import { ClientPayments } from './pages/client/Payments';
import { ClientProfile } from './pages/client/Profile';
import { ClientStore } from './pages/client/Store';
import { CreatePassword } from './pages/CreatePassword';
import { Login } from './pages/Login';
import type { LegalDocumentType } from '@gymguerra/shared';

const CLIENT_NAV: NavItem[] = [
  { to: '/app', label: 'Inicio', icon: 'home', end: true },
  { to: '/app/pagos', label: 'Pagos', icon: 'card' },
  { to: '/app/tienda', label: 'Tienda', icon: 'bag' },
  { to: '/app/perfil', label: 'Perfil', icon: 'user' },
];
const ADMIN_NAV: NavItem[] = [
  { to: '/admin', label: 'Resumen', icon: 'home', end: true },
  { to: '/admin/miembros', label: 'Miembros', icon: 'users' },
  { to: '/admin/planes', label: 'Planes', icon: 'ticket' },
  { to: '/admin/productos', label: 'Tienda', icon: 'box' },
  { to: '/admin/pedidos', label: 'Pedidos', icon: 'list' },
  { to: '/admin/ajustes', label: 'Ajustes', icon: 'settings' },
];
const TRAINER_NAV: NavItem[] = [{ to: '/entrenador/miembros', label: 'Clientes', icon: 'users' }];

interface ConsentStatus { current: Record<LegalDocumentType, { version: string }>; pending: LegalDocumentType[] }

/** Tras iniciar sesión: mientras haya documentos legales sin aceptar, solo se muestra la pantalla de aceptación. */
function ConsentGuard({ children }: { children: ReactNode }) {
  const state = useAsync(() => api.get<{ data: ConsentStatus }>('/consents/me'), []);
  if (state.data === undefined) return state.error ? <div className="p-4"><ErrorBox error={state.error} retry={state.reload} /></div> : <Loading />;
  const { pending, current } = state.data.data;
  if (pending.length > 0) {
    return (
      <ConsentGate pending={pending} onAccept={async () => {
        await api.post('/consents', { documents: pending.map((type) => ({ type, version: current[type].version })) });
        state.reload();
      }} />
    );
  }
  return <>{children}</>;
}

function Protected({ roles, nav, roleLabel }: { roles: Role[]; nav: NavItem[]; roleLabel: string }) {
  return (
    <RequireRole roles={roles}>
      <ConsentGuard><AppShell nav={nav} roleLabel={roleLabel} /></ConsentGuard>
    </RequireRole>
  );
}

function RootRedirect() {
  const { status, user } = useAuth();
  if (status === 'loading') return <Loading />;
  return <Navigate to={user ? homePathFor(user.role) : '/login'} replace />;
}

// Los textos legales (y el lector de Markdown) pesan: solo se descargan al abrir una página legal
const LegalRoute = lazy(() => import('./pages/LegalRoute'));

function NotFound() {
  return (
    <main className="grid min-h-dvh place-items-center p-4 text-center">
      <div>
        <p className="font-display text-5xl font-bold">404</p>
        <p className="mt-2 text-muted">No encontramos esa página.</p>
        <Link to="/" className="mt-4 inline-block text-brand-text underline">Ir al inicio</Link>
      </div>
    </main>
  );
}

export function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<RootRedirect />} />
      <Route path="/login" element={<Login />} />
      <Route path="/crear-contrasena" element={<CreatePassword />} />
      <Route path="/legal/:slug" element={<Suspense fallback={<Loading />}><LegalRoute notFound={<NotFound />} /></Suspense>} />

      <Route path="/app" element={<Protected roles={['MEMBER']} nav={CLIENT_NAV} roleLabel="Cliente" />}>
        <Route index element={<ClientHome />} />
        <Route path="pagos" element={<ClientPayments />} />
        <Route path="tienda" element={<ClientStore />} />
        <Route path="pedidos" element={<ClientOrders />} />
        <Route path="perfil" element={<ClientProfile />} />
      </Route>

      <Route path="/admin" element={<Protected roles={['ADMIN']} nav={ADMIN_NAV} roleLabel="Administrador" />}>
        <Route index element={<AdminDashboard />} />
        <Route path="miembros" element={<MembersPage base="/admin" />} />
        <Route path="miembros/:id" element={<MemberDetailPage base="/admin" />} />
        <Route path="planes" element={<AdminPlans />} />
        <Route path="productos" element={<AdminProducts />} />
        <Route path="pedidos" element={<AdminOrders />} />
        <Route path="ajustes" element={<AdminSettings />} />
      </Route>

      <Route path="/entrenador" element={<Protected roles={['TRAINER']} nav={TRAINER_NAV} roleLabel="Entrenador" />}>
        <Route index element={<Navigate to="miembros" replace />} />
        <Route path="miembros" element={<MembersPage base="/entrenador" readOnly />} />
        <Route path="miembros/:id" element={<MemberDetailPage base="/entrenador" />} />
      </Route>

      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

export function App() {
  return (
    <AuthProvider>
      <ToastProvider>
        <AppRoutes />
        <CookieBanner />
      </ToastProvider>
    </AuthProvider>
  );
}
