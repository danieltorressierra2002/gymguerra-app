import '@testing-library/jest-dom/vitest';
import { cleanup } from '@testing-library/react';
import { afterEach, vi } from 'vitest';
import { api } from './lib/api';

afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
  api.reset();
  localStorage.clear();
  document.cookie = 'gg_consent=; Max-Age=0; Path=/';
});
