/**
 * Falla (código 1) si algún documento legal tiene datos sin completar o notas «[[REVISAR: ...]]».
 * Ejecútalo antes de publicar:  npm run legal:check -w @gymguerra/web
 */
import { readdirSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { fillPlaceholders } from '@gymguerra/shared';
import { legalValues } from '../src/features/legal/legal-config';

const dir = join(import.meta.dirname, '../src/features/legal/content');
const auto = { VERSION: '1.0', FECHA_VIGENCIA: '2026-11-21' };
let problems = 0;

for (const file of readdirSync(dir).filter((f) => f.endsWith('.md')).sort()) {
  const { missing, reviewNotes } = fillPlaceholders(readFileSync(join(dir, file), 'utf8'), {
    ...legalValues,
    ...auto,
  });
  if (missing.length === 0 && reviewNotes.length === 0) {
    console.log(`✔ ${file}`);
    continue;
  }
  problems += missing.length + reviewNotes.length;
  console.log(`✖ ${file}`);
  if (missing.length) console.log(`    datos sin completar: ${missing.join(', ')}`);
  if (reviewNotes.length) console.log(`    notas de revisión pendientes: ${reviewNotes.length}`);
}

if (problems > 0) {
  console.error(`\nNo publiques todavía: quedan ${problems} pendiente(s). Completa legal-config.ts y revisa los textos con un abogado.`);
  process.exit(1);
}
console.log('\nTodos los documentos están completos.');
