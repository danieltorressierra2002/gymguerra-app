import cors from 'cors';
import express from 'express';
import rateLimit from 'express-rate-limit';
import helmet from 'helmet';
import type { PrismaClient } from '@prisma/client';
import { errorHandler, notFoundHandler } from './lib/errors';
import { authenticate } from './middleware/auth';
import { createCredentialsService } from './modules/auth/credentials-service';
import type { IdentityProvisioner } from './modules/auth/provisioner';
import { accountRouter, localAuthRouter } from './modules/auth/local/routes';
import type { LocalAuthService } from './modules/auth/local/service';
import { authRouter } from './modules/auth/routes';
import type { EmailSender } from './modules/email/sender';
import type { TokenVerifier } from './modules/auth/verifier';
import { membersRouter } from './modules/members/routes';
import { createMemberService } from './modules/members/service';
import { adminRouter } from './modules/admin/routes';
import { createSummaryService } from './modules/admin/summary';
import { categoriesRouter } from './modules/categories/routes';
import { createCategoryService } from './modules/categories/service';
import { consentsRouter, publicLegalRouter } from './modules/consents/routes';
import { createConsentService } from './modules/consents/service';
import { ordersRouter } from './modules/orders/routes';
import { createOrderService } from './modules/orders/service';
import { productsRouter, publicStoreRouter } from './modules/products/routes';
import { createProductService } from './modules/products/service';
import { membershipsRouter } from './modules/memberships/routes';
import { createMembershipService } from './modules/memberships/service';
import { createPaymentService } from './modules/payments/payment-service';
import { paymentsRouter } from './modules/payments/routes';
import { createPlanService } from './modules/plans/service';
import { plansRouter, publicPlansRouter } from './modules/plans/routes';
import { settingsRouter } from './modules/settings/routes';

export interface AppConfig {
  corsOrigins: string[];
  trustProxyHops: number;
  timeZone: string;
  appName: string;
  /** Cookie de renovación con atributo Secure (true en producción, con HTTPS) */
  secureCookies: boolean;
  refreshTtlSeconds: number;
}

/** Recibe sus dependencias (no lee process.env) para poder probarse sin base de datos real. */
export function buildApp(deps: {
  prisma: PrismaClient;
  verifier: TokenVerifier;
  provisioner: IdentityProvisioner;
  /** Servicio de inicio de sesión propio; si falta, no se montan /api/auth/login, etc. */
  local?: LocalAuthService;
  /** null = el gimnasio no envía correos */
  emailSender: EmailSender | null;
  config: AppConfig;
}) {
  const { prisma, verifier, provisioner, local, emailSender, config } = deps;
  const app = express();

  app.disable('x-powered-by');
  if (config.trustProxyHops > 0) app.set('trust proxy', config.trustProxyHops);

  app.use(helmet());
  app.use(
    cors({
      origin: config.corsOrigins, // lista blanca explícita, nunca "*"
      credentials: true, // la cookie de renovación viaja entre el frontend y la API
      methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'],
      allowedHeaders: ['Authorization', 'Content-Type'],
      maxAge: 600,
    }),
  );
  app.use(rateLimit({ windowMs: 60_000, limit: 120, standardHeaders: 'draft-7', legacyHeaders: false }));
  app.use(express.json({ limit: '100kb' }));

  app.get('/health', (_req, res) => {
    res.json({ status: 'ok' });
  });

  const memberships = createMembershipService({ prisma, timeZone: config.timeZone });
  const credentials = createCredentialsService({ provisioner, email: emailSender, appName: config.appName });
  const members = createMemberService({ prisma, provisioner, credentials, timeZone: config.timeZone });
  const payments = createPaymentService({ prisma, timeZone: config.timeZone });
  const plans = createPlanService({ prisma });
  const categories = createCategoryService({ prisma });
  const products = createProductService({ prisma });
  const orders = createOrderService({ prisma, timeZone: config.timeZone });
  const consents = createConsentService({ prisma });
  const summary = createSummaryService({ prisma, timeZone: config.timeZone });

  // Rutas públicas (sin sesión), antes del router autenticado
  app.use('/api/auth', authRouter({ prisma, credentials }));
  if (local) {
    app.use(
      '/api/auth',
      localAuthRouter({
        service: local,
        corsOrigins: config.corsOrigins,
        secureCookies: config.secureCookies,
        refreshTtlSeconds: config.refreshTtlSeconds,
      }),
    );
  }
  app.use('/api/public', publicPlansRouter(plans));
  app.use('/api/public', publicStoreRouter(products, categories));
  app.use('/api/public', publicLegalRouter());

  const api = express.Router();
  api.use(authenticate(prisma, verifier)); // todo lo de /api exige sesión
  api.use('/settings', settingsRouter(prisma));
  api.use('/members', membersRouter(members));
  api.use('/memberships', membershipsRouter(memberships));
  api.use('/payments', paymentsRouter(payments));
  api.use('/plans', plansRouter(plans));
  api.use('/categories', categoriesRouter(categories));
  api.use('/products', productsRouter(products));
  api.use('/orders', ordersRouter(orders));
  api.use('/consents', consentsRouter(consents));
  api.use('/admin', adminRouter(summary));
  if (local) api.use('/account', accountRouter(local));
  app.use('/api', api);

  app.use(notFoundHandler);
  app.use(errorHandler);
  return app;
}
