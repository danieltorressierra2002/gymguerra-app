import type { PrismaClient } from '@prisma/client';
import { buildApp } from './app';
import type { IdentityProvisioner } from './modules/auth/provisioner';
import type { EmailMessage, EmailSender } from './modules/email/sender';
import type { TokenVerifier } from './modules/auth/verifier';

type Role = 'ADMIN' | 'TRAINER' | 'MEMBER';

// Tokens de prueba → identidad. Cualquier otro token es inválido.
export const verifier: TokenVerifier = {
  async verify(token) {
    if (['admin', 'trainer', 'member', 'pending', 'suspended'].includes(token)) {
      return { provider: 'test', subject: token, emailVerified: token !== 'pending' };
    }
    throw new Error('token inválido');
  },
};

const users: Record<string, { role: Role; status: string }> = {
  admin: { role: 'ADMIN', status: 'ACTIVE' },
  trainer: { role: 'TRAINER', status: 'ACTIVE' },
  member: { role: 'MEMBER', status: 'ACTIVE' },
  pending: { role: 'MEMBER', status: 'PENDING' },
  suspended: { role: 'MEMBER', status: 'SUSPENDED' },
};

/** Cuenta cuántas veces se intentó crear un usuario en el proveedor de identidad. */
export const provisionerCalls = { create: 0 };

export const provisioner: IdentityProvisioner = {
  async createUser() {
    provisionerCalls.create += 1;
    return { provider: 'test', subject: 'nuevo' };
  },
  async createPasswordSetupLink(email) {
    return `https://gym.test/accion?email=${encodeURIComponent(email)}&oobCode=abc`;
  },
  async disableUser() {},
  async deleteUser() {},
};

/** Registro de consultas de planes y un plan de ejemplo para las pruebas. */
export const planCalls: { findMany: Array<{ where: Record<string, unknown> }> } = { findMany: [] };
const samplePlan = {
  id: '7a1b2c3d-4e5f-4a6b-8c7d-9e0f1a2b3c4d',
  name: 'Mensual',
  description: null,
  price: '25.00',
  currency: 'USD',
  durationMonths: 1,
  durationDays: null,
  benefits: ['Acceso libre'],
  includesTrainer: false,
  isActive: true,
  sortOrder: 0,
  createdAt: new Date('2026-11-01T00:00:00Z'),
  updatedAt: new Date('2026-11-01T00:00:00Z'),
};

// Incluye campos internos a propósito: la API pública no debe devolverlos
const sampleProduct = {
  id: '5d4c3b2a-1f0e-4d9c-8b7a-6f5e4d3c2b1a',
  name: 'Batido de proteína',
  slug: 'batido-de-proteina',
  description: 'Sabor vainilla',
  price: '4.50',
  currency: 'USD',
  imageUrl: 'https://img.test/batido.jpg',
  sku: 'INTERNO-1',
  isActive: true,
  deletedAt: null,
  createdAt: new Date('2026-11-01T00:00:00Z'),
  category: { name: 'Suplementos', slug: 'suplementos', id: 'c1', isActive: true },
};

/** Correos "enviados" durante la prueba. */
export const sentEmails: EmailMessage[] = [];
export const emailSender: EmailSender = {
  async send(message) {
    sentEmails.push(message);
  },
};

// Base de datos falsa: estas pruebas ejercitan autenticación, permisos, validación
// y los chequeos previos de unicidad. La lógica transaccional se prueba con PostgreSQL real.
export const prisma = {
  user: {
    findFirst: async ({ where }: { where: Record<string, unknown> }) => {
      if (typeof where.email === 'string') {
        return where.email === 'taken@test.dev' ? { id: 'x', name: 'Cliente Existente' } : null;
      }
      const subject = String(where.authSubject);
      const u = users[subject];
      return u
        ? { id: `id-${subject}`, email: `${subject}@test.dev`, member: null, trainer: null, ...u }
        : null;
    },
    update: async () => ({}),
  },
  member: {
    findFirst: async ({ where }: { where: Record<string, unknown> }) => {
      if (where.id === '3f0c2a7e-8b1d-4c53-9a54-1d2f3a4b5c6d') {
        return { user: { email: 'cliente@test.dev', name: 'Cliente de Prueba' } };
      }
      return where.documentId === 'DUP-1' ? { id: 'm-existente' } : null;
    },
  },
  trainer: { findFirst: async () => ({ id: 't1' }) },
  $transaction: async (fn: (tx: unknown) => unknown) => fn({ auditLog: { create: async () => ({}) } }),
  product: {
    findMany: async () => [sampleProduct],
    count: async () => 1,
  },
  productCategory: {
    findMany: async () => [{ id: 'c1', name: 'Suplementos', slug: 'suplementos' }],
  },
  membershipPlan: {
    findMany: async (args: { where: Record<string, unknown> }) => {
      planCalls.findMany.push(args);
      return [samplePlan];
    },
  },
} as unknown as PrismaClient;

export const app = buildApp({
  prisma,
  verifier,
  provisioner,
  emailSender,
  config: { corsOrigins: ['http://localhost:5173'], trustProxyHops: 0, timeZone: 'UTC', appName: 'Gimnasio Guerra', secureCookies: false, refreshTtlSeconds: 2_592_000 },
});

export const bearer = (t: string) => ({ Authorization: `Bearer ${t}` });

export const ids = {
  member: '3f0c2a7e-8b1d-4c53-9a54-1d2f3a4b5c6d',
  plan: '7a1b2c3d-4e5f-4a6b-8c7d-9e0f1a2b3c4d',
  membership: '9b8a7c6d-5e4f-4a3b-8c2d-1e0f9a8b7c6d',
};
