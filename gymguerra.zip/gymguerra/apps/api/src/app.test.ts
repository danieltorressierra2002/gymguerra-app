import request from 'supertest';
import { describe, expect, it } from 'vitest';
import { app, bearer, ids } from './test-helpers';

const validBody = { memberId: ids.member, planId: ids.plan };

describe('autenticación', () => {
  it('/health es público', async () => {
    await request(app).get('/health').expect(200, { status: 'ok' });
  });

  it('rechaza peticiones sin token', async () => {
    const res = await request(app).get('/api/memberships').expect(401);
    expect(res.body.error.code).toBe('UNAUTHORIZED');
  });

  it('rechaza tokens inválidos con mensaje genérico', async () => {
    const res = await request(app).get('/api/memberships').set(bearer('basura')).expect(401);
    expect(res.body.error.code).toBe('INVALID_TOKEN');
  });

  it('exige correo confirmado a cuentas pendientes', async () => {
    const res = await request(app).get('/api/memberships').set(bearer('pending')).expect(403);
    expect(res.body.error.code).toBe('EMAIL_NOT_VERIFIED');
  });

  it('bloquea cuentas suspendidas', async () => {
    const res = await request(app).get('/api/memberships').set(bearer('suspended')).expect(403);
    expect(res.body.error.code).toBe('ACCOUNT_SUSPENDED');
  });
});

describe('membresías: autorización por rol', () => {
  it('cliente y entrenador no pueden crear membresías', async () => {
    await request(app).post('/api/memberships').set(bearer('member')).send(validBody).expect(403);
    await request(app).post('/api/memberships').set(bearer('trainer')).send(validBody).expect(403);
  });

  it('solo el administrador cambia el umbral del semáforo', async () => {
    await request(app).put('/api/settings/membership').set(bearer('trainer')).send({ warningDays: 7 }).expect(403);
    await request(app).put('/api/settings/membership').set(bearer('member')).send({ warningDays: 7 }).expect(403);
  });

  it('solo el administrador cancela, pausa o renueva', async () => {
    for (const action of ['cancel', 'freeze', 'unfreeze', 'renew']) {
      await request(app).post(`/api/memberships/${ids.membership}/${action}`).set(bearer('member')).send({}).expect(403);
    }
  });

  it('el entrenador no usa el endpoint exclusivo de cliente', async () => {
    await request(app).get('/api/memberships/me').set(bearer('trainer')).expect(403);
  });
});

describe('membresías: validación', () => {
  it('rechaza cuerpos inválidos antes de tocar la base de datos', async () => {
    const res = await request(app)
      .post('/api/memberships')
      .set(bearer('admin'))
      .send({ memberId: 'no-es-uuid', planId: ids.plan })
      .expect(400);
    expect(res.body.error.code).toBe('VALIDATION_ERROR');
  });

  it('rechaza campos desconocidos (mass assignment)', async () => {
    await request(app).post('/api/memberships').set(bearer('admin')).send({ ...validBody, status: 'CANCELLED' }).expect(400);
  });

  it('rechaza umbrales fuera de rango', async () => {
    await request(app).put('/api/settings/membership').set(bearer('admin')).send({ warningDays: 500 }).expect(400);
    await request(app).put('/api/settings/membership').set(bearer('admin')).send({ warningDays: -1 }).expect(400);
  });

  it('exige motivo al cancelar', async () => {
    await request(app).post(`/api/memberships/${ids.membership}/cancel`).set(bearer('admin')).send({}).expect(400);
  });

  it('rechaza ids que no son UUID', async () => {
    await request(app).get('/api/memberships/abc').set(bearer('admin')).expect(400);
  });
});
