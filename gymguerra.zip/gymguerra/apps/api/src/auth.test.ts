import request from 'supertest';
import { beforeEach, describe, expect, it } from 'vitest';
import { app, sentEmails } from './test-helpers';

const wait = () => new Promise((resolve) => setTimeout(resolve, 25));

describe('POST /api/auth/forgot-password (público)', () => {
  beforeEach(() => {
    sentEmails.length = 0;
  });

  it('cuenta existente: responde 202 y envía el correo con el enlace', async () => {
    const res = await request(app).post('/api/auth/forgot-password').send({ email: 'taken@test.dev' }).expect(202);
    expect(res.body).toEqual({ data: { ok: true } });
    await wait();
    expect(sentEmails).toHaveLength(1);
    expect(sentEmails[0]?.to).toBe('taken@test.dev');
    expect(sentEmails[0]?.text).toContain('oobCode=abc');
    expect(sentEmails[0]?.subject).toContain('Gimnasio Guerra');
  });

  it('cuenta inexistente: misma respuesta exacta y no se envía nada (no revela qué correos existen)', async () => {
    const known = await request(app).post('/api/auth/forgot-password').send({ email: 'taken@test.dev' });
    const unknown = await request(app).post('/api/auth/forgot-password').send({ email: 'nadie@test.dev' });
    expect(unknown.status).toBe(known.status);
    expect(unknown.body).toEqual(known.body);
    await wait();
    expect(sentEmails).toHaveLength(1); // solo el de la cuenta existente
  });

  it('rechaza correos mal formados y campos extra', async () => {
    await request(app).post('/api/auth/forgot-password').send({ email: 'no-es-correo' }).expect(400);
    await request(app).post('/api/auth/forgot-password').send({ email: 'a@b.co', role: 'ADMIN' }).expect(400);
  });

  it('limita los intentos por IP (429)', async () => {
    let last = 0;
    for (let i = 0; i < 8; i++) {
      last = (await request(app).post('/api/auth/forgot-password').send({ email: 'otro@test.dev' })).status;
    }
    expect(last).toBe(429);
  });

  it('el resto de /api sigue exigiendo sesión', async () => {
    await request(app).get('/api/members').expect(401);
  });
});
