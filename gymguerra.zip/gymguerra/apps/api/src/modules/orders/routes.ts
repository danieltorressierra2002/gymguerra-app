import { Router } from 'express';
import { ah } from '../../lib/async-handler';
import { uuid } from '../../lib/validators';
import { requestMeta, requireRole } from '../../middleware/auth';
import { cancelOrderSchema, createOrderSchema, listOrdersQuerySchema, transitionSchema } from './schemas';
import type { OrderService } from './service';

export function ordersRouter(service: OrderService) {
  const r = Router();

  // Solo los clientes compran
  r.post(
    '/',
    requireRole('MEMBER'),
    ah(async (req, res) => {
      const data = await service.create(req.user!, createOrderSchema.parse(req.body), requestMeta(req));
      res.status(201).json({ data });
    }),
  );

  // Admin: todos. Cliente: solo los suyos (el servicio fuerza el filtro).
  r.get(
    '/',
    requireRole('ADMIN', 'MEMBER'),
    ah(async (req, res) => {
      res.json(await service.list(req.user!, listOrdersQuerySchema.parse(req.query)));
    }),
  );

  r.get(
    '/:id',
    requireRole('ADMIN', 'MEMBER'),
    ah(async (req, res) => {
      res.json({ data: await service.getById(req.user!, uuid.parse(req.params.id)) });
    }),
  );

  r.post(
    '/:id/cancel',
    requireRole('ADMIN', 'MEMBER'),
    ah(async (req, res) => {
      const data = await service.cancel(
        req.user!,
        uuid.parse(req.params.id),
        cancelOrderSchema.parse(req.body ?? {}),
        requestMeta(req),
      );
      res.json({ data });
    }),
  );

  r.patch(
    '/:id/status',
    requireRole('ADMIN'),
    ah(async (req, res) => {
      const data = await service.transition(
        req.user!,
        uuid.parse(req.params.id),
        transitionSchema.parse(req.body),
        requestMeta(req),
      );
      res.json({ data });
    }),
  );

  return r;
}
