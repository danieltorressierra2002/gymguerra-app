import { z } from 'zod';
import { isoDate, uuid } from '../../lib/validators';

const item = z.object({ productId: uuid, quantity: z.number().int().min(1).max(20) }).strict();

/**
 * El cliente envía SOLO qué productos y cuántos. Nombres, precios y totales los
 * calcula el servidor: nunca se confía en un precio enviado desde el navegador.
 */
export const createOrderSchema = z
  .object({
    items: z.array(item).min(1).max(30),
    notes: z.string().trim().max(300).optional(),
    /** Aceptación de las condiciones de la tienda: queda registrada con su versión */
    acceptStoreTerms: z.literal(true, { errorMap: () => ({ message: 'Debes aceptar las condiciones de la tienda' }) }),
  })
  .strict()
  .refine((v) => new Set(v.items.map((i) => i.productId)).size === v.items.length, {
    message: 'Hay productos repetidos; suma sus cantidades',
    path: ['items'],
  });

/** PAGADO no se puede fijar a mano: lo decide el registro de pagos. */
export const transitionSchema = z.object({ status: z.enum(['PREPARED', 'DELIVERED', 'CANCELLED']) }).strict();

export const cancelOrderSchema = z.object({ reason: z.string().trim().max(300).optional() }).strict();

export const listOrdersQuerySchema = z.object({
  status: z.enum(['PENDING', 'PAID', 'PREPARED', 'DELIVERED', 'CANCELLED']).optional(),
  memberId: uuid.optional(),
  from: isoDate.optional(),
  to: isoDate.optional(),
  dir: z.enum(['asc', 'desc']).default('desc'),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(20),
});

export type CreateOrderInput = z.infer<typeof createOrderSchema>;
export type TransitionInput = z.infer<typeof transitionSchema>;
export type CancelOrderInput = z.infer<typeof cancelOrderSchema>;
export type ListOrdersQuery = z.infer<typeof listOrdersQuerySchema>;
