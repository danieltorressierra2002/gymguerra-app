import { Prisma, type PrismaClient } from '@prisma/client';
import { LEGAL_DOCUMENTS, addDays, canTransition, zonedDayStart } from '@gymguerra/shared';
import { audit, type RequestMeta } from '../../lib/audit';
import { AppError } from '../../lib/errors';
import type { Actor } from '../../lib/permissions';
import type { CancelOrderInput, CreateOrderInput, ListOrdersQuery, TransitionInput } from './schemas';

const include = {
  items: {
    select: { id: true, productId: true, nameSnapshot: true, unitPrice: true, quantity: true, lineTotal: true },
  },
  member: { select: { id: true, documentId: true, user: { select: { name: true } } } },
  payments: {
    where: { status: 'PAID' },
    select: { receiptNumber: true, amount: true, method: true, paidAt: true },
  },
} satisfies Prisma.OrderInclude;

export interface OrderServiceDeps {
  prisma: PrismaClient;
  timeZone: string;
  now?: () => Date;
}

export function createOrderService({ prisma, timeZone, now = () => new Date() }: OrderServiceDeps) {
  /** Si no puede verlo, responde 404 (no revela que existe). */
  async function load(actor: Actor, id: string) {
    const row = await prisma.order.findUnique({ where: { id }, include });
    const visible = row && (actor.role === 'ADMIN' || (actor.role === 'MEMBER' && actor.memberId === row.memberId));
    if (!row || !visible) throw AppError.notFound('Pedido no encontrado');
    return row;
  }

  return {
    getById: load,

    async list(actor: Actor, q: ListOrdersQuery) {
      const and: Prisma.OrderWhereInput[] = [];
      if (actor.role === 'MEMBER') {
        if (!actor.memberId) throw AppError.forbidden();
        and.push({ memberId: actor.memberId });
      } else if (actor.role !== 'ADMIN') {
        throw AppError.forbidden();
      } else if (q.memberId) {
        and.push({ memberId: q.memberId });
      }
      if (q.status) and.push({ status: q.status });
      // Los días se miden en la zona horaria del gimnasio
      if (q.from) and.push({ createdAt: { gte: zonedDayStart(q.from, timeZone) } });
      if (q.to) and.push({ createdAt: { lt: zonedDayStart(addDays(q.to, 1), timeZone) } });

      const where: Prisma.OrderWhereInput = { AND: and };
      const [total, items] = await Promise.all([
        prisma.order.count({ where }),
        prisma.order.findMany({
          where,
          include,
          orderBy: [{ createdAt: q.dir }, { id: 'asc' }],
          skip: (q.page - 1) * q.pageSize,
          take: q.pageSize,
        }),
      ]);
      return { items, total, page: q.page, pageSize: q.pageSize };
    },

    /**
     * Crea el pedido a partir del carrito. Precios, nombres y totales salen de la base
     * de datos, no del navegador. La tienda no controla existencias: si un producto ya
     * no está publicado (el administrador lo quitó), el pedido se rechaza con la lista.
     */
    async create(actor: Actor, input: CreateOrderInput, meta: RequestMeta) {
      if (actor.role !== 'MEMBER' || !actor.memberId) throw AppError.forbidden();
      const memberId = actor.memberId;

      const id = await prisma.$transaction(async (tx) => {
        const ids = input.items.map((i) => i.productId);
        const products = await tx.product.findMany({
          where: { id: { in: ids }, isActive: true, deletedAt: null, category: { isActive: true, deletedAt: null } },
          select: { id: true, name: true, price: true, currency: true },
        });

        if (products.length !== ids.length) {
          const found = new Set(products.map((p) => p.id));
          throw new AppError(409, 'PRODUCT_UNAVAILABLE', 'Algunos productos ya no están disponibles', {
            productIds: ids.filter((pid) => !found.has(pid)),
          });
        }

        const currencies = new Set(products.map((p) => p.currency));
        if (currencies.size > 1) {
          throw AppError.badRequest('MIXED_CURRENCY', 'No se pueden mezclar productos de distintas monedas en un pedido');
        }
        const currency = products[0]!.currency;

        const byId = new Map(products.map((p) => [p.id, p]));
        const lines = input.items.map((i) => {
          const p = byId.get(i.productId)!;
          return {
            productId: p.id,
            nameSnapshot: p.name,
            unitPrice: p.price,
            quantity: i.quantity,
            lineTotal: p.price.mul(i.quantity),
          };
        });
        const subtotal = lines.reduce((sum, l) => sum.plus(l.lineTotal), new Prisma.Decimal(0));

        const order = await tx.order.create({
          data: {
            memberId,
            currency,
            subtotal,
            discount: new Prisma.Decimal(0),
            total: subtotal,
            notes: input.notes,
            items: { create: lines },
          },
          select: { id: true },
        });

        // Prueba de aceptación de las condiciones de la tienda (versión vigente)
        await tx.consent.createMany({
          data: [
            {
              userId: actor.id,
              documentType: 'STORE_TERMS',
              version: LEGAL_DOCUMENTS.STORE_TERMS.version,
              ip: meta.ip,
              userAgent: meta.userAgent,
            },
          ],
          skipDuplicates: true,
        });

        await audit(tx, {
          actorId: actor.id,
          action: 'order.create',
          entityType: 'Order',
          entityId: order.id,
          after: { items: lines.length, total: subtotal.toString(), currency },
          meta,
        });
        return order.id;
      });
      return load(actor, id);
    },

    /** El cliente cancela su propio pedido; el administrador cancela cualquiera. Solo si sigue PENDIENTE. */
    async cancel(actor: Actor, id: string, input: CancelOrderInput, meta: RequestMeta) {
      await load(actor, id); // 404 si no es suyo
      await prisma.$transaction(async (tx) => {
        const order = await tx.order.findUnique({ where: { id }, select: { status: true } });
        if (!order) throw AppError.notFound('Pedido no encontrado');
        if (!canTransition(order.status, 'CANCELLED')) {
          throw AppError.conflict(
            'NOT_CANCELLABLE',
            'Solo se cancela un pedido pendiente de pago. Si ya pagaste, contacta al gimnasio.',
          );
        }
        const { count } = await tx.order.updateMany({
          where: { id, status: 'PENDING' },
          data: { status: 'CANCELLED', cancelledAt: now() },
        });
        if (count === 0) throw AppError.conflict('STALE', 'El pedido cambió; recarga e intenta de nuevo');
        await audit(tx, {
          actorId: actor.id,
          action: 'order.cancel',
          entityType: 'Order',
          entityId: id,
          before: { status: 'PENDING' },
          after: { status: 'CANCELLED', reason: input.reason ?? null },
          meta,
        });
      });
      return load(actor, id);
    },

    /** Avance del pedido por el administrador: PAGADO → PREPARADO → ENTREGADO (o cancelar si está pendiente). */
    async transition(actor: Actor, id: string, input: TransitionInput, meta: RequestMeta) {
      await prisma.$transaction(async (tx) => {
        const order = await tx.order.findUnique({ where: { id }, select: { status: true } });
        if (!order) throw AppError.notFound('Pedido no encontrado');
        if (!canTransition(order.status, input.status)) {
          throw AppError.conflict(
            'INVALID_TRANSITION',
            `No se puede pasar un pedido de ${order.status} a ${input.status}`,
          );
        }
        const at = now();
        const stamp =
          input.status === 'PREPARED'
            ? { preparedAt: at }
            : input.status === 'DELIVERED'
              ? { deliveredAt: at }
              : { cancelledAt: at };

        // Con el estado esperado en el WHERE, un doble clic no aplica el cambio dos veces
        const { count } = await tx.order.updateMany({
          where: { id, status: order.status },
          data: { status: input.status, ...stamp },
        });
        if (count === 0) throw AppError.conflict('STALE', 'El pedido cambió; recarga e intenta de nuevo');
        await audit(tx, {
          actorId: actor.id,
          action: 'order.status',
          entityType: 'Order',
          entityId: id,
          before: { status: order.status },
          after: { status: input.status },
          meta,
        });
      });
      return load(actor, id);
    },
  };
}

export type OrderService = ReturnType<typeof createOrderService>;
