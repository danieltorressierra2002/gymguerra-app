/** Conversión entre la API (duration: {months}|{days}) y las columnas de la base de datos. */
export type DurationInput = { months: number } | { days: number };

export function toDurationColumns(d: DurationInput): { durationMonths: number | null; durationDays: number | null } {
  return 'months' in d
    ? { durationMonths: d.months, durationDays: null }
    : { durationMonths: null, durationDays: d.days };
}

export interface PlanRow {
  id: string;
  name: string;
  description: string | null;
  price: unknown;
  currency: string;
  durationMonths: number | null;
  durationDays: number | null;
  benefits: string[];
  includesTrainer: boolean;
  isActive: boolean;
  sortOrder: number;
  createdAt: Date;
  updatedAt: Date;
}

/** Vista completa (administración y usuarios autenticados). */
export function presentPlan(row: PlanRow) {
  const { durationMonths, durationDays, ...rest } = row;
  let duration: DurationInput;
  if (durationMonths) duration = { months: durationMonths };
  else if (durationDays) duration = { days: durationDays };
  else throw new Error(`El plan ${row.id} no tiene duración (viola membership_plans_duration_chk)`);
  return { ...rest, duration };
}

/** Vista pública (landing): solo lo que un visitante necesita ver. */
export function presentPublicPlan(row: PlanRow) {
  const p = presentPlan(row);
  return {
    id: p.id,
    name: p.name,
    description: p.description,
    price: p.price,
    currency: p.currency,
    duration: p.duration,
    benefits: p.benefits,
    includesTrainer: p.includesTrainer,
  };
}
