import { Router } from 'express';
import { ah } from '../../lib/async-handler';
import { requestMeta, requireRole } from '../../middleware/auth';
import { createPlanSchema, listPlansQuerySchema, planIdSchema, updatePlanSchema } from './schemas';
import type { PlanService } from './service';

/** Rutas PÚBLICAS para la landing (se montan antes del router autenticado). */
export function publicPlansRouter(service: PlanService) {
  const r = Router();
  r.get(
    '/plans',
    ah(async (_req, res) => {
      const data = await service.listPublic();
      // Los planes casi no cambian: un minuto de caché alivia la base de datos
      res.set('Cache-Control', 'public, max-age=60').json({ data });
    }),
  );
  return r;
}

export function plansRouter(service: PlanService) {
  const r = Router();

  r.get(
    '/',
    requireRole('ADMIN', 'TRAINER', 'MEMBER'),
    ah(async (req, res) => {
      res.json({ data: await service.list(req.user!, listPlansQuerySchema.parse(req.query)) });
    }),
  );

  r.get(
    '/:id',
    requireRole('ADMIN', 'TRAINER', 'MEMBER'),
    ah(async (req, res) => {
      res.json({ data: await service.get(req.user!, planIdSchema.parse(req.params.id)) });
    }),
  );

  r.post(
    '/',
    requireRole('ADMIN'),
    ah(async (req, res) => {
      const data = await service.create(req.user!, createPlanSchema.parse(req.body), requestMeta(req));
      res.status(201).json({ data });
    }),
  );

  r.patch(
    '/:id',
    requireRole('ADMIN'),
    ah(async (req, res) => {
      const data = await service.update(
        req.user!,
        planIdSchema.parse(req.params.id),
        updatePlanSchema.parse(req.body ?? {}),
        requestMeta(req),
      );
      res.json({ data });
    }),
  );

  r.delete(
    '/:id',
    requireRole('ADMIN'),
    ah(async (req, res) => {
      const data = await service.remove(req.user!, planIdSchema.parse(req.params.id), requestMeta(req));
      res.json({ data });
    }),
  );

  return r;
}
