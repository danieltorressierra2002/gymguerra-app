import { z } from 'zod';
import { uuid } from '../../lib/validators';
import { money } from '../payments/schemas';

/** Un plan dura N meses calendario o N días: exactamente una de las dos formas. */
const duration = z.union([
  z.object({ months: z.number().int().min(1).max(60) }).strict(),
  z.object({ days: z.number().int().min(1).max(3650) }).strict(),
]);

const name = z.string().trim().min(2).max(80);
const description = z.string().trim().max(500);
const currency = z.string().regex(/^[A-Z]{3}$/, 'Moneda ISO de 3 letras mayúsculas (p. ej. USD)');
const benefits = z.array(z.string().trim().min(1).max(120)).max(20);
const sortOrder = z.number().int().min(0).max(10_000);

export const createPlanSchema = z
  .object({
    name,
    description: description.optional(),
    price: money,
    currency,
    duration,
    benefits: benefits.default([]),
    includesTrainer: z.boolean().default(false),
    isActive: z.boolean().default(true),
    sortOrder: sortOrder.default(0),
  })
  .strict();

/** `null` en la descripción la borra. La duración, si viene, reemplaza a la anterior. */
export const updatePlanSchema = z
  .object({
    name,
    description: description.nullable(),
    price: money,
    currency,
    duration,
    benefits,
    includesTrainer: z.boolean(),
    isActive: z.boolean(),
    sortOrder,
  })
  .partial()
  .strict();

export const listPlansQuerySchema = z.object({
  includeInactive: z
    .enum(['true', 'false'])
    .transform((v) => v === 'true')
    .optional(),
});

export const planIdSchema = uuid;

export type CreatePlanInput = z.infer<typeof createPlanSchema>;
export type UpdatePlanInput = z.infer<typeof updatePlanSchema>;
export type ListPlansQuery = z.infer<typeof listPlansQuerySchema>;
