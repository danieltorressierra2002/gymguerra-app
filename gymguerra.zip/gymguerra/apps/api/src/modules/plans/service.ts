import { Prisma, type PrismaClient } from '@prisma/client';
import { audit, type RequestMeta } from '../../lib/audit';
import { AppError } from '../../lib/errors';
import type { Actor } from '../../lib/permissions';
import { presentPlan, presentPublicPlan, toDurationColumns } from './mapper';
import type { CreatePlanInput, ListPlansQuery, UpdatePlanInput } from './schemas';

type Db = Prisma.TransactionClient;

const select = {
  id: true,
  name: true,
  description: true,
  price: true,
  currency: true,
  durationMonths: true,
  durationDays: true,
  benefits: true,
  includesTrainer: true,
  isActive: true,
  sortOrder: true,
  createdAt: true,
  updatedAt: true,
} satisfies Prisma.MembershipPlanSelect;

export function createPlanService({ prisma, now = () => new Date() }: { prisma: PrismaClient; now?: () => Date }) {
  async function ensureNameFree(db: Pick<Db, 'membershipPlan'>, name: string, excludeId?: string) {
    const taken = await db.membershipPlan.findFirst({
      where: {
        name: { equals: name, mode: 'insensitive' },
        deletedAt: null,
        ...(excludeId ? { id: { not: excludeId } } : {}),
      },
      select: { id: true },
    });
    if (taken) throw AppError.conflict('PLAN_NAME_TAKEN', 'Ya existe un plan con ese nombre');
  }

  return {
    /** Para la landing: sin sesión, solo planes activos y solo datos públicos. */
    async listPublic() {
      const rows = await prisma.membershipPlan.findMany({
        where: { isActive: true, deletedAt: null },
        orderBy: [{ sortOrder: 'asc' }, { price: 'asc' }],
        select,
      });
      return rows.map(presentPublicPlan);
    },

    /** El administrador puede ver también los inactivos; el resto, solo los activos. */
    async list(actor: Actor, q: ListPlansQuery) {
      const where: Prisma.MembershipPlanWhereInput = { deletedAt: null };
      if (!(actor.role === 'ADMIN' && q.includeInactive)) where.isActive = true;
      const rows = await prisma.membershipPlan.findMany({
        where,
        orderBy: [{ sortOrder: 'asc' }, { price: 'asc' }],
        select,
      });
      return rows.map(presentPlan);
    },

    async get(actor: Actor, id: string) {
      const row = await prisma.membershipPlan.findFirst({
        where: { id, deletedAt: null, ...(actor.role === 'ADMIN' ? {} : { isActive: true }) },
        select,
      });
      if (!row) throw AppError.notFound('Plan no encontrado');
      return presentPlan(row);
    },

    async create(actor: Actor, input: CreatePlanInput, meta: RequestMeta) {
      const row = await prisma.$transaction(async (tx) => {
        await ensureNameFree(tx, input.name);
        const created = await tx.membershipPlan.create({
          data: {
            name: input.name,
            description: input.description,
            price: new Prisma.Decimal(input.price),
            currency: input.currency,
            ...toDurationColumns(input.duration),
            benefits: input.benefits,
            includesTrainer: input.includesTrainer,
            isActive: input.isActive,
            sortOrder: input.sortOrder,
          },
          select,
        });
        await audit(tx, {
          actorId: actor.id,
          action: 'plan.create',
          entityType: 'MembershipPlan',
          entityId: created.id,
          after: { name: input.name, price: input.price, currency: input.currency, duration: input.duration },
          meta,
        });
        return created;
      });
      return presentPlan(row);
    },

    /**
     * Cambiar precio o duración NO afecta a las membresías ya creadas:
     * cada una guarda el precio con el que se vendió (priceSnapshot) y sus fechas.
     */
    async update(actor: Actor, id: string, input: UpdatePlanInput, meta: RequestMeta) {
      const row = await prisma.$transaction(async (tx) => {
        const current = await tx.membershipPlan.findFirst({ where: { id, deletedAt: null }, select: { price: true } });
        if (!current) throw AppError.notFound('Plan no encontrado');
        if (input.name !== undefined) await ensureNameFree(tx, input.name, id);

        const data: Prisma.MembershipPlanUpdateInput = {};
        if (input.name !== undefined) data.name = input.name;
        if (input.description !== undefined) data.description = input.description;
        if (input.price !== undefined) data.price = new Prisma.Decimal(input.price);
        if (input.currency !== undefined) data.currency = input.currency;
        if (input.duration !== undefined) Object.assign(data, toDurationColumns(input.duration));
        if (input.benefits !== undefined) data.benefits = input.benefits;
        if (input.includesTrainer !== undefined) data.includesTrainer = input.includesTrainer;
        if (input.isActive !== undefined) data.isActive = input.isActive;
        if (input.sortOrder !== undefined) data.sortOrder = input.sortOrder;

        const updated = await tx.membershipPlan.update({ where: { id }, data, select });
        await audit(tx, {
          actorId: actor.id,
          action: 'plan.update',
          entityType: 'MembershipPlan',
          entityId: id,
          after: {
            changed: Object.keys(input),
            ...(input.price !== undefined ? { price: input.price, previousPrice: current.price.toString() } : {}),
          },
          meta,
        });
        return updated;
      });
      return presentPlan(row);
    },

    /**
     * Baja lógica: el plan deja de ofrecerse, pero las membresías que ya lo usan
     * conservan su historial. Devuelve cuántas siguen vigentes para avisar al administrador.
     */
    async remove(actor: Actor, id: string, meta: RequestMeta) {
      return prisma.$transaction(async (tx) => {
        const plan = await tx.membershipPlan.findFirst({ where: { id, deletedAt: null }, select: { id: true } });
        if (!plan) throw AppError.notFound('Plan no encontrado');

        const activeMemberships = await tx.membership.count({
          where: { planId: id, status: { in: ['ACTIVE', 'FROZEN'] } },
        });
        await tx.membershipPlan.update({ where: { id }, data: { deletedAt: now(), isActive: false } });
        await audit(tx, {
          actorId: actor.id,
          action: 'plan.delete',
          entityType: 'MembershipPlan',
          entityId: id,
          after: { activeMemberships },
          meta,
        });
        return { activeMemberships };
      });
    },
  };
}

export type PlanService = ReturnType<typeof createPlanService>;
