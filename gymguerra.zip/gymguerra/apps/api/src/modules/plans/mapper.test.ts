import { describe, expect, it } from 'vitest';
import { presentPlan, presentPublicPlan, toDurationColumns, type PlanRow } from './mapper';

const row: PlanRow = {
  id: 'p1',
  name: 'Mensual',
  description: null,
  price: '25.00',
  currency: 'USD',
  durationMonths: 1,
  durationDays: null,
  benefits: ['Acceso libre'],
  includesTrainer: false,
  isActive: true,
  sortOrder: 0,
  createdAt: new Date('2026-11-01T00:00:00Z'),
  updatedAt: new Date('2026-11-02T00:00:00Z'),
};

describe('toDurationColumns', () => {
  it('meses → durationMonths y borra días', () => {
    expect(toDurationColumns({ months: 3 })).toEqual({ durationMonths: 3, durationDays: null });
  });
  it('días → durationDays y borra meses', () => {
    expect(toDurationColumns({ days: 15 })).toEqual({ durationMonths: null, durationDays: 15 });
  });
});

describe('presentPlan', () => {
  it('expone duration y oculta las columnas internas', () => {
    const p = presentPlan(row);
    expect(p.duration).toEqual({ months: 1 });
    expect(p).not.toHaveProperty('durationMonths');
    expect(p).not.toHaveProperty('durationDays');
  });

  it('plan en días', () => {
    expect(presentPlan({ ...row, durationMonths: null, durationDays: 30 }).duration).toEqual({ days: 30 });
  });

  it('falla si la fila viola la restricción de duración', () => {
    expect(() => presentPlan({ ...row, durationMonths: null, durationDays: null })).toThrow();
  });
});

describe('presentPublicPlan', () => {
  it('no filtra campos internos', () => {
    const p = presentPublicPlan(row);
    expect(Object.keys(p).sort()).toEqual(
      ['benefits', 'currency', 'description', 'duration', 'id', 'includesTrainer', 'name', 'price'].sort(),
    );
    expect(p).not.toHaveProperty('isActive');
    expect(p).not.toHaveProperty('sortOrder');
    expect(p).not.toHaveProperty('createdAt');
  });
});
