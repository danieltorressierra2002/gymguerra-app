import { AppError } from '../../lib/errors';
import { getFirebaseAuth } from './firebase-app';
import type { IdentityProvisioner } from './provisioner';

export function createFirebaseProvisioner(
  serviceAccountBase64: string,
  opts: { appUrl: string },
): IdentityProvisioner {
  const auth = getFirebaseAuth(serviceAccountBase64);
  return {
    async createUser({ email, name }) {
      try {
        // Sin contraseña: no se puede entrar hasta usar el enlace de activación
        const user = await auth.createUser({ email, displayName: name, emailVerified: false });
        return { provider: 'firebase', subject: user.uid };
      } catch (err) {
        if ((err as { code?: string }).code === 'auth/email-already-exists') {
          throw AppError.conflict('EMAIL_TAKEN', 'Ya existe una cuenta con ese correo');
        }
        throw err;
      }
    },
    // El dominio de APP_URL debe estar en «Dominios autorizados» de Firebase Authentication
    async createPasswordSetupLink(email) {
      return auth.generatePasswordResetLink(email, { url: `${opts.appUrl}/login` });
    },
    async disableUser(subject) {
      await auth.updateUser(subject, { disabled: true });
    },
    async deleteUser(subject) {
      await auth.deleteUser(subject);
    },
  };
}
