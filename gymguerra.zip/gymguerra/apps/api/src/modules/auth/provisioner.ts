/**
 * Alta y baja de cuentas en el proveedor de identidad. Igual que TokenVerifier,
 * es una interfaz: la API no sabe si detrás hay Firebase, Supabase u otro.
 *
 * La API NUNCA fija ni conoce la contraseña de un cliente: la cuenta se crea sin
 * contraseña y la persona la define con un enlace de un solo uso enviado por correo.
 */
export interface IdentityProvisioner {
  createUser(input: { email: string; name: string }): Promise<{ provider: string; subject: string }>;
  /** Enlace de un solo uso para crear o restablecer la contraseña. */
  createPasswordSetupLink(email: string): Promise<string>;
  disableUser(subject: string): Promise<void>;
  deleteUser(subject: string): Promise<void>;
}
