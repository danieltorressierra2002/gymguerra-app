/**
 * Contrato del proveedor de identidad. La API solo conoce esta interfaz:
 * cambiar de Firebase a Supabase Auth u otro es escribir otra implementación
 * y registrar un authProvider distinto en users; nada más cambia.
 */
export interface VerifiedIdentity {
  provider: string;
  subject: string;
  email?: string;
  emailVerified: boolean;
  /** Sesión a la que pertenece el token (autenticación propia) */
  sessionId?: string;
}

export interface TokenVerifier {
  verify(token: string): Promise<VerifiedIdentity>;
}
