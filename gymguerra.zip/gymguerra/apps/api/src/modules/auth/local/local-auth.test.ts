import { randomUUID } from 'node:crypto';
import request from 'supertest';
import { beforeEach, describe, expect, it } from 'vitest';
import { buildApp } from '../../../app';
import { createPasswordHasher } from '../../../lib/password';
import { asPrisma, createFakePrisma } from '../../../test-fake-prisma';
import type { EmailMessage } from '../../email/sender';
import { createJwtService } from './jwt';
import { createLocalAuth, LOCK_MINUTES, MAX_FAILED_LOGINS } from './service';

const ORIGIN = 'https://gym.test';
const STRONG = 'la tortuga corre por la azotea';
const clock = { t: new Date('2026-11-22T12:00:00Z') };
const now = () => new Date(clock.t);
const advance = (ms: number) => void (clock.t = new Date(clock.t.getTime() + ms));

// Parámetros livianos: las pruebas deben ser rápidas. El «hash viejo» usa un costo menor aún.
const hasher = createPasswordHasher({ N: 2 ** 11, r: 8, p: 1 });
const oldHasher = createPasswordHasher({ N: 2 ** 10, r: 8, p: 1 });

let db = createFakePrisma(now);
let auth = build();
let app = makeApp();
const sent: EmailMessage[] = [];
let ipCounter = 0;
const ip = () => `10.9.${Math.floor(++ipCounter / 250)}.${ipCounter % 250}`; // un cubo de límite por prueba

function build() {
  return createLocalAuth({
    prisma: asPrisma(db),
    hasher,
    jwt: createJwtService({ secret: 'k'.repeat(48), accessTtlSeconds: 900, now }),
    config: { accessTtlSeconds: 900, refreshTtlSeconds: 30 * 86_400, appUrl: ORIGIN },
    now,
  });
}

function makeApp() {
  return buildApp({
    prisma: asPrisma(db),
    verifier: auth.verifier,
    provisioner: auth.provisioner,
    local: auth.service,
    emailSender: { send: async (m) => void sent.push(m) },
    config: {
      corsOrigins: [ORIGIN],
      trustProxyHops: 1, // permite simular IPs distintas con X-Forwarded-For
      timeZone: 'UTC',
      appName: 'Gimnasio Guerra',
      secureCookies: true,
      refreshTtlSeconds: 30 * 86_400,
    },
  });
}

async function seedUser(over: Record<string, unknown> = {}, password: string | null = STRONG, h = hasher) {
  return db.user.create({
    data: {
      email: 'ana@correo.cu',
      name: 'Ana',
      role: 'MEMBER',
      status: 'ACTIVE',
      authSubject: randomUUID(),
      passwordHash: password ? await h.hash(password) : null,
      ...over,
    },
  });
}

const login = (body: object, address = ip()) =>
  request(app).post('/api/auth/login').set('X-Forwarded-For', address).set('Origin', ORIGIN).send(body);

const cookieOf = (res: request.Response) => {
  const raw = (res.headers['set-cookie'] as unknown as string[] | undefined)?.find((c) => c.startsWith('gg_rt='));
  return { raw, value: raw?.split(';')[0]?.slice('gg_rt='.length) };
};

const refresh = (value: string | undefined, origin: string | undefined = ORIGIN) => {
  const r = request(app).post('/api/auth/refresh').set('X-Forwarded-For', ip()).set('Cookie', `gg_rt=${value}`);
  return origin ? r.set('Origin', origin) : r;
};

const bearer = (t: string) => ({ Authorization: `Bearer ${t}` });
const tokenFromLink = (link: string) => link.split('#token=')[1]!;

beforeEach(() => {
  clock.t = new Date('2026-11-22T12:00:00Z');
  db = createFakePrisma(now);
  auth = build();
  app = makeApp();
  sent.length = 0;
});

describe('inicio de sesión', () => {
  it('devuelve el token de acceso en el cuerpo y la renovación en una cookie protegida', async () => {
    await seedUser();
    const res = await login({ email: 'ana@correo.cu', password: STRONG }).expect(200);

    expect(res.body.data).toMatchObject({ tokenType: 'Bearer', expiresIn: 900, user: { email: 'ana@correo.cu', role: 'MEMBER' } });
    expect(JSON.stringify(res.body)).not.toMatch(/passwordHash|scrypt\$/);
    expect(res.headers['cache-control']).toBe('no-store');

    const { raw, value } = cookieOf(res);
    expect(raw).toMatch(/HttpOnly/);
    expect(raw).toMatch(/SameSite=Strict/i);
    expect(raw).toMatch(/Secure/);
    expect(raw).toMatch(/Path=\/api\/auth/);
    expect(JSON.stringify(res.body)).not.toContain(value!); // la renovación nunca va en el cuerpo

    await request(app).get('/api/settings/membership').set(bearer(res.body.data.accessToken)).expect(200);
  });

  it('correo inexistente y contraseña incorrecta dan exactamente la misma respuesta', async () => {
    await seedUser();
    const wrong = await login({ email: 'ana@correo.cu', password: 'otra frase equivocada' }).expect(401);
    const missing = await login({ email: 'nadie@correo.cu', password: 'otra frase equivocada' }).expect(401);
    expect(missing.body).toEqual(wrong.body);
    expect(wrong.body.error.code).toBe('INVALID_CREDENTIALS');
  });

  it('bloquea la cuenta tras 5 fallos, aunque luego se use la contraseña correcta, y la libera a los 15 minutos', async () => {
    await seedUser();
    const address = ip();
    for (let i = 0; i < MAX_FAILED_LOGINS; i++) {
      await login({ email: 'ana@correo.cu', password: 'incorrecta incorrecta' }, address).expect(401);
    }
    const blocked = await login({ email: 'ana@correo.cu', password: STRONG }, address).expect(401);
    expect(blocked.body.error.code).toBe('INVALID_CREDENTIALS'); // no revela que está bloqueada

    advance((LOCK_MINUTES + 1) * 60_000);
    await login({ email: 'ana@correo.cu', password: STRONG }).expect(200);
  });

  it('una cuenta suspendida no entra aunque la contraseña sea correcta', async () => {
    await seedUser({ status: 'SUSPENDED' });
    const res = await login({ email: 'ana@correo.cu', password: STRONG }).expect(403);
    expect(res.body.error.code).toBe('ACCOUNT_SUSPENDED');
  });

  it('una cuenta que aún no definió contraseña no puede entrar', async () => {
    await seedUser({ status: 'PENDING' }, null);
    await login({ email: 'ana@correo.cu', password: STRONG }).expect(401);
  });

  it('refuerza el hash antiguo al iniciar sesión', async () => {
    const user = await seedUser({}, STRONG, oldHasher);
    expect(user.passwordHash).toMatch(/^scrypt\$1024\$/);
    await login({ email: 'ana@correo.cu', password: STRONG }).expect(200);
    expect(user.passwordHash).toMatch(/^scrypt\$2048\$/);
  });

  it('valida el cuerpo y limita los intentos por IP', async () => {
    await login({ email: 'no-es-correo', password: 'x' }).expect(400);
    await login({ email: 'a@b.cu', password: 'x'.repeat(200) }).expect(400);
    await login({ email: 'a@b.cu', password: 'x', rol: 'ADMIN' }).expect(400);
    const address = ip();
    let last = 0;
    for (let i = 0; i < 12; i++) last = (await login({ email: 'a@b.cu', password: 'x' }, address)).status;
    expect(last).toBe(429);
  });

  it('el token de acceso caduca a los 15 minutos', async () => {
    await seedUser();
    const res = await login({ email: 'ana@correo.cu', password: STRONG }).expect(200);
    advance(16 * 60_000);
    const denied = await request(app).get('/api/settings/membership').set(bearer(res.body.data.accessToken)).expect(401);
    expect(denied.body.error.code).toBe('INVALID_TOKEN');
  });
});

describe('renovación y cierre de sesión', () => {
  it('renueva el acceso y cambia el token de renovación en cada uso', async () => {
    await seedUser();
    const first = cookieOf(await login({ email: 'ana@correo.cu', password: STRONG }));
    const res = await refresh(first.value).expect(200);
    const second = cookieOf(res);
    expect(second.value).not.toBe(first.value);
    await request(app).get('/api/settings/membership').set(bearer(res.body.data.accessToken)).expect(200);
  });

  it('reutilizar un token viejo cierra la sesión entera (posible robo)', async () => {
    await seedUser();
    const first = cookieOf(await login({ email: 'ana@correo.cu', password: STRONG }));
    const second = cookieOf(await refresh(first.value).expect(200));

    advance(60_000); // fuera del margen de carrera entre pestañas
    await refresh(first.value).expect(401);
    const after = await refresh(second.value).expect(401); // la sesión legítima también quedó cerrada
    expect(after.body.error.code).toBe('INVALID_SESSION');
  });

  it('dos pestañas que renuevan a la vez no se cierran la sesión (margen de 10 s)', async () => {
    await seedUser();
    const first = cookieOf(await login({ email: 'ana@correo.cu', password: STRONG }));
    const second = cookieOf(await refresh(first.value).expect(200));
    const retry = await refresh(first.value).expect(401);
    expect(retry.body.error.code).toBe('REFRESH_RETRY');
    await refresh(second.value).expect(200); // la sesión sigue viva
  });

  it('al cerrar sesión el token de acceso deja de servir al instante y la cookie se borra', async () => {
    await seedUser();
    const res = await login({ email: 'ana@correo.cu', password: STRONG }).expect(200);
    const { value } = cookieOf(res);

    const out = await request(app).post('/api/auth/logout').set('Origin', ORIGIN).set('Cookie', `gg_rt=${value}`).expect(204);
    expect(cookieOf(out).raw).toMatch(/gg_rt=;/);

    await request(app).get('/api/settings/membership').set(bearer(res.body.data.accessToken)).expect(401);
    await refresh(value).expect(401);
    await request(app).post('/api/auth/logout').set('Origin', ORIGIN).set('Cookie', `gg_rt=${value}`).expect(204); // idempotente
  });

  it('rechaza peticiones con cookie desde un origen no permitido (CSRF)', async () => {
    await seedUser();
    const { value } = cookieOf(await login({ email: 'ana@correo.cu', password: STRONG }));
    const evil = await refresh(value, 'https://evil.test').expect(403);
    expect(evil.body.error.code).toBe('UNTRUSTED_ORIGIN');
    await request(app).post('/api/auth/logout').set('Origin', 'https://evil.test').set('Cookie', `gg_rt=${value}`).expect(403);
    await refresh(undefined, ORIGIN).set('Cookie', '').expect(401);
  });

  it('desactivar a un usuario cierra todas sus sesiones', async () => {
    const user = await seedUser();
    const res = await login({ email: 'ana@correo.cu', password: STRONG }).expect(200);
    await auth.provisioner.disableUser(user.authSubject);
    await request(app).get('/api/settings/membership').set(bearer(res.body.data.accessToken)).expect(401);
  });

  it('rechaza tokens firmados con otro secreto', async () => {
    await seedUser();
    const other = createJwtService({ secret: 'z'.repeat(48), accessTtlSeconds: 900, now });
    const forged = await other.sign({ subject: 'cualquiera', sessionId: 'cualquiera' });
    await request(app).get('/api/settings/membership').set(bearer(forged)).expect(401);
  });
});

describe('crear o restablecer la contraseña con el enlace del correo', () => {
  it('flujo completo: enlace → contraseña débil rechazada → contraseña válida → inicio de sesión', async () => {
    const user = await seedUser({ status: 'PENDING' }, null);
    const link = await auth.provisioner.createPasswordSetupLink('ana@correo.cu');
    expect(link).toMatch(/^https:\/\/gym\.test\/crear-contrasena#token=/); // en el fragmento, no en la consulta
    const token = tokenFromLink(link);

    const weak = await request(app).post('/api/auth/set-password').set('Origin', ORIGIN).set('X-Forwarded-For', ip())
      .send({ token, password: 'gymguerra2026' }).expect(400);
    expect(weak.body.error.code).toBe('WEAK_PASSWORD');
    expect(weak.body.error.details.problems.length).toBeGreaterThan(0);

    await request(app).post('/api/auth/set-password').set('Origin', ORIGIN).set('X-Forwarded-For', ip())
      .send({ token, password: STRONG }).expect(204);
    expect(user.status).toBe('ACTIVE');
    expect(user.emailVerifiedAt).not.toBeNull();
    expect(user.passwordHash).toMatch(/^scrypt\$/);
    expect(user.passwordHash).not.toContain(STRONG);

    await login({ email: 'ana@correo.cu', password: STRONG }).expect(200);
  });

  it('el enlace sirve una sola vez', async () => {
    await seedUser({ status: 'PENDING' }, null);
    const token = tokenFromLink(await auth.provisioner.createPasswordSetupLink('ana@correo.cu'));
    const set = () => request(app).post('/api/auth/set-password').set('Origin', ORIGIN).set('X-Forwarded-For', ip()).send({ token, password: STRONG });
    await set().expect(204);
    const again = await set().expect(400);
    expect(again.body.error.code).toBe('INVALID_OR_EXPIRED_TOKEN');
  });

  it('el enlace de alta caduca a las 72 h y el de recuperación a la hora', async () => {
    await seedUser({ status: 'PENDING' }, null);
    const setup = tokenFromLink(await auth.provisioner.createPasswordSetupLink('ana@correo.cu'));
    advance(73 * 3_600_000);
    await request(app).post('/api/auth/set-password').set('Origin', ORIGIN).set('X-Forwarded-For', ip()).send({ token: setup, password: STRONG }).expect(400);

    await seedUser({ email: 'luis@correo.cu', status: 'ACTIVE' });
    const reset = tokenFromLink(await auth.provisioner.createPasswordSetupLink('luis@correo.cu'));
    advance(61 * 60_000);
    await request(app).post('/api/auth/set-password').set('Origin', ORIGIN).set('X-Forwarded-For', ip()).send({ token: reset, password: STRONG }).expect(400);
  });

  it('pedir un enlace nuevo invalida el anterior', async () => {
    await seedUser({ status: 'PENDING' }, null);
    const old = tokenFromLink(await auth.provisioner.createPasswordSetupLink('ana@correo.cu'));
    const fresh = tokenFromLink(await auth.provisioner.createPasswordSetupLink('ana@correo.cu'));
    await request(app).post('/api/auth/set-password').set('Origin', ORIGIN).set('X-Forwarded-For', ip()).send({ token: old, password: STRONG }).expect(400);
    await request(app).post('/api/auth/set-password').set('Origin', ORIGIN).set('X-Forwarded-For', ip()).send({ token: fresh, password: STRONG }).expect(204);
  });

  it('en la base de datos solo queda el hash del token, nunca el token', async () => {
    await seedUser({ status: 'PENDING' }, null);
    const token = tokenFromLink(await auth.provisioner.createPasswordSetupLink('ana@correo.cu'));
    expect(JSON.stringify(db.authToken.rows)).not.toContain(token);
  });

  it('restablecer la contraseña cierra todas las sesiones abiertas', async () => {
    await seedUser();
    const session = await login({ email: 'ana@correo.cu', password: STRONG }).expect(200);
    const token = tokenFromLink(await auth.provisioner.createPasswordSetupLink('ana@correo.cu'));
    await request(app).post('/api/auth/set-password').set('Origin', ORIGIN).set('X-Forwarded-For', ip())
      .send({ token, password: 'una frase nueva y larga' }).expect(204);
    await request(app).get('/api/settings/membership').set(bearer(session.body.data.accessToken)).expect(401);
    await login({ email: 'ana@correo.cu', password: STRONG }).expect(401);
    await login({ email: 'ana@correo.cu', password: 'una frase nueva y larga' }).expect(200);
  });

  it('«olvidé mi contraseña» envía el enlace por correo sin revelar qué cuentas existen', async () => {
    await seedUser();
    const known = await request(app).post('/api/auth/forgot-password').set('X-Forwarded-For', ip()).send({ email: 'ana@correo.cu' }).expect(202);
    const unknown = await request(app).post('/api/auth/forgot-password').set('X-Forwarded-For', ip()).send({ email: 'nadie@correo.cu' }).expect(202);
    expect(unknown.body).toEqual(known.body);
    await new Promise((r) => setTimeout(r, 50));
    expect(sent).toHaveLength(1);
    expect(sent[0]?.text).toContain('/crear-contrasena#token=');
  });
});

describe('quién soy', () => {
  it('devuelve los datos de la sesión y exige iniciar sesión', async () => {
    await request(app).get('/api/account/me').expect(401);
    await seedUser();
    const { body } = await login({ email: 'ana@correo.cu', password: STRONG }).expect(200);
    const me = await request(app).get('/api/account/me').set(bearer(body.data.accessToken)).expect(200);
    expect(me.body.data).toMatchObject({ name: 'Ana', email: 'ana@correo.cu', role: 'MEMBER' });
    expect(JSON.stringify(me.body)).not.toMatch(/passwordHash/);
    expect(me.headers['cache-control']).toBe('no-store');
  });
});

describe('cambiar la contraseña con la sesión iniciada', () => {
  it('exige sesión y la contraseña actual', async () => {
    await request(app).post('/api/account/change-password').send({}).expect(401);
    await seedUser();
    const { body } = await login({ email: 'ana@correo.cu', password: STRONG }).expect(200);
    const post = (data: object) =>
      request(app).post('/api/account/change-password').set('X-Forwarded-For', ip()).set(bearer(body.data.accessToken)).send(data);

    const wrong = await post({ currentPassword: 'no es esta', newPassword: 'una frase nueva y larga' }).expect(400);
    expect(wrong.body.error.code).toBe('INVALID_CURRENT_PASSWORD');
    await post({ currentPassword: STRONG, newPassword: 'corta' }).expect(400);
  });

  it('cierra las demás sesiones pero conserva la actual', async () => {
    await seedUser();
    const here = await login({ email: 'ana@correo.cu', password: STRONG }).expect(200);
    const other = await login({ email: 'ana@correo.cu', password: STRONG }).expect(200);

    await request(app).post('/api/account/change-password').set('X-Forwarded-For', ip()).set(bearer(here.body.data.accessToken))
      .send({ currentPassword: STRONG, newPassword: 'una frase nueva y larga' }).expect(204);

    await request(app).get('/api/settings/membership').set(bearer(here.body.data.accessToken)).expect(200);
    await request(app).get('/api/settings/membership').set(bearer(other.body.data.accessToken)).expect(401);
    await login({ email: 'ana@correo.cu', password: STRONG }).expect(401);
    await login({ email: 'ana@correo.cu', password: 'una frase nueva y larga' }).expect(200);
  });
});
