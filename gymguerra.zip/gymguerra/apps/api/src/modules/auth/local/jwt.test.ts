import { SignJWT } from 'jose';
import { describe, expect, it } from 'vitest';
import { createJwtService } from './jwt';

const secret = 'x'.repeat(48);
let t = new Date('2026-11-22T12:00:00Z');
const jwt = createJwtService({ secret, accessTtlSeconds: 900, now: () => t });
const claims = { subject: 'sub-1', sessionId: 'sid-1' };

describe('token de acceso (JWT)', () => {
  it('firma y verifica devolviendo usuario y sesión', async () => {
    t = new Date('2026-11-22T12:00:00Z');
    expect(await jwt.verify(await jwt.sign(claims))).toEqual(claims);
  });

  it('caduca a los 15 minutos', async () => {
    t = new Date('2026-11-22T12:00:00Z');
    const token = await jwt.sign(claims);
    t = new Date('2026-11-22T12:14:00Z');
    await expect(jwt.verify(token)).resolves.toBeDefined();
    t = new Date('2026-11-22T12:16:00Z');
    await expect(jwt.verify(token)).rejects.toThrow();
  });

  it('rechaza un token firmado con otro secreto o alterado', async () => {
    t = new Date('2026-11-22T12:00:00Z');
    const other = createJwtService({ secret: 'y'.repeat(48), accessTtlSeconds: 900, now: () => t });
    await expect(jwt.verify(await other.sign(claims))).rejects.toThrow();

    const good = await jwt.sign(claims);
    const [h, , s] = good.split('.');
    const forgedPayload = Buffer.from(JSON.stringify({ sub: 'admin', sid: 'sid-1', iss: 'gymguerra', aud: 'gymguerra-api', exp: 9999999999 })).toString('base64url');
    await expect(jwt.verify(`${h}.${forgedPayload}.${s}`)).rejects.toThrow();
  });

  it('rechaza «alg: none» y otros algoritmos', async () => {
    const enc = (o: object) => Buffer.from(JSON.stringify(o)).toString('base64url');
    const none = `${enc({ alg: 'none', typ: 'JWT' })}.${enc({ sub: 'x', sid: 'y', iss: 'gymguerra', aud: 'gymguerra-api', exp: 9999999999 })}.`;
    await expect(jwt.verify(none)).rejects.toThrow();

    const hs512 = await new SignJWT({ sid: 'y' })
      .setProtectedHeader({ alg: 'HS512' })
      .setSubject('x')
      .setIssuer('gymguerra')
      .setAudience('gymguerra-api')
      .setExpirationTime('1h')
      .sign(new TextEncoder().encode(secret));
    await expect(jwt.verify(hs512)).rejects.toThrow();
  });

  it('rechaza tokens de otro emisor o destinatario', async () => {
    const foreign = await new SignJWT({ sid: 'y' })
      .setProtectedHeader({ alg: 'HS256' })
      .setSubject('x')
      .setIssuer('otro-sistema')
      .setAudience('gymguerra-api')
      .setExpirationTime('1h')
      .sign(new TextEncoder().encode(secret));
    await expect(jwt.verify(foreign)).rejects.toThrow();
  });
});
