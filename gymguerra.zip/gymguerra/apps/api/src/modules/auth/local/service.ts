import { randomUUID } from 'node:crypto';
import type { Prisma, PrismaClient } from '@prisma/client';
import { audit, type RequestMeta } from '../../../lib/audit';
import { AppError } from '../../../lib/errors';
import type { Actor } from '../../../lib/permissions';
import type { PasswordHasher } from '../../../lib/password';
import { passwordProblems } from '../../../lib/password-policy';
import { generateToken, hashToken } from '../../../lib/tokens';
import type { IdentityProvisioner } from '../provisioner';
import type { TokenVerifier } from '../verifier';
import type { JwtService } from './jwt';

export const MAX_FAILED_LOGINS = 5;
export const LOCK_MINUTES = 15;
/** Dos pestañas pueden renovar a la vez: dentro de este margen no se trata como robo. */
export const REFRESH_REUSE_GRACE_MS = 10_000;
const SETUP_TTL_MS = 72 * 60 * 60 * 1000;
const RESET_TTL_MS = 60 * 60 * 1000;

// Mismo mensaje para «no existe», «clave incorrecta» y «bloqueada»: no se puede averiguar qué correos hay
const GENERIC_LOGIN_ERROR =
  'Correo o contraseña incorrectos, o la cuenta está bloqueada temporalmente. Inténtalo más tarde.';
const INVALID_SESSION = 'Sesión inválida o expirada';
const INVALID_LINK = 'El enlace no es válido o ya caducó. Pide uno nuevo.';

export interface LocalAuthConfig {
  accessTtlSeconds: number;
  refreshTtlSeconds: number;
  /** URL pública del frontend, destino de los enlaces de los correos */
  appUrl: string;
}

export interface LocalAuthDeps {
  prisma: PrismaClient;
  hasher: PasswordHasher;
  jwt: JwtService;
  config: LocalAuthConfig;
  now?: () => Date;
}

/**
 * Crea un enlace de un solo uso para fijar o restablecer la contraseña.
 * Invalida los anteriores sin usar y devuelve el token en claro (solo existe aquí y en el correo).
 */
export async function issuePasswordToken(
  db: Pick<Prisma.TransactionClient, 'authToken'>,
  userId: string,
  type: 'PASSWORD_SETUP' | 'PASSWORD_RESET',
  now: Date = new Date(),
): Promise<string> {
  await db.authToken.updateMany({ where: { userId, usedAt: null }, data: { usedAt: now } });
  const token = generateToken();
  const ttl = type === 'PASSWORD_SETUP' ? SETUP_TTL_MS : RESET_TTL_MS;
  await db.authToken.create({
    data: { userId, type, tokenHash: hashToken(token), expiresAt: new Date(now.getTime() + ttl) },
  });
  return token;
}

export function createLocalAuth(deps: LocalAuthDeps) {
  const { prisma, hasher, jwt, config } = deps;
  const now = deps.now ?? (() => new Date());

  function weakPassword(password: string, email: string) {
    const problems = passwordProblems(password, { email });
    if (problems.length > 0) {
      throw AppError.badRequest('WEAK_PASSWORD', 'La contraseña no es lo bastante segura', { problems });
    }
  }

  async function newSessionTokens(sessionId: string, subject: string) {
    return jwt.sign({ subject, sessionId });
  }

  const service = {
    async login(input: { email: string; password: string }, meta: RequestMeta) {
      const user = await prisma.user.findFirst({
        where: { email: input.email, deletedAt: null, authProvider: 'local' },
      });
      const locked = Boolean(user?.lockedUntil && user.lockedUntil.getTime() > now().getTime());

      // Siempre se calcula un hash (real o simulado): el tiempo de respuesta no delata si el correo existe
      let valid = false;
      if (user?.passwordHash) valid = await hasher.verify(input.password, user.passwordHash);
      else await hasher.dummyVerify(input.password);

      if (!user || !valid || locked) {
        if (user && !locked) {
          const updated = await prisma.user.update({
            where: { id: user.id },
            data: { failedLogins: { increment: 1 } },
            select: { failedLogins: true },
          });
          if (updated.failedLogins >= MAX_FAILED_LOGINS) {
            await prisma.user.update({
              where: { id: user.id },
              data: { failedLogins: 0, lockedUntil: new Date(now().getTime() + LOCK_MINUTES * 60_000) },
            });
          }
        }
        throw AppError.unauthorized('INVALID_CREDENTIALS', GENERIC_LOGIN_ERROR);
      }
      if (user.status === 'SUSPENDED' || !user.authSubject) {
        throw AppError.forbidden('ACCOUNT_SUSPENDED', 'Tu cuenta está suspendida');
      }

      // Si el hash es de una versión más débil, se refuerza ahora que tenemos la contraseña en claro
      const upgraded = hasher.needsRehash(user.passwordHash!) ? await hasher.hash(input.password) : undefined;
      const refreshToken = generateToken();
      const session = await prisma.$transaction(async (tx) => {
        await tx.user.update({
          where: { id: user.id },
          data: {
            failedLogins: 0,
            lockedUntil: null,
            lastLoginAt: now(),
            ...(upgraded ? { passwordHash: upgraded } : {}),
          },
        });
        return tx.session.create({
          data: {
            userId: user.id,
            refreshTokenHash: hashToken(refreshToken),
            expiresAt: new Date(now().getTime() + config.refreshTtlSeconds * 1000),
            ip: meta.ip,
            userAgent: meta.userAgent,
          },
          select: { id: true },
        });
      });

      return {
        accessToken: await newSessionTokens(session.id, user.authSubject),
        expiresIn: config.accessTtlSeconds,
        refreshToken,
        user: { id: user.id, name: user.name, email: user.email, role: user.role },
      };
    },

    /** Renueva el acceso y ROTA el token de renovación. Reutilizar uno viejo cierra la sesión. */
    async refresh(refreshToken: string, meta: RequestMeta) {
      const h = hashToken(refreshToken);
      const session = await prisma.session.findUnique({ where: { refreshTokenHash: h } });

      if (!session) {
        const reused = await prisma.session.findUnique({ where: { previousTokenHash: h } });
        if (reused && !reused.revokedAt) {
          if (now().getTime() - reused.lastUsedAt.getTime() < REFRESH_REUSE_GRACE_MS) {
            throw AppError.unauthorized('REFRESH_RETRY', INVALID_SESSION); // carrera entre pestañas
          }
          await prisma.session.update({ where: { id: reused.id }, data: { revokedAt: now() } }); // posible robo
        }
        throw AppError.unauthorized('INVALID_SESSION', INVALID_SESSION);
      }

      if (session.revokedAt || session.expiresAt.getTime() <= now().getTime()) {
        throw AppError.unauthorized('INVALID_SESSION', INVALID_SESSION);
      }
      const user = await prisma.user.findFirst({ where: { id: session.userId, deletedAt: null } });
      if (!user || user.status !== 'ACTIVE' || !user.authSubject) {
        await prisma.session.update({ where: { id: session.id }, data: { revokedAt: now() } });
        throw AppError.unauthorized('INVALID_SESSION', INVALID_SESSION);
      }

      const next = generateToken();
      // Cambio atómico: si dos peticiones llegan a la vez, solo una gana
      const { count } = await prisma.session.updateMany({
        where: { id: session.id, refreshTokenHash: h },
        data: {
          refreshTokenHash: hashToken(next),
          previousTokenHash: h,
          lastUsedAt: now(),
          ip: meta.ip,
          userAgent: meta.userAgent,
        },
      });
      if (count === 0) throw AppError.unauthorized('REFRESH_RETRY', INVALID_SESSION);

      return {
        accessToken: await newSessionTokens(session.id, user.authSubject),
        expiresIn: config.accessTtlSeconds,
        refreshToken: next,
      };
    },

    /** Datos de quien tiene la sesión abierta (la interfaz los pide al arrancar). */
    async me(actor: Actor) {
      const user = await prisma.user.findFirst({ where: { id: actor.id, deletedAt: null } });
      if (!user) throw AppError.unauthorized('INVALID_SESSION', INVALID_SESSION);
      return {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        memberId: actor.memberId,
        trainerId: actor.trainerId,
      };
    },

    /** Cierra la sesión. Es idempotente: cerrar dos veces no da error. */
    async logout(refreshToken: string) {
      const h = hashToken(refreshToken);
      const session =
        (await prisma.session.findUnique({ where: { refreshTokenHash: h } })) ??
        (await prisma.session.findUnique({ where: { previousTokenHash: h } }));
      if (session && !session.revokedAt) {
        await prisma.session.update({ where: { id: session.id }, data: { revokedAt: now() } });
      }
    },

    /** Fija la contraseña con el enlace del correo (alta nueva o «olvidé mi contraseña»). */
    async setPassword(input: { token: string; password: string }, meta: RequestMeta) {
      const t = await prisma.authToken.findUnique({ where: { tokenHash: hashToken(input.token) } });
      if (!t || t.usedAt || t.expiresAt.getTime() <= now().getTime()) {
        throw AppError.badRequest('INVALID_OR_EXPIRED_TOKEN', INVALID_LINK);
      }
      const user = await prisma.user.findFirst({ where: { id: t.userId, deletedAt: null } });
      if (!user || user.status === 'SUSPENDED') throw AppError.badRequest('INVALID_OR_EXPIRED_TOKEN', INVALID_LINK);

      weakPassword(input.password, user.email);
      const hash = await hasher.hash(input.password);

      await prisma.$transaction(async (tx) => {
        // El token solo se puede usar una vez, incluso si llegan dos peticiones a la vez
        const { count } = await tx.authToken.updateMany({ where: { id: t.id, usedAt: null }, data: { usedAt: now() } });
        if (count === 0) throw AppError.badRequest('INVALID_OR_EXPIRED_TOKEN', INVALID_LINK);

        await tx.user.update({
          where: { id: user.id },
          data: {
            passwordHash: hash,
            failedLogins: 0,
            lockedUntil: null,
            status: 'ACTIVE', // haber usado el enlace del correo demuestra que es suyo
            emailVerifiedAt: user.emailVerifiedAt ?? now(),
          },
        });
        // Cambiar la contraseña cierra todas las sesiones abiertas
        await tx.session.updateMany({ where: { userId: user.id, revokedAt: null }, data: { revokedAt: now() } });
        await audit(tx, {
          actorId: user.id,
          action: 'auth.password_set',
          entityType: 'User',
          entityId: user.id,
          meta,
        });
      });
    },

    /** Cambio de contraseña con la sesión iniciada: pide la actual y cierra las demás sesiones. */
    async changePassword(
      actor: Actor & { sessionId?: string },
      input: { currentPassword: string; newPassword: string },
      meta: RequestMeta,
    ) {
      const user = await prisma.user.findFirst({ where: { id: actor.id, deletedAt: null } });
      if (!user?.passwordHash || !(await hasher.verify(input.currentPassword, user.passwordHash))) {
        throw AppError.badRequest('INVALID_CURRENT_PASSWORD', 'La contraseña actual no es correcta');
      }
      weakPassword(input.newPassword, user.email);
      const hash = await hasher.hash(input.newPassword);

      await prisma.$transaction(async (tx) => {
        await tx.user.update({ where: { id: user.id }, data: { passwordHash: hash } });
        await tx.session.updateMany({
          where: { userId: user.id, revokedAt: null, ...(actor.sessionId ? { id: { not: actor.sessionId } } : {}) },
          data: { revokedAt: now() },
        });
        await audit(tx, {
          actorId: user.id,
          action: 'auth.password_changed',
          entityType: 'User',
          entityId: user.id,
          meta,
        });
      });
    },
  };

  /** Verifica el token de acceso Y que su sesión siga abierta: cerrar sesión surte efecto al instante. */
  const verifier: TokenVerifier = {
    async verify(token) {
      const { subject, sessionId } = await jwt.verify(token);
      const session = await prisma.session.findUnique({ where: { id: sessionId } });
      if (!session || session.revokedAt || session.expiresAt.getTime() <= now().getTime()) {
        throw new Error('sesión cerrada o caducada');
      }
      return { provider: 'local', subject, emailVerified: true, sessionId };
    },
  };

  const provisioner: IdentityProvisioner = {
    // No hay proveedor externo: el identificador lo generamos nosotros
    async createUser() {
      return { provider: 'local', subject: randomUUID() };
    },

    async createPasswordSetupLink(email) {
      const user = await prisma.user.findFirst({
        where: { email, deletedAt: null, authProvider: 'local' },
        select: { id: true, passwordHash: true },
      });
      if (!user) throw new Error('No existe una cuenta local con ese correo');
      const token = await issuePasswordToken(
        prisma,
        user.id,
        user.passwordHash ? 'PASSWORD_RESET' : 'PASSWORD_SETUP',
        now(),
      );
      // En el fragmento (#) el token no viaja al servidor ni se filtra en el encabezado Referer
      return `${config.appUrl}/crear-contrasena#token=${token}`;
    },

    async disableUser(subject) {
      const user = await prisma.user.findFirst({ where: { authProvider: 'local', authSubject: subject } });
      if (user) {
        await prisma.session.updateMany({ where: { userId: user.id, revokedAt: null }, data: { revokedAt: now() } });
      }
    },

    // Nada externo que deshacer
    async deleteUser() {},
  };

  return { service, verifier, provisioner };
}

export type LocalAuth = ReturnType<typeof createLocalAuth>;
export type LocalAuthService = LocalAuth['service'];
