import { SignJWT, jwtVerify } from 'jose';

const ISSUER = 'gymguerra';
const AUDIENCE = 'gymguerra-api';

/**
 * Token de acceso de vida corta (15 min por defecto). Va firmado con HS256 y un secreto del servidor.
 * Solo se aceptan tokens HS256 con nuestro emisor y destinatario: «alg: none» y otros algoritmos se rechazan.
 */
export function createJwtService(opts: { secret: string; accessTtlSeconds: number; now?: () => Date }) {
  const key = new TextEncoder().encode(opts.secret);
  const now = opts.now ?? (() => new Date());

  return {
    async sign(p: { subject: string; sessionId: string }): Promise<string> {
      const iat = Math.floor(now().getTime() / 1000);
      return new SignJWT({ sid: p.sessionId })
        .setProtectedHeader({ alg: 'HS256', typ: 'JWT' })
        .setSubject(p.subject)
        .setIssuer(ISSUER)
        .setAudience(AUDIENCE)
        .setIssuedAt(iat)
        .setExpirationTime(iat + opts.accessTtlSeconds)
        .sign(key);
    },

    /** Lanza si la firma, el algoritmo, el emisor o la caducidad no son válidos. */
    async verify(token: string): Promise<{ subject: string; sessionId: string }> {
      const { payload } = await jwtVerify(token, key, {
        issuer: ISSUER,
        audience: AUDIENCE,
        algorithms: ['HS256'],
        currentDate: now(),
      });
      if (typeof payload.sub !== 'string' || typeof payload.sid !== 'string') throw new Error('token incompleto');
      return { subject: payload.sub, sessionId: payload.sid };
    },
  };
}

export type JwtService = ReturnType<typeof createJwtService>;
