import { Router, type Request, type RequestHandler, type Response } from 'express';
import rateLimit from 'express-rate-limit';
import { z } from 'zod';
import { ah } from '../../../lib/async-handler';
import { AppError } from '../../../lib/errors';
import { requestMeta } from '../../../middleware/auth';
import type { LocalAuthService } from './service';

export const REFRESH_COOKIE = 'gg_rt';
const COOKIE_PATH = '/api/auth';

export function readCookie(header: string | undefined, name: string): string | undefined {
  for (const part of (header ?? '').split(';')) {
    const [k, ...v] = part.trim().split('=');
    if (k === name) return decodeURIComponent(v.join('='));
  }
  return undefined;
}

/**
 * Defensa extra contra CSRF para las rutas que usan la cookie de renovación:
 * si el navegador envía «Origin», debe ser uno de los orígenes permitidos.
 * (La cookie además es SameSite=Strict y solo viaja a /api/auth.)
 */
export function requireTrustedOrigin(allowed: string[]): RequestHandler {
  return (req, _res, next) => {
    const origin = req.get('origin');
    if (origin && !allowed.includes(origin)) return next(AppError.forbidden('UNTRUSTED_ORIGIN', 'Origen no permitido'));
    next();
  };
}

const email = z.string().trim().toLowerCase().email().max(254);
const loginSchema = z.object({ email, password: z.string().min(1).max(128) }).strict();
const setPasswordSchema = z.object({ token: z.string().min(20).max(200), password: z.string().min(1).max(128) }).strict();
const changePasswordSchema = z
  .object({ currentPassword: z.string().min(1).max(128), newPassword: z.string().min(1).max(128) })
  .strict();

function limiter(limit: number) {
  return rateLimit({
    windowMs: 15 * 60_000,
    limit,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    message: { error: { code: 'RATE_LIMITED', message: 'Demasiados intentos. Intenta de nuevo más tarde.' } },
  });
}

export function localAuthRouter(deps: { service: LocalAuthService; corsOrigins: string[]; secureCookies: boolean; refreshTtlSeconds: number }) {
  const { service, corsOrigins, secureCookies, refreshTtlSeconds } = deps;
  const trusted = requireTrustedOrigin(corsOrigins);
  const r = Router();

  // HttpOnly: el JavaScript de la página no puede leerla (un XSS no la roba). Strict: no viaja en peticiones de otros sitios.
  const setRefreshCookie = (res: Response, token: string) =>
    res.cookie(REFRESH_COOKIE, token, {
      httpOnly: true,
      sameSite: 'strict',
      secure: secureCookies,
      path: COOKIE_PATH,
      maxAge: refreshTtlSeconds * 1000,
    });
  const clearRefreshCookie = (res: Response) =>
    res.clearCookie(REFRESH_COOKIE, { httpOnly: true, sameSite: 'strict', secure: secureCookies, path: COOKIE_PATH });

  const noStore = (res: Response) => res.set('Cache-Control', 'no-store');

  r.post(
    '/login',
    trusted,
    limiter(10),
    ah(async (req, res) => {
      const out = await service.login(loginSchema.parse(req.body), requestMeta(req));
      setRefreshCookie(res, out.refreshToken);
      noStore(res).json({ data: { accessToken: out.accessToken, tokenType: 'Bearer', expiresIn: out.expiresIn, user: out.user } });
    }),
  );

  r.post(
    '/refresh',
    trusted,
    ah(async (req: Request, res) => {
      const token = readCookie(req.headers.cookie, REFRESH_COOKIE);
      if (!token) throw AppError.unauthorized('INVALID_SESSION', 'Sesión inválida o expirada');
      const out = await service.refresh(token, requestMeta(req));
      setRefreshCookie(res, out.refreshToken);
      noStore(res).json({ data: { accessToken: out.accessToken, tokenType: 'Bearer', expiresIn: out.expiresIn } });
    }),
  );

  r.post(
    '/logout',
    trusted,
    ah(async (req, res) => {
      const token = readCookie(req.headers.cookie, REFRESH_COOKIE);
      if (token) await service.logout(token);
      clearRefreshCookie(res);
      res.status(204).end();
    }),
  );

  // Fija la contraseña con el enlace del correo (cuenta nueva u «olvidé mi contraseña»)
  r.post(
    '/set-password',
    trusted,
    limiter(10),
    ah(async (req, res) => {
      await service.setPassword(setPasswordSchema.parse(req.body), requestMeta(req));
      res.status(204).end();
    }),
  );

  return r;
}

/** Requiere sesión (se monta dentro del router autenticado). */
export function accountRouter(service: LocalAuthService) {
  const r = Router();

  r.get(
    '/me',
    ah(async (req, res) => {
      res.set('Cache-Control', 'no-store').json({ data: await service.me(req.user!) });
    }),
  );

  r.post(
    '/change-password',
    limiter(10),
    ah(async (req, res) => {
      await service.changePassword(req.user!, changePasswordSchema.parse(req.body), requestMeta(req));
      res.status(204).end();
    }),
  );
  return r;
}
