import type { EmailSender } from '../email/sender';
import { invitationEmail, passwordResetEmail } from '../email/templates';
import type { IdentityProvisioner } from './provisioner';

/**
 * Enlaces para crear o restablecer contraseñas.
 * `email: null` = el gimnasio NO envía correos: el enlace se devuelve al administrador, que se lo
 * entrega al cliente por su cuenta (WhatsApp, en persona...). Si hay un proveedor de correo, además se envía.
 */
export function createCredentialsService(deps: {
  provisioner: IdentityProvisioner;
  email: EmailSender | null;
  appName: string;
}) {
  const { provisioner, email, appName } = deps;
  return {
    emailEnabled: email !== null,

    /** Genera el enlace (invalida el anterior) y, si hay correo configurado, lo envía. Nunca falla por el correo. */
    async prepareInvitation(p: { to: string; name?: string | null }): Promise<{ link: string; sent: boolean }> {
      const link = await provisioner.createPasswordSetupLink(p.to);
      if (!email) return { link, sent: false };
      try {
        await email.send({ to: p.to, ...invitationEmail({ name: p.name, link, appName }) });
        return { link, sent: true };
      } catch (err) {
        console.error('No se pudo enviar el correo de invitación', err);
        return { link, sent: false };
      }
    },

    /** Solo para «olvidé mi contraseña» por correo; sin proveedor de correo no existe esa vía. */
    async sendPasswordReset(p: { to: string; name?: string | null }) {
      if (!email) throw new Error('El envío de correo está desactivado');
      const link = await provisioner.createPasswordSetupLink(p.to);
      await email.send({ to: p.to, ...passwordResetEmail({ name: p.name, link, appName }) });
    },
  };
}

export type CredentialsService = ReturnType<typeof createCredentialsService>;
