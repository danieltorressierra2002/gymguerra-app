import { describe, expect, it } from 'vitest';
import { createCredentialsService } from './credentials-service';
import type { IdentityProvisioner } from './provisioner';
import type { EmailMessage, EmailSender } from '../email/sender';

const LINK = 'https://gym.test/crear-contrasena#token=abc123';
const provisioner: IdentityProvisioner = {
  createUser: async () => ({ provider: 'local', subject: 's' }),
  createPasswordSetupLink: async () => LINK,
  disableUser: async () => {},
  deleteUser: async () => {},
};

describe('enlaces de activación', () => {
  it('sin correo configurado devuelve el enlace para que el administrador lo entregue', async () => {
    const svc = createCredentialsService({ provisioner, email: null, appName: 'Gimnasio Guerra' });
    expect(svc.emailEnabled).toBe(false);
    expect(await svc.prepareInvitation({ to: 'ana@correo.cu', name: 'Ana' })).toEqual({ link: LINK, sent: false });
  });

  it('sin correo no existe «olvidé mi contraseña» por correo', async () => {
    const svc = createCredentialsService({ provisioner, email: null, appName: 'Gym' });
    await expect(svc.sendPasswordReset({ to: 'ana@correo.cu' })).rejects.toThrow();
  });

  it('con correo configurado envía el mensaje con el enlace y además lo devuelve', async () => {
    const sent: EmailMessage[] = [];
    const email: EmailSender = { send: async (m) => void sent.push(m) };
    const svc = createCredentialsService({ provisioner, email, appName: 'Gimnasio Guerra' });
    expect(svc.emailEnabled).toBe(true);
    expect(await svc.prepareInvitation({ to: 'ana@correo.cu', name: 'Ana' })).toEqual({ link: LINK, sent: true });
    expect(sent).toHaveLength(1);
    expect(sent[0]?.text).toContain(LINK);
  });

  it('si el envío falla igual devuelve el enlace (nunca deja al cliente sin acceso)', async () => {
    const email: EmailSender = { send: async () => Promise.reject(new Error('sin red')) };
    const svc = createCredentialsService({ provisioner, email, appName: 'Gym' });
    expect(await svc.prepareInvitation({ to: 'ana@correo.cu' })).toEqual({ link: LINK, sent: false });
  });
});
