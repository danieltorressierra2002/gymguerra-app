import { cert, getApps, initializeApp } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';

/** Una sola inicialización de Firebase Admin, compartida por el verificador y el aprovisionador. */
export function getFirebaseAuth(serviceAccountBase64: string) {
  const credentials = JSON.parse(Buffer.from(serviceAccountBase64, 'base64').toString('utf8'));
  const app = getApps()[0] ?? initializeApp({ credential: cert(credentials) });
  return getAuth(app);
}
