import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import type { PrismaClient } from '@prisma/client';
import { z } from 'zod';
import { ah } from '../../lib/async-handler';
import { AppError } from '../../lib/errors';
import type { CredentialsService } from './credentials-service';

const forgotSchema = z.object({ email: z.string().trim().toLowerCase().email().max(254) }).strict();

/** Rutas PÚBLICAS (no exigen sesión). Se montan antes del router autenticado. */
export function authRouter(deps: { prisma: PrismaClient; credentials: CredentialsService }) {
  const { prisma, credentials } = deps;
  const r = Router();

  // Límite estricto por IP: evita usarlo para enviar correo masivo a terceros
  const limiter = rateLimit({
    windowMs: 15 * 60_000,
    limit: 5,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    message: { error: { code: 'RATE_LIMITED', message: 'Demasiados intentos. Intenta de nuevo más tarde.' } },
  });

  r.post(
    '/forgot-password',
    limiter,
    ah(async (req, res) => {
      const { email } = forgotSchema.parse(req.body);
      // Sin proveedor de correo no existe esta vía: la persona pide un enlace nuevo a la administración
      if (!credentials.emailEnabled) {
        throw new AppError(501, 'EMAIL_DISABLED', 'Este gimnasio no envía correos. Pide un enlace nuevo a la administración.');
      }

      // Misma respuesta exista o no la cuenta (no se puede averiguar qué correos están registrados)
      res.status(202).json({ data: { ok: true } });

      // El envío ocurre después de responder, para que el tiempo de respuesta tampoco delate nada
      void (async () => {
        const user = await prisma.user.findFirst({
          where: { email, deletedAt: null, status: { not: 'SUSPENDED' } },
          select: { name: true },
        });
        if (user) await credentials.sendPasswordReset({ to: email, name: user.name });
      })().catch((err) => console.error('forgot-password falló', err));
    }),
  );

  return r;
}
