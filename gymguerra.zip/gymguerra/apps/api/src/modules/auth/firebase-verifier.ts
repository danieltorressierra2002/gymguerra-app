import { getFirebaseAuth } from './firebase-app';
import type { TokenVerifier } from './verifier';

/**
 * Verifica ID tokens de Firebase Auth en el servidor (transición).
 * La cuenta de servicio llega por variable de entorno en base64:
 * nunca va en el código ni en el frontend.
 */
export function createFirebaseVerifier(serviceAccountBase64: string): TokenVerifier {
  const auth = getFirebaseAuth(serviceAccountBase64);
  return {
    async verify(token) {
      // checkRevoked=true: un token de una sesión revocada deja de servir
      const decoded = await auth.verifyIdToken(token, true);
      return {
        provider: 'firebase',
        subject: decoded.uid,
        email: decoded.email,
        emailVerified: decoded.email_verified === true,
      };
    },
  };
}
