import { Router } from 'express';
import { ah } from '../../lib/async-handler';
import { uuid } from '../../lib/validators';
import { requestMeta, requireRole } from '../../middleware/auth';
import type { CategoryService } from '../categories/service';
import {
  adminListQuerySchema,
  createProductSchema,
  publicListQuerySchema,
  slugParam,
  updateProductSchema,
} from './schemas';
import type { ProductService } from './service';

const PUBLIC_CACHE = 'public, max-age=60';

/** Tienda pública: se ve sin iniciar sesión. */
export function publicStoreRouter(products: ProductService, categories: CategoryService) {
  const r = Router();

  r.get(
    '/categories',
    ah(async (_req, res) => {
      res.set('Cache-Control', PUBLIC_CACHE).json({ data: await categories.listPublic() });
    }),
  );

  r.get(
    '/products',
    ah(async (req, res) => {
      res.set('Cache-Control', PUBLIC_CACHE).json(await products.listPublic(publicListQuerySchema.parse(req.query)));
    }),
  );

  r.get(
    '/products/:slug',
    ah(async (req, res) => {
      const data = await products.getPublic(slugParam.parse(req.params.slug));
      res.set('Cache-Control', PUBLIC_CACHE).json({ data });
    }),
  );

  return r;
}

/** Gestión de productos: solo el administrador. */
export function productsRouter(service: ProductService) {
  const r = Router();
  r.use(requireRole('ADMIN'));

  r.get('/', ah(async (req, res) => void res.json(await service.list(adminListQuerySchema.parse(req.query)))));

  r.get('/:id', ah(async (req, res) => void res.json({ data: await service.get(uuid.parse(req.params.id)) })));

  r.post(
    '/',
    ah(async (req, res) => {
      const data = await service.create(req.user!, createProductSchema.parse(req.body), requestMeta(req));
      res.status(201).json({ data });
    }),
  );

  r.patch(
    '/:id',
    ah(async (req, res) => {
      const data = await service.update(
        req.user!,
        uuid.parse(req.params.id),
        updateProductSchema.parse(req.body ?? {}),
        requestMeta(req),
      );
      res.json({ data });
    }),
  );

  r.delete(
    '/:id',
    ah(async (req, res) => {
      await service.remove(req.user!, uuid.parse(req.params.id), requestMeta(req));
      res.status(204).end();
    }),
  );

  return r;
}
