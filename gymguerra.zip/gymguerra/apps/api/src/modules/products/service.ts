import { Prisma, type PrismaClient } from '@prisma/client';
import { slugify } from '@gymguerra/shared';
import { audit, type RequestMeta } from '../../lib/audit';
import { AppError } from '../../lib/errors';
import type { Actor } from '../../lib/permissions';
import { uniqueSlug } from '../../lib/unique-slug';
import type {
  AdminListQuery,
  CreateProductInput,
  PublicListQuery,
  UpdateProductInput,
} from './schemas';

type Db = Prisma.TransactionClient;

const adminSelect = {
  id: true,
  categoryId: true,
  sku: true,
  name: true,
  slug: true,
  description: true,
  price: true,
  currency: true,
  imageUrl: true,
  isActive: true,
  createdAt: true,
  updatedAt: true,
  category: { select: { id: true, name: true, slug: true } },
} satisfies Prisma.ProductSelect;

const publicSelect = {
  id: true,
  name: true,
  slug: true,
  description: true,
  price: true,
  currency: true,
  imageUrl: true,
  category: { select: { name: true, slug: true } },
} satisfies Prisma.ProductSelect;

type PublicRow = Prisma.ProductGetPayload<{ select: typeof publicSelect }>;

/** Solo lo que un visitante necesita ver, aunque la consulta devuelva más. */
export function presentPublicProduct(row: PublicRow) {
  return {
    id: row.id,
    name: row.name,
    slug: row.slug,
    description: row.description,
    price: row.price,
    currency: row.currency,
    imageUrl: row.imageUrl,
    category: { name: row.category.name, slug: row.category.slug },
  };
}

export function createProductService({ prisma, now = () => new Date() }: { prisma: PrismaClient; now?: () => Date }) {
  async function assertCategory(db: Pick<Db, 'productCategory'>, categoryId: string) {
    const c = await db.productCategory.findFirst({ where: { id: categoryId, deletedAt: null }, select: { id: true } });
    if (!c) throw AppError.badRequest('CATEGORY_UNAVAILABLE', 'La categoría no existe');
  }

  async function assertSkuFree(db: Pick<Db, 'product'>, sku: string, excludeId?: string) {
    const taken = await db.product.findFirst({
      where: { sku, ...(excludeId ? { id: { not: excludeId } } : {}) },
      select: { id: true },
    });
    if (taken) throw AppError.conflict('SKU_TAKEN', 'Ya existe un producto con ese SKU');
  }

  return {
    // ───────── tienda pública (sin sesión) ─────────
    async listPublic(q: PublicListQuery) {
      const where: Prisma.ProductWhereInput = {
        isActive: true,
        deletedAt: null,
        category: { isActive: true, deletedAt: null, ...(q.category ? { slug: q.category } : {}) },
        ...(q.q
          ? {
              OR: [
                { name: { contains: q.q, mode: 'insensitive' } },
                { description: { contains: q.q, mode: 'insensitive' } },
              ],
            }
          : {}),
      };
      const [total, rows] = await Promise.all([
        prisma.product.count({ where }),
        prisma.product.findMany({
          where,
          select: publicSelect,
          orderBy: [{ createdAt: 'desc' }, { id: 'asc' }],
          skip: (q.page - 1) * q.pageSize,
          take: q.pageSize,
        }),
      ]);
      return { items: rows.map(presentPublicProduct), total, page: q.page, pageSize: q.pageSize };
    },

    async getPublic(slug: string) {
      const row = await prisma.product.findFirst({
        where: { slug, isActive: true, deletedAt: null, category: { isActive: true, deletedAt: null } },
        select: publicSelect,
      });
      if (!row) throw AppError.notFound('Producto no encontrado');
      return presentPublicProduct(row);
    },

    // ───────── administración ─────────
    async list(q: AdminListQuery) {
      const and: Prisma.ProductWhereInput[] = [{ deletedAt: null }];
      if (q.categoryId) and.push({ categoryId: q.categoryId });
      if (q.isActive !== undefined) and.push({ isActive: q.isActive });
      if (q.q) {
        and.push({
          OR: [
            { name: { contains: q.q, mode: 'insensitive' } },
            { sku: { contains: q.q, mode: 'insensitive' } },
          ],
        });
      }
      const where: Prisma.ProductWhereInput = { AND: and };
      const [total, items] = await Promise.all([
        prisma.product.count({ where }),
        prisma.product.findMany({
          where,
          select: adminSelect,
          orderBy: [{ createdAt: 'desc' }, { id: 'asc' }],
          skip: (q.page - 1) * q.pageSize,
          take: q.pageSize,
        }),
      ]);
      return { items, total, page: q.page, pageSize: q.pageSize };
    },

    async get(id: string) {
      const row = await prisma.product.findFirst({ where: { id, deletedAt: null }, select: adminSelect });
      if (!row) throw AppError.notFound('Producto no encontrado');
      return row;
    },

    async create(actor: Actor, input: CreateProductInput, meta: RequestMeta) {
      return prisma.$transaction(async (tx) => {
        await assertCategory(tx, input.categoryId);
        if (input.sku) await assertSkuFree(tx, input.sku);

        // El slug no cambia al editar el nombre, para no romper enlaces compartidos
        const slug = await uniqueSlug(slugify(input.name), async (s) =>
          Boolean(await tx.product.findUnique({ where: { slug: s }, select: { id: true } })),
        );
        const created = await tx.product.create({
          data: {
            categoryId: input.categoryId,
            name: input.name,
            slug,
            description: input.description,
            price: new Prisma.Decimal(input.price),
            currency: input.currency,
            imageUrl: input.imageUrl,
            sku: input.sku,
            isActive: input.isActive,
          },
          select: adminSelect,
        });
        await audit(tx, {
          actorId: actor.id,
          action: 'product.create',
          entityType: 'Product',
          entityId: created.id,
          after: { name: input.name, price: input.price, currency: input.currency },
          meta,
        });
        return created;
      });
    },

    /**
     * Editar precio o nombre NO cambia los pedidos ya hechos: cada pedido guarda
     * el nombre y el precio con los que se compró.
     */
    async update(actor: Actor, id: string, input: UpdateProductInput, meta: RequestMeta) {
      return prisma.$transaction(async (tx) => {
        const current = await tx.product.findFirst({ where: { id, deletedAt: null }, select: { price: true } });
        if (!current) throw AppError.notFound('Producto no encontrado');
        if (input.categoryId !== undefined) await assertCategory(tx, input.categoryId);
        if (input.sku) await assertSkuFree(tx, input.sku, id);

        const data: Prisma.ProductUncheckedUpdateInput = {};
        if (input.categoryId !== undefined) data.categoryId = input.categoryId;
        if (input.name !== undefined) data.name = input.name;
        if (input.description !== undefined) data.description = input.description;
        if (input.price !== undefined) data.price = new Prisma.Decimal(input.price);
        if (input.currency !== undefined) data.currency = input.currency;
        if (input.imageUrl !== undefined) data.imageUrl = input.imageUrl;
        if (input.sku !== undefined) data.sku = input.sku;
        if (input.isActive !== undefined) data.isActive = input.isActive;

        const updated = await tx.product.update({ where: { id }, data, select: adminSelect });
        await audit(tx, {
          actorId: actor.id,
          action: 'product.update',
          entityType: 'Product',
          entityId: id,
          after: {
            changed: Object.keys(input),
            ...(input.price !== undefined ? { price: input.price, previousPrice: current.price.toString() } : {}),
          },
          meta,
        });
        return updated;
      });
    },

    /**
     * «Quitar» un producto (p. ej. cuando se agota): baja lógica. Desaparece de la tienda
     * y libera su SKU, pero los pedidos antiguos conservan su historial.
     * Para ocultarlo temporalmente sin borrarlo, usa isActive = false.
     */
    async remove(actor: Actor, id: string, meta: RequestMeta) {
      await prisma.$transaction(async (tx) => {
        const current = await tx.product.findFirst({ where: { id, deletedAt: null }, select: { id: true } });
        if (!current) throw AppError.notFound('Producto no encontrado');
        await tx.product.update({ where: { id }, data: { deletedAt: now(), isActive: false, sku: null } });
        await audit(tx, {
          actorId: actor.id,
          action: 'product.delete',
          entityType: 'Product',
          entityId: id,
          meta,
        });
      });
    },
  };
}

export type ProductService = ReturnType<typeof createProductService>;
