import { z } from 'zod';
import { uuid } from '../../lib/validators';
import { money } from '../payments/schemas';

const name = z.string().trim().min(2).max(120);
const description = z.string().trim().max(1000);
const currency = z.string().regex(/^[A-Z]{3}$/, 'Moneda ISO de 3 letras mayúsculas (p. ej. USD)');
// Solo https: evita contenido mixto y esquemas peligrosos (javascript:, data:)
const imageUrl = z
  .string()
  .trim()
  .url()
  .max(500)
  .refine((u) => u.startsWith('https://'), 'La imagen debe usar https');
const sku = z.string().trim().min(1).max(40);
const bool = z
  .enum(['true', 'false'])
  .transform((v) => v === 'true')
  .optional();

export const createProductSchema = z
  .object({
    categoryId: uuid,
    name,
    description: description.optional(),
    price: money,
    currency,
    imageUrl: imageUrl.optional(),
    sku: sku.optional(),
    isActive: z.boolean().default(true),
  })
  .strict();

/** `null` borra descripción, imagen o SKU. */
export const updateProductSchema = z
  .object({
    categoryId: uuid,
    name,
    description: description.nullable(),
    price: money,
    currency,
    imageUrl: imageUrl.nullable(),
    sku: sku.nullable(),
    isActive: z.boolean(),
  })
  .partial()
  .strict();

export const adminListQuerySchema = z.object({
  q: z.string().trim().min(1).max(100).optional(),
  categoryId: uuid.optional(),
  isActive: bool,
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(20),
});

export const publicListQuerySchema = z.object({
  category: z.string().regex(/^[a-z0-9-]{1,80}$/).optional(),
  q: z.string().trim().min(1).max(100).optional(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(48).default(12),
});

export const slugParam = z.string().regex(/^[a-z0-9-]{1,120}$/, 'Identificador inválido');

export type CreateProductInput = z.infer<typeof createProductSchema>;
export type UpdateProductInput = z.infer<typeof updateProductSchema>;
export type AdminListQuery = z.infer<typeof adminListQuerySchema>;
export type PublicListQuery = z.infer<typeof publicListQuerySchema>;
