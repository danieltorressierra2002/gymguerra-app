import { Router } from 'express';
import { ah } from '../../lib/async-handler';
import { requestMeta, requireRole } from '../../middleware/auth';
import {
  cancelSchema,
  createSchema,
  freezeSchema,
  listQuerySchema,
  renewSchema,
  uuid,
} from './schemas';
import type { MembershipService } from './service';

export function membershipsRouter(service: MembershipService) {
  const r = Router();

  // Cliente: su propia membresía (debe ir antes de /:id)
  r.get(
    '/me',
    requireRole('MEMBER'),
    ah(async (req, res) => {
      res.json({ data: await service.getMine(req.user!) });
    }),
  );

  // Listado con filtros. Entrenador: solo sus clientes. Cliente: solo lo suyo.
  r.get(
    '/',
    requireRole('ADMIN', 'TRAINER', 'MEMBER'),
    ah(async (req, res) => {
      res.json(await service.list(req.user!, listQuerySchema.parse(req.query)));
    }),
  );

  r.get(
    '/:id',
    requireRole('ADMIN', 'TRAINER', 'MEMBER'),
    ah(async (req, res) => {
      res.json({ data: await service.getById(req.user!, uuid.parse(req.params.id)) });
    }),
  );

  // ── Escritura: solo administrador ──
  r.post(
    '/',
    requireRole('ADMIN'),
    ah(async (req, res) => {
      const data = await service.create(req.user!, createSchema.parse(req.body), requestMeta(req));
      res.status(201).json({ data });
    }),
  );

  r.post(
    '/:id/renew',
    requireRole('ADMIN'),
    ah(async (req, res) => {
      const data = await service.renew(
        req.user!,
        uuid.parse(req.params.id),
        renewSchema.parse(req.body ?? {}),
        requestMeta(req),
      );
      res.status(201).json({ data });
    }),
  );

  r.post(
    '/:id/freeze',
    requireRole('ADMIN'),
    ah(async (req, res) => {
      const data = await service.freeze(
        req.user!,
        uuid.parse(req.params.id),
        freezeSchema.parse(req.body ?? {}),
        requestMeta(req),
      );
      res.json({ data });
    }),
  );

  r.post(
    '/:id/unfreeze',
    requireRole('ADMIN'),
    ah(async (req, res) => {
      res.json({
        data: await service.unfreeze(req.user!, uuid.parse(req.params.id), requestMeta(req)),
      });
    }),
  );

  r.post(
    '/:id/cancel',
    requireRole('ADMIN'),
    ah(async (req, res) => {
      const data = await service.cancel(
        req.user!,
        uuid.parse(req.params.id),
        cancelSchema.parse(req.body),
        requestMeta(req),
      );
      res.json({ data });
    }),
  );

  return r;
}
