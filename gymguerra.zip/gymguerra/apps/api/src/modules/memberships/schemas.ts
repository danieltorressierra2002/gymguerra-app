import { z } from 'zod';
import { isoDate, uuid } from '../../lib/validators';
import { paymentInputSchema } from '../payments/schemas';

export { isoDate, uuid };

export const createSchema = z
  .object({
    memberId: uuid,
    planId: uuid,
    startDate: isoDate.optional(),
    payment: paymentInputSchema.optional(),
  })
  .strict();

export const renewSchema = z
  .object({
    planId: uuid.optional(),
    startDate: isoDate.optional(),
    payment: paymentInputSchema.optional(),
  })
  .strict();

export const freezeSchema = z.object({ reason: z.string().trim().max(500).optional() }).strict();
export const cancelSchema = z.object({ reason: z.string().trim().min(3).max(500) }).strict();

export const listQuerySchema = z.object({
  state: z.enum(['OK', 'EXPIRING', 'EXPIRED', 'FROZEN', 'CANCELLED']).optional(),
  memberId: uuid.optional(),
  planId: uuid.optional(),
  trainerId: uuid.optional(),
  paymentMethod: z.enum(['CASH', 'TRANSFER', 'CARD', 'ONLINE']).optional(),
  endFrom: isoDate.optional(),
  endTo: isoDate.optional(),
  q: z.string().trim().min(1).max(100).optional(),
  sort: z.enum(['endDate', 'startDate', 'createdAt']).default('endDate'),
  dir: z.enum(['asc', 'desc']).default('asc'),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(20),
});

export type CreateInput = z.infer<typeof createSchema>;
export type RenewInput = z.infer<typeof renewSchema>;
export type FreezeInput = z.infer<typeof freezeSchema>;
export type CancelInput = z.infer<typeof cancelSchema>;
export type ListQuery = z.infer<typeof listQuerySchema>;
