import type { Prisma, PrismaClient } from '@prisma/client';
import {
  addDays,
  computeEndDate,
  computeSemaforo,
  nextStartDate,
  todayInTimeZone,
  unfreezeEndDate,
  type PlanDuration,
  type SemaforoState,
} from '@gymguerra/shared';
import { audit, type RequestMeta } from '../../lib/audit';
import { AppError } from '../../lib/errors';
import { canViewMember, type Actor } from '../../lib/permissions';
import { recordMembershipPayment } from '../payments/service';
import { getMembershipSettings } from '../settings/service';
import type { CancelInput, CreateInput, FreezeInput, ListQuery, RenewInput } from './schemas';

type Db = Prisma.TransactionClient;

const toIso = (d: Date) => d.toISOString().slice(0, 10);
const fromIso = (s: string) => new Date(`${s}T00:00:00.000Z`);

const include = {
  plan: { select: { id: true, name: true, durationMonths: true, durationDays: true } },
  member: {
    select: {
      id: true,
      documentId: true,
      trainerId: true,
      user: { select: { name: true, email: true } },
    },
  },
} satisfies Prisma.MembershipInclude;

type Row = Prisma.MembershipGetPayload<{ include: typeof include }>;
interface Ctx {
  today: string;
  warningDays: number;
}

function planDuration(plan: { durationMonths: number | null; durationDays: number | null }): PlanDuration {
  if (plan.durationMonths) return { months: plan.durationMonths };
  if (plan.durationDays) return { days: plan.durationDays };
  throw AppError.badRequest('PLAN_INVALID', 'El plan no tiene una duración válida');
}

/** Filtro SQL equivalente a computeSemaforo, para filtrar listados en la base de datos. */
function semaforoWhere(state: SemaforoState, ctx: Ctx): Prisma.MembershipWhereInput {
  const today = fromIso(ctx.today);
  const limit = fromIso(addDays(ctx.today, ctx.warningDays));
  switch (state) {
    case 'OK':
      return { status: 'ACTIVE', endDate: { gt: limit } };
    case 'EXPIRING':
      return { status: 'ACTIVE', endDate: { gte: today, lte: limit } };
    case 'EXPIRED':
      return { status: 'ACTIVE', endDate: { lt: today } };
    case 'FROZEN':
      return { status: 'FROZEN' };
    case 'CANCELLED':
      return { status: 'CANCELLED' };
  }
}

function present(row: Row, ctx: Ctx) {
  const endDate = toIso(row.endDate);
  return {
    ...row,
    startDate: toIso(row.startDate),
    endDate,
    frozenAt: row.frozenAt ? toIso(row.frozenAt) : null,
    semaforo: computeSemaforo({
      status: row.status,
      endDate,
      frozenAt: row.frozenAt ? toIso(row.frozenAt) : null,
      today: ctx.today,
      warningDays: ctx.warningDays,
    }),
  };
}

export interface MembershipServiceDeps {
  prisma: PrismaClient;
  /** Zona horaria IANA del gimnasio: define qué día es "hoy" */
  timeZone: string;
  /** Reloj inyectable para pruebas */
  now?: () => Date;
}

export function createMembershipService({ prisma, timeZone, now = () => new Date() }: MembershipServiceDeps) {
  const context = async (db: Pick<Db, 'setting'> = prisma): Promise<Ctx> => ({
    today: todayInTimeZone(timeZone, now()),
    ...(await getMembershipSettings(db)),
  });

  async function load(db: Db | PrismaClient, id: string): Promise<Row> {
    const row = await db.membership.findUnique({ where: { id }, include });
    if (!row) throw AppError.notFound('Membresía no encontrada');
    return row;
  }

  /** Si el actor no puede verla, responde 404 (no revela que existe). */
  function assertVisible(actor: Actor, row: Row) {
    if (!canViewMember(actor, { memberId: row.memberId, trainerId: row.member.trainerId })) {
      throw AppError.notFound('Membresía no encontrada');
    }
  }

  async function activePlan(db: Db, planId: string) {
    const plan = await db.membershipPlan.findFirst({
      where: { id: planId, isActive: true, deletedAt: null },
    });
    if (!plan) throw AppError.badRequest('PLAN_UNAVAILABLE', 'El plan no existe o no está disponible');
    return plan;
  }

  return {
    async list(actor: Actor, q: ListQuery) {
      const ctx = await context();
      const and: Prisma.MembershipWhereInput[] = [{ member: { deletedAt: null } }];

      // Alcance por rol
      if (actor.role === 'MEMBER') {
        if (!actor.memberId) throw AppError.forbidden();
        and.push({ memberId: actor.memberId });
      } else if (actor.role === 'TRAINER') {
        if (!actor.trainerId) throw AppError.forbidden();
        and.push({ member: { trainerId: actor.trainerId } });
      }

      if (q.memberId) and.push({ memberId: q.memberId });
      if (q.trainerId) and.push({ member: { trainerId: q.trainerId } });
      if (q.planId) and.push({ planId: q.planId });
      if (q.state) and.push(semaforoWhere(q.state, ctx));
      if (q.paymentMethod) {
        and.push({ payments: { some: { method: q.paymentMethod, status: 'PAID' } } });
      }
      if (q.endFrom) and.push({ endDate: { gte: fromIso(q.endFrom) } });
      if (q.endTo) and.push({ endDate: { lte: fromIso(q.endTo) } });
      if (q.q) {
        and.push({
          OR: [
            { member: { documentId: { contains: q.q } } },
            { member: { user: { name: { contains: q.q, mode: 'insensitive' } } } },
          ],
        });
      }

      const where: Prisma.MembershipWhereInput = { AND: and };
      const [total, rows] = await Promise.all([
        prisma.membership.count({ where }),
        prisma.membership.findMany({
          where,
          include,
          orderBy: [{ [q.sort]: q.dir }, { id: 'asc' }],
          skip: (q.page - 1) * q.pageSize,
          take: q.pageSize,
        }),
      ]);

      return {
        items: rows.map((r) => present(r, ctx)),
        total,
        page: q.page,
        pageSize: q.pageSize,
      };
    },

    async getById(actor: Actor, id: string) {
      const ctx = await context();
      const row = await load(prisma, id);
      assertVisible(actor, row);
      return present(row, ctx);
    },

    /** Membresía vigente del cliente que inició sesión (panel de usuario). */
    async getMine(actor: Actor) {
      if (!actor.memberId) throw AppError.forbidden();
      const ctx = await context();
      const row = await prisma.membership.findFirst({
        where: { memberId: actor.memberId, status: { not: 'CANCELLED' } },
        orderBy: { endDate: 'desc' },
        include,
      });
      return row ? present(row, ctx) : null;
    },

    async create(actor: Actor, input: CreateInput, meta: RequestMeta) {
      const ctx = await context();
      const id = await prisma.$transaction(async (tx) => {
        const member = await tx.member.findFirst({
          where: { id: input.memberId, deletedAt: null },
          select: { id: true },
        });
        if (!member) throw AppError.notFound('Cliente no encontrado');

        const plan = await activePlan(tx, input.planId);
        const startDate = input.startDate ?? ctx.today;
        const endDate = computeEndDate(startDate, planDuration(plan));

        const created = await tx.membership.create({
          data: {
            memberId: member.id,
            planId: plan.id,
            startDate: fromIso(startDate),
            endDate: fromIso(endDate),
            priceSnapshot: plan.price,
            currency: plan.currency,
            createdById: actor.id,
          },
          select: { id: true },
        });

        await tx.membershipEvent.create({
          data: { membershipId: created.id, type: 'CREATED', actorId: actor.id, payload: { startDate, endDate } },
        });

        if (input.payment) {
          await recordMembershipPayment(tx, {
            actorId: actor.id,
            memberId: member.id,
            membershipId: created.id,
            defaultAmount: plan.price,
            currency: plan.currency,
            input: input.payment,
          });
        }

        await audit(tx, {
          actorId: actor.id,
          action: 'membership.create',
          entityType: 'Membership',
          entityId: created.id,
          after: { memberId: member.id, planId: plan.id, startDate, endDate },
          meta,
        });
        return created.id;
      });
      return present(await load(prisma, id), ctx);
    },

    async renew(actor: Actor, id: string, input: RenewInput, meta: RequestMeta) {
      const ctx = await context();
      const newId = await prisma.$transaction(async (tx) => {
        const prev = await load(tx, id);
        if (prev.status !== 'ACTIVE') {
          throw AppError.conflict(
            'NOT_RENEWABLE',
            'Solo se renueva una membresía activa. Reanuda la pausa o crea una nueva.',
          );
        }
        const alreadyRenewed = await tx.membership.findUnique({
          where: { renewedFromId: id },
          select: { id: true },
        });
        if (alreadyRenewed) throw AppError.conflict('ALREADY_RENEWED', 'Esta membresía ya fue renovada');

        const plan = await activePlan(tx, input.planId ?? prev.planId);
        const prevEnd = toIso(prev.endDate);
        const startDate = input.startDate ?? nextStartDate(prevEnd, ctx.today);
        // Las fechas ISO se comparan como texto sin errores de zona horaria
        if (startDate < prevEnd) {
          throw AppError.badRequest(
            'INVALID_START_DATE',
            `La renovación no puede empezar antes del vencimiento actual (${prevEnd})`,
          );
        }
        const endDate = computeEndDate(startDate, planDuration(plan));

        const created = await tx.membership.create({
          data: {
            memberId: prev.memberId,
            planId: plan.id,
            startDate: fromIso(startDate),
            endDate: fromIso(endDate),
            priceSnapshot: plan.price,
            currency: plan.currency,
            renewedFromId: prev.id,
            createdById: actor.id,
          },
          select: { id: true },
        });

        await tx.membershipEvent.create({
          data: {
            membershipId: created.id,
            type: 'RENEWED',
            actorId: actor.id,
            payload: { renewedFrom: prev.id, startDate, endDate },
          },
        });

        if (input.payment) {
          await recordMembershipPayment(tx, {
            actorId: actor.id,
            memberId: prev.memberId,
            membershipId: created.id,
            defaultAmount: plan.price,
            currency: plan.currency,
            input: input.payment,
          });
        }

        await audit(tx, {
          actorId: actor.id,
          action: 'membership.renew',
          entityType: 'Membership',
          entityId: created.id,
          before: { renewedFrom: prev.id, endDate: prevEnd },
          after: { startDate, endDate, planId: plan.id },
          meta,
        });
        return created.id;
      });
      return present(await load(prisma, newId), ctx);
    },

    async freeze(actor: Actor, id: string, input: FreezeInput, meta: RequestMeta) {
      const ctx = await context();
      await prisma.$transaction(async (tx) => {
        const row = await load(tx, id);
        if (row.status !== 'ACTIVE') {
          throw AppError.conflict('NOT_FREEZABLE', 'Solo se puede pausar una membresía activa');
        }
        const { state } = computeSemaforo({
          status: row.status,
          endDate: toIso(row.endDate),
          today: ctx.today,
          warningDays: ctx.warningDays,
        });
        if (state === 'EXPIRED') {
          throw AppError.conflict('EXPIRED', 'No se puede pausar una membresía vencida; renuévala');
        }

        // updateMany con el estado esperado evita aplicar la acción dos veces si hay doble clic
        const { count } = await tx.membership.updateMany({
          where: { id, status: 'ACTIVE' },
          data: { status: 'FROZEN', frozenAt: fromIso(ctx.today) },
        });
        if (count === 0) throw AppError.conflict('STALE', 'La membresía cambió; recarga e intenta de nuevo');

        await tx.membershipEvent.create({
          data: { membershipId: id, type: 'FROZEN', actorId: actor.id, payload: { reason: input.reason ?? null } },
        });
        await audit(tx, {
          actorId: actor.id,
          action: 'membership.freeze',
          entityType: 'Membership',
          entityId: id,
          before: { status: 'ACTIVE' },
          after: { status: 'FROZEN', frozenAt: ctx.today, reason: input.reason ?? null },
          meta,
        });
      });
      return present(await load(prisma, id), ctx);
    },

    async unfreeze(actor: Actor, id: string, meta: RequestMeta) {
      const ctx = await context();
      await prisma.$transaction(async (tx) => {
        const row = await load(tx, id);
        if (row.status !== 'FROZEN') {
          throw AppError.conflict('NOT_FROZEN', 'La membresía no está pausada');
        }
        const frozenAt = row.frozenAt ? toIso(row.frozenAt) : ctx.today;
        const prevEnd = toIso(row.endDate);
        const { endDate, extraDays } = unfreezeEndDate(prevEnd, frozenAt, ctx.today);

        const { count } = await tx.membership.updateMany({
          where: { id, status: 'FROZEN' },
          data: {
            status: 'ACTIVE',
            frozenAt: null,
            endDate: fromIso(endDate),
            frozenDaysTotal: { increment: extraDays },
          },
        });
        if (count === 0) throw AppError.conflict('STALE', 'La membresía cambió; recarga e intenta de nuevo');

        await tx.membershipEvent.create({
          data: { membershipId: id, type: 'UNFROZEN', actorId: actor.id, payload: { extraDays, endDate } },
        });
        await audit(tx, {
          actorId: actor.id,
          action: 'membership.unfreeze',
          entityType: 'Membership',
          entityId: id,
          before: { status: 'FROZEN', endDate: prevEnd },
          after: { status: 'ACTIVE', endDate, extraDays },
          meta,
        });
      });
      return present(await load(prisma, id), ctx);
    },

    async cancel(actor: Actor, id: string, input: CancelInput, meta: RequestMeta) {
      const ctx = await context();
      await prisma.$transaction(async (tx) => {
        const row = await load(tx, id);
        if (row.status === 'CANCELLED') {
          throw AppError.conflict('ALREADY_CANCELLED', 'La membresía ya está cancelada');
        }
        const { count } = await tx.membership.updateMany({
          where: { id, status: { in: ['ACTIVE', 'FROZEN'] } },
          data: { status: 'CANCELLED', cancelledAt: now(), cancelReason: input.reason, frozenAt: null },
        });
        if (count === 0) throw AppError.conflict('STALE', 'La membresía cambió; recarga e intenta de nuevo');

        await tx.membershipEvent.create({
          data: { membershipId: id, type: 'CANCELLED', actorId: actor.id, payload: { reason: input.reason } },
        });
        await audit(tx, {
          actorId: actor.id,
          action: 'membership.cancel',
          entityType: 'Membership',
          entityId: id,
          before: { status: row.status },
          after: { status: 'CANCELLED', reason: input.reason },
          meta,
        });
      });
      return present(await load(prisma, id), ctx);
    },
  };
}

export type MembershipService = ReturnType<typeof createMembershipService>;
