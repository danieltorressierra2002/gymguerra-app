import { Router } from 'express';
import { z } from 'zod';
import { LEGAL_DOCUMENTS } from '@gymguerra/shared';
import { ah } from '../../lib/async-handler';
import { requestMeta } from '../../middleware/auth';
import type { ConsentService } from './service';

const acceptSchema = z
  .object({
    documents: z
      .array(
        z
          .object({ type: z.enum(['TERMS', 'PRIVACY', 'STORE_TERMS']), version: z.string().trim().min(1).max(20) })
          .strict(),
      )
      .min(1)
      .max(3),
  })
  .strict();

/** Versiones vigentes de los documentos legales: pública, para que la web sepa qué mostrar. */
export function publicLegalRouter() {
  const r = Router();
  r.get('/legal', (_req, res) => {
    res.set('Cache-Control', 'public, max-age=300').json({ data: { documents: LEGAL_DOCUMENTS } });
  });
  return r;
}

/** Requiere sesión; cualquier rol acepta los documentos para sí mismo. */
export function consentsRouter(service: ConsentService) {
  const r = Router();

  r.get(
    '/me',
    ah(async (req, res) => {
      res.json({ data: await service.status(req.user!) });
    }),
  );

  r.post(
    '/',
    ah(async (req, res) => {
      const { documents } = acceptSchema.parse(req.body);
      res.status(201).json({ data: await service.accept(req.user!, documents, requestMeta(req)) });
    }),
  );

  return r;
}
