import type { PrismaClient } from '@prisma/client';
import { LEGAL_DOCUMENTS, pendingDocuments, type LegalDocumentType } from '@gymguerra/shared';
import type { RequestMeta } from '../../lib/audit';
import { AppError } from '../../lib/errors';
import type { Actor } from '../../lib/permissions';

export function createConsentService({ prisma }: { prisma: PrismaClient }) {
  async function status(actor: Actor) {
    const accepted = await prisma.consent.findMany({
      where: { userId: actor.id },
      select: { documentType: true, version: true, acceptedAt: true },
      orderBy: { acceptedAt: 'desc' },
    });
    return { current: LEGAL_DOCUMENTS, accepted, pending: pendingDocuments(accepted) };
  }

  return {
    status,

    /**
     * Registra la aceptación (con fecha, IP y navegador) SOLO de la versión vigente.
     * Si el documento cambió mientras la persona lo leía, se rechaza para que lo vuelva a leer.
     */
    async accept(
      actor: Actor,
      documents: Array<{ type: LegalDocumentType; version: string }>,
      meta: RequestMeta,
    ) {
      const stale = documents.filter((d) => d.version !== LEGAL_DOCUMENTS[d.type].version);
      if (stale.length > 0) {
        throw new AppError(409, 'STALE_VERSION', 'Los documentos se actualizaron. Léelos de nuevo antes de aceptar.', {
          current: LEGAL_DOCUMENTS,
        });
      }
      await prisma.consent.createMany({
        data: documents.map((d) => ({
          userId: actor.id,
          documentType: d.type,
          version: d.version,
          ip: meta.ip,
          userAgent: meta.userAgent,
        })),
        skipDuplicates: true,
      });
      return status(actor);
    },
  };
}

export type ConsentService = ReturnType<typeof createConsentService>;
