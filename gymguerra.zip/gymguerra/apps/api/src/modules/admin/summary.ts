import { Prisma, type PrismaClient } from '@prisma/client';
import { computeSemaforo, todayInTimeZone, zonedDayStart, type SemaforoState } from '@gymguerra/shared';
import { getMembershipSettings } from '../settings/service';

// ───────── lógica pura (se prueba sin base de datos) ─────────

export interface SnapshotRow {
  memberId: string;
  name: string;
  documentId: string;
  /** Última membresía no cancelada del cliente (null si nunca tuvo) */
  membership: {
    id: string;
    plan: string;
    status: 'ACTIVE' | 'FROZEN' | 'CANCELLED';
    endDate: string;
    frozenAt: string | null;
  } | null;
}

interface Ctx {
  today: string;
  warningDays: number;
}

function stateOf(row: SnapshotRow, ctx: Ctx) {
  if (!row.membership) return null;
  return computeSemaforo({ ...row.membership, today: ctx.today, warningDays: ctx.warningDays });
}

/** Cuenta CLIENTES (no membresías): cada uno entra una sola vez, según su membresía más reciente. */
export function countStates(rows: SnapshotRow[], ctx: Ctx) {
  const out = { total: rows.length, ok: 0, expiring: 0, expired: 0, frozen: 0, withoutMembership: 0 };
  for (const row of rows) {
    const s = stateOf(row, ctx);
    if (!s) out.withoutMembership++;
    else if (s.state === 'OK') out.ok++;
    else if (s.state === 'EXPIRING') out.expiring++;
    else if (s.state === 'EXPIRED') out.expired++;
    else if (s.state === 'FROZEN') out.frozen++;
  }
  return out;
}

export interface AttentionItem {
  memberId: string;
  name: string;
  membershipId: string;
  plan: string;
  endDate: string;
  state: SemaforoState;
  daysLeft: number | null;
}

/** Clientes que requieren atención: por vencer, o vencidos hace poco (hasta 30 días). Los más urgentes primero. */
export function pickAttention(rows: SnapshotRow[], ctx: Ctx, limit = 8): AttentionItem[] {
  const items: AttentionItem[] = [];
  for (const row of rows) {
    const s = stateOf(row, ctx);
    if (!row.membership || !s) continue;
    const recent = s.state === 'EXPIRED' && (s.daysLeft ?? 0) >= -30;
    if (s.state === 'EXPIRING' || recent) {
      items.push({
        memberId: row.memberId,
        name: row.name,
        membershipId: row.membership.id,
        plan: row.membership.plan,
        endDate: row.membership.endDate,
        state: s.state,
        daysLeft: s.daysLeft,
      });
    }
  }
  return items.sort((a, b) => (a.daysLeft ?? 0) - (b.daysLeft ?? 0) || a.name.localeCompare(b.name)).slice(0, limit);
}

/** ['2026-06', ..., '2026-11']: los últimos n meses terminando en el mes de `today`. */
export function lastMonths(today: string, n: number): string[] {
  const [y, m] = today.split('-').map(Number) as [number, number];
  const out: string[] = [];
  for (let i = n - 1; i >= 0; i--) {
    const idx = y * 12 + (m - 1) - i;
    out.push(`${Math.floor(idx / 12)}-${String((idx % 12) + 1).padStart(2, '0')}`);
  }
  return out;
}

/** Mes («AAAA-MM») en que cae un instante, medido en la zona horaria del gimnasio. */
export function monthKey(date: Date, timeZone: string): string {
  const parts = new Intl.DateTimeFormat('en-CA', { timeZone, year: 'numeric', month: '2-digit' }).formatToParts(date);
  const get = (t: string) => parts.find((p) => p.type === t)?.value ?? '';
  return `${get('year')}-${get('month')}`;
}

/** Ingresos por mes y moneda (nunca se suman monedas distintas). */
export function revenueSeries(
  payments: ReadonlyArray<{ amount: Prisma.Decimal | string; currency: string; paidAt: Date | null }>,
  months: string[],
  timeZone: string,
) {
  const totals = new Map<string, Prisma.Decimal>();
  for (const p of payments) {
    if (!p.paidAt) continue;
    const month = monthKey(p.paidAt, timeZone);
    if (!months.includes(month)) continue;
    const key = `${month}|${p.currency}`;
    totals.set(key, (totals.get(key) ?? new Prisma.Decimal(0)).plus(new Prisma.Decimal(p.amount)));
  }
  return [...totals.entries()]
    .map(([key, total]) => {
      const [month, currency] = key.split('|') as [string, string];
      return { month, currency, total: total.toFixed(2) };
    })
    .sort((a, b) => a.month.localeCompare(b.month) || a.currency.localeCompare(b.currency));
}

// ───────── servicio ─────────

const toIso = (d: Date) => d.toISOString().slice(0, 10);

export function createSummaryService({
  prisma,
  timeZone,
  now = () => new Date(),
}: {
  prisma: PrismaClient;
  timeZone: string;
  now?: () => Date;
}) {
  return {
    async summary() {
      const { warningDays } = await getMembershipSettings(prisma);
      const today = todayInTimeZone(timeZone, now());
      const months = lastMonths(today, 6);
      const since = zonedDayStart(`${months[0]}-01`, timeZone);

      const [members, payments, pendingPayment, toPrepare] = await Promise.all([
        prisma.member.findMany({
          where: { deletedAt: null },
          select: {
            id: true,
            documentId: true,
            user: { select: { name: true } },
            memberships: {
              where: { status: { not: 'CANCELLED' } },
              orderBy: { endDate: 'desc' },
              take: 1,
              select: { id: true, status: true, endDate: true, frozenAt: true, plan: { select: { name: true } } },
            },
          },
        }),
        prisma.payment.findMany({
          where: { status: 'PAID', paidAt: { gte: since } },
          select: { amount: true, currency: true, paidAt: true },
        }),
        prisma.order.count({ where: { status: 'PENDING' } }),
        prisma.order.count({ where: { status: 'PAID' } }),
      ]);

      const rows: SnapshotRow[] = members.map((m) => {
        const cur = m.memberships[0];
        return {
          memberId: m.id,
          name: m.user.name,
          documentId: m.documentId,
          membership: cur
            ? {
                id: cur.id,
                plan: cur.plan.name,
                status: cur.status,
                endDate: toIso(cur.endDate),
                frozenAt: cur.frozenAt ? toIso(cur.frozenAt) : null,
              }
            : null,
        };
      });
      const ctx = { today, warningDays };

      return {
        asOf: today,
        warningDays,
        members: countStates(rows, ctx),
        attention: pickAttention(rows, ctx),
        revenue: { months, series: revenueSeries(payments, months, timeZone) },
        orders: { pendingPayment, toPrepare },
      };
    },
  };
}

export type SummaryService = ReturnType<typeof createSummaryService>;
