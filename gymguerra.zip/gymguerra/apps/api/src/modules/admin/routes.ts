import { Router } from 'express';
import { ah } from '../../lib/async-handler';
import { requireRole } from '../../middleware/auth';
import type { SummaryService } from './summary';

export function adminRouter(summary: SummaryService) {
  const r = Router();
  r.use(requireRole('ADMIN'));

  // Resumen del panel: miembros por estado, ingresos de 6 meses, pedidos y clientes que requieren atención
  r.get(
    '/summary',
    ah(async (_req, res) => {
      res.set('Cache-Control', 'no-store').json({ data: await summary.summary() });
    }),
  );

  return r;
}
