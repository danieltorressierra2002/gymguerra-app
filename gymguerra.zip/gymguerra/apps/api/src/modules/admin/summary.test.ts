import request from 'supertest';
import { describe, expect, it } from 'vitest';
import { app, bearer } from '../../test-helpers';
import { countStates, lastMonths, monthKey, pickAttention, revenueSeries, type SnapshotRow } from './summary';

const ctx = { today: '2026-11-22', warningDays: 5 };
const row = (id: string, endDate: string | null, status: 'ACTIVE' | 'FROZEN' = 'ACTIVE'): SnapshotRow => ({
  memberId: id,
  name: `Cliente ${id}`,
  documentId: id,
  membership: endDate ? { id: `m-${id}`, plan: 'Mensual', status, endDate, frozenAt: status === 'FROZEN' ? '2026-11-20' : null } : null,
});

describe('resumen del administrador', () => {
  const rows = [
    row('a', '2026-12-30'), // al día
    row('b', '2026-11-25'), // por vencer (3 días)
    row('c', '2026-11-22'), // por vencer (vence hoy)
    row('d', '2026-11-10'), // vencido
    row('e', '2026-12-15', 'FROZEN'), // pausada
    row('f', null), // sin membresía
  ];

  it('cuenta clientes por estado (cada cliente una sola vez)', () => {
    expect(countStates(rows, ctx)).toEqual({ total: 6, ok: 1, expiring: 2, expired: 1, frozen: 1, withoutMembership: 1 });
  });

  it('lista primero a quien vence antes, e incluye vencidos recientes', () => {
    const items = pickAttention(rows, ctx);
    expect(items.map((i) => i.memberId)).toEqual(['d', 'c', 'b']);
    expect(items[0]).toMatchObject({ state: 'EXPIRED', daysLeft: -12 });
  });

  it('no incluye vencidos hace más de 30 días ni respeta más del límite', () => {
    expect(pickAttention([row('x', '2026-09-01')], ctx)).toEqual([]);
    const many = Array.from({ length: 20 }, (_, i) => row(String(i), '2026-11-24'));
    expect(pickAttention(many, ctx, 8)).toHaveLength(8);
  });

  it('lastMonths cruza el fin de año', () => {
    expect(lastMonths('2026-11-22', 6)).toEqual(['2026-06', '2026-07', '2026-08', '2026-09', '2026-10', '2026-11']);
    expect(lastMonths('2027-02-03', 4)).toEqual(['2026-11', '2026-12', '2027-01', '2027-02']);
  });

  it('el mes de un pago se mide en la zona horaria del gimnasio', () => {
    const instant = new Date('2026-12-01T02:00:00Z'); // 1 dic UTC = 30 nov en Nueva York
    expect(monthKey(instant, 'UTC')).toBe('2026-12');
    expect(monthKey(instant, 'America/New_York')).toBe('2026-11');
  });

  it('suma los ingresos por mes y por moneda sin mezclarlas', () => {
    const months = ['2026-10', '2026-11'];
    const series = revenueSeries(
      [
        { amount: '10.50', currency: 'USD', paidAt: new Date('2026-11-05T12:00:00Z') },
        { amount: '4.50', currency: 'USD', paidAt: new Date('2026-11-20T12:00:00Z') },
        { amount: '100', currency: 'CUP', paidAt: new Date('2026-11-06T12:00:00Z') },
        { amount: '7.25', currency: 'USD', paidAt: new Date('2026-10-02T12:00:00Z') },
        { amount: '99', currency: 'USD', paidAt: new Date('2026-05-02T12:00:00Z') }, // fuera de rango
        { amount: '5', currency: 'USD', paidAt: null }, // sin fecha de pago
      ],
      months,
      'UTC',
    );
    expect(series).toEqual([
      { month: '2026-10', currency: 'USD', total: '7.25' },
      { month: '2026-11', currency: 'CUP', total: '100.00' },
      { month: '2026-11', currency: 'USD', total: '15.00' },
    ]);
  });

  it('no pierde céntimos con decimales (0.1 + 0.2 = 0.30)', () => {
    const series = revenueSeries(
      [
        { amount: '0.10', currency: 'USD', paidAt: new Date('2026-11-05T12:00:00Z') },
        { amount: '0.20', currency: 'USD', paidAt: new Date('2026-11-06T12:00:00Z') },
      ],
      ['2026-11'],
      'UTC',
    );
    expect(series[0]?.total).toBe('0.30');
  });
});

describe('GET /api/admin/summary: acceso', () => {
  it('exige sesión de administrador', async () => {
    await request(app).get('/api/admin/summary').expect(401);
    await request(app).get('/api/admin/summary').set(bearer('member')).expect(403);
    await request(app).get('/api/admin/summary').set(bearer('trainer')).expect(403);
  });
});
