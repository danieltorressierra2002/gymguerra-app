import { describe, expect, it } from 'vitest';
import { escapeHtml, invitationEmail, passwordResetEmail } from './templates';

const link = 'https://gym.test/accion?oobCode=abc&mode=resetPassword';

describe('plantillas de correo', () => {
  it('escapa HTML en el nombre (sin inyección en el correo)', () => {
    const { html } = invitationEmail({ name: '<script>alert(1)</script>', link, appName: 'Gym' });
    expect(html).not.toContain('<script>');
    expect(html).toContain('&lt;script&gt;');
  });

  it('escapa el enlace en el atributo href y lo deja intacto en el texto', () => {
    const { html, text } = passwordResetEmail({ name: 'Ana', link, appName: 'Gym' });
    expect(html).toContain('oobCode=abc&amp;mode=resetPassword');
    expect(text).toContain(link);
  });

  it('el asunto menciona la app y funciona sin nombre', () => {
    const msg = invitationEmail({ link, appName: 'Gimnasio Guerra' });
    expect(msg.subject).toContain('Gimnasio Guerra');
    expect(msg.text.startsWith('Hola,')).toBe(true);
  });

  it('el botón usa naranja con texto negro (contraste)', () => {
    const { html } = invitationEmail({ name: 'Ana', link, appName: 'Gym' });
    expect(html).toContain('background:#FF6A00;color:#0A0A0B');
  });

  it('escapeHtml cubre comillas y ampersand', () => {
    expect(escapeHtml(`a&b"c'd`)).toBe('a&amp;b&quot;c&#39;d');
  });
});
