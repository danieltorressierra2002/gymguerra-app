export interface EmailMessage {
  to: string;
  subject: string;
  text: string;
  html: string;
}

/** Contrato de envío de correo. Implementaciones: consola (desarrollo), Resend; SES se añade igual. */
export interface EmailSender {
  send(message: EmailMessage): Promise<void>;
}
