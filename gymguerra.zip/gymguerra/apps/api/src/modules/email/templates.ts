import type { EmailMessage } from './sender';

type Template = Omit<EmailMessage, 'to'>;

export function escapeHtml(value: string): string {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function layout(appName: string, heading: string, intro: string, buttonLabel: string, link: string, outro: string) {
  const h = escapeHtml;
  return `<!doctype html>
<html lang="es"><body style="margin:0;background:#0A0A0B;padding:24px;font-family:Arial,Helvetica,sans-serif">
  <table role="presentation" width="100%" style="max-width:480px;margin:0 auto;background:#1B1B1F;border-radius:16px;padding:28px;color:#F5F5F7">
    <tr><td>
      <p style="margin:0 0 16px;font-size:22px;font-weight:700;letter-spacing:.02em;text-transform:uppercase;color:#FF6A00">${h(appName)}</p>
      <h1 style="margin:0 0 12px;font-size:20px">${h(heading)}</h1>
      <p style="margin:0 0 20px;font-size:15px;line-height:1.5;color:#D4D4DC">${h(intro)}</p>
      <p style="margin:0 0 20px"><a href="${h(link)}" style="display:inline-block;background:#FF6A00;color:#0A0A0B;text-decoration:none;font-weight:700;padding:14px 22px;border-radius:12px">${h(buttonLabel)}</a></p>
      <p style="margin:0;font-size:13px;line-height:1.5;color:#A8A8B3">${h(outro)}</p>
    </td></tr>
  </table>
</body></html>`;
}

/** Correo para que un cliente nuevo cree su contraseña. */
export function invitationEmail(p: { name?: string | null; link: string; appName: string }): Template {
  const hello = p.name ? `Hola ${p.name},` : 'Hola,';
  const intro = `${hello} te creamos una cuenta en ${p.appName}. Crea tu contraseña para entrar.`;
  const outro = 'El enlace es personal y caduca pronto. Si no esperabas este correo, puedes ignorarlo.';
  return {
    subject: `Activa tu cuenta en ${p.appName}`,
    text: `${intro}\n\n${p.link}\n\n${outro}`,
    html: layout(p.appName, 'Activa tu cuenta', intro, 'Crear mi contraseña', p.link, outro),
  };
}

/** Correo de recuperación de contraseña. */
export function passwordResetEmail(p: { name?: string | null; link: string; appName: string }): Template {
  const hello = p.name ? `Hola ${p.name},` : 'Hola,';
  const intro = `${hello} recibimos una solicitud para restablecer tu contraseña de ${p.appName}.`;
  const outro = 'Si no fuiste tú, ignora este correo: tu contraseña actual no cambia.';
  return {
    subject: `Restablece tu contraseña de ${p.appName}`,
    text: `${intro}\n\n${p.link}\n\n${outro}`,
    html: layout(p.appName, 'Restablece tu contraseña', intro, 'Elegir nueva contraseña', p.link, outro),
  };
}
