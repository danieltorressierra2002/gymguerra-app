import type { EmailSender } from './sender';

/** Solo desarrollo: imprime el correo (con su enlace) en la terminal. El entorno de producción lo rechaza. */
export function createConsoleSender(): EmailSender {
  return {
    async send({ to, subject, text }) {
      console.log(`\n[correo de desarrollo] Para: ${to}\nAsunto: ${subject}\n\n${text}\n`);
    },
  };
}
