import type { EmailSender } from './sender';

/** Envío con la API HTTP de Resend (sin dependencias extra). La clave llega por variable de entorno. */
export function createResendSender(opts: { apiKey: string; from: string }): EmailSender {
  return {
    async send({ to, subject, text, html }) {
      const res = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: { Authorization: `Bearer ${opts.apiKey}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ from: opts.from, to: [to], subject, text, html }),
        signal: AbortSignal.timeout(10_000),
      });
      // No se incluye el cuerpo de la respuesta ni la clave en el error
      if (!res.ok) throw new Error(`El proveedor de correo respondió ${res.status}`);
    },
  };
}
