import { AppError } from '../../lib/errors';
import type { Role } from '../../lib/permissions';
import { adminUpdateMemberSchema, selfUpdateMemberSchema, type MemberUpdate } from './schemas';

/**
 * Qué campos puede cambiar cada rol. Los esquemas son estrictos: un cliente que
 * envíe `trainerId` o `name` recibe 400 (protección contra asignación masiva).
 */
export function parseMemberUpdate(role: Role, body: unknown): MemberUpdate {
  if (role === 'ADMIN') return adminUpdateMemberSchema.parse(body);
  if (role === 'MEMBER') return selfUpdateMemberSchema.parse(body);
  throw AppError.forbidden();
}
