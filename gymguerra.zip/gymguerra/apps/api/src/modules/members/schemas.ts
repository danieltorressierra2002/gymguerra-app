import { z } from 'zod';
import { isoDate, uuid } from '../../lib/validators';

const phone = z
  .string()
  .trim()
  .min(5)
  .max(30)
  .regex(/^[+\d][\d\s().-]*$/, 'Teléfono inválido');

const emergencyContact = z
  .object({
    name: z.string().trim().min(1).max(100),
    phone,
    relation: z.string().trim().max(50).optional(),
  })
  .strict();

const birthDate = isoDate.refine((d) => d >= '1900-01-01', 'Fecha de nacimiento inválida');

export const createMemberSchema = z
  .object({
    name: z.string().trim().min(2).max(120),
    email: z.string().trim().toLowerCase().email().max(254),
    documentId: z.string().trim().min(3).max(30),
    phone: phone.optional(),
    address: z.string().trim().max(250).optional(),
    birthDate: birthDate.optional(),
    emergencyContact: emergencyContact.optional(),
    trainerId: uuid.optional(),
    notes: z.string().trim().max(1000).optional(),
  })
  .strict();

/** El administrador puede cambiarlo todo. `null` borra el valor. */
export const adminUpdateMemberSchema = z
  .object({
    name: z.string().trim().min(2).max(120),
    documentId: z.string().trim().min(3).max(30),
    phone: phone.nullable(),
    address: z.string().trim().max(250).nullable(),
    birthDate: birthDate.nullable(),
    emergencyContact: emergencyContact.nullable(),
    trainerId: uuid.nullable(),
    notes: z.string().trim().max(1000).nullable(),
  })
  .partial()
  .strict();

/** El cliente solo edita sus datos de contacto («perfil editable»). */
export const selfUpdateMemberSchema = z
  .object({
    phone: phone.nullable(),
    address: z.string().trim().max(250).nullable(),
    emergencyContact: emergencyContact.nullable(),
  })
  .partial()
  .strict();

export const listMembersQuerySchema = z.object({
  q: z.string().trim().min(1).max(100).optional(),
  trainerId: uuid.optional(),
  hasTrainer: z
    .enum(['true', 'false'])
    .transform((v) => v === 'true')
    .optional(),
  sort: z.enum(['name', 'createdAt']).default('name'),
  dir: z.enum(['asc', 'desc']).default('asc'),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(20),
});

export type CreateMemberInput = z.infer<typeof createMemberSchema>;
export type MemberUpdate = z.infer<typeof adminUpdateMemberSchema>;
export type ListMembersQuery = z.infer<typeof listMembersQuerySchema>;
