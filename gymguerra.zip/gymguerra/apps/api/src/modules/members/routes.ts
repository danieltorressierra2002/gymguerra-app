import { Router } from 'express';
import { ah } from '../../lib/async-handler';
import { uuid } from '../../lib/validators';
import { requestMeta, requireRole } from '../../middleware/auth';
import { parseMemberUpdate } from './profile-rules';
import { createMemberSchema, listMembersQuerySchema } from './schemas';
import type { MemberService } from './service';

export function membersRouter(service: MemberService) {
  const r = Router();

  // Perfil del cliente que inició sesión (antes de /:id)
  r.get(
    '/me',
    requireRole('MEMBER'),
    ah(async (req, res) => {
      res.json({ data: await service.me(req.user!) });
    }),
  );

  // Descarga de todos mis datos (derecho de acceso y portabilidad)
  r.get(
    '/me/export',
    requireRole('MEMBER'),
    ah(async (req, res) => {
      const data = await service.exportMine(req.user!);
      res.set('Content-Disposition', 'attachment; filename="mis-datos.json"').json(data);
    }),
  );

  r.get(
    '/',
    requireRole('ADMIN', 'TRAINER'),
    ah(async (req, res) => {
      res.json(await service.list(req.user!, listMembersQuerySchema.parse(req.query)));
    }),
  );

  r.get(
    '/:id',
    requireRole('ADMIN', 'TRAINER', 'MEMBER'),
    ah(async (req, res) => {
      res.json({ data: await service.get(req.user!, uuid.parse(req.params.id)) });
    }),
  );

  r.post(
    '/',
    requireRole('ADMIN'),
    ah(async (req, res) => {
      const data = await service.create(req.user!, createMemberSchema.parse(req.body), requestMeta(req));
      // La respuesta incluye el enlace de activación: nunca debe quedar en cachés
      res.status(201).set('Cache-Control', 'no-store').json({ data });
    }),
  );

  // Genera un enlace nuevo de activación y lo devuelve al administrador
  r.post(
    '/:id/invite',
    requireRole('ADMIN'),
    ah(async (req, res) => {
      const data = await service.invite(req.user!, uuid.parse(req.params.id), requestMeta(req));
      res.set('Cache-Control', 'no-store').json({ data });
    }),
  );

  // Admin: todo. Cliente: solo su contacto (ver profile-rules.ts).
  r.patch(
    '/:id',
    requireRole('ADMIN', 'MEMBER'),
    ah(async (req, res) => {
      const id = uuid.parse(req.params.id);
      const input = parseMemberUpdate(req.user!.role, req.body ?? {});
      res.json({ data: await service.update(req.user!, id, input, requestMeta(req)) });
    }),
  );

  r.delete(
    '/:id',
    requireRole('ADMIN'),
    ah(async (req, res) => {
      await service.remove(req.user!, uuid.parse(req.params.id), requestMeta(req));
      res.status(204).end();
    }),
  );

  return r;
}
