import { describe, expect, it } from 'vitest';
import { ZodError } from 'zod';
import { AppError } from '../../lib/errors';
import { parseMemberUpdate } from './profile-rules';

describe('parseMemberUpdate', () => {
  it('el administrador puede cambiar entrenador, notas y documento', () => {
    const t = '3f0c2a7e-8b1d-4c53-9a54-1d2f3a4b5c6d';
    expect(parseMemberUpdate('ADMIN', { trainerId: t, notes: 'ok', documentId: 'ABC123' })).toEqual({
      trainerId: t,
      notes: 'ok',
      documentId: 'ABC123',
    });
  });

  it('el administrador puede quitar el entrenador con null', () => {
    expect(parseMemberUpdate('ADMIN', { trainerId: null })).toEqual({ trainerId: null });
  });

  it('el cliente edita solo su contacto', () => {
    expect(parseMemberUpdate('MEMBER', { phone: '+53 5555 1234', address: 'Calle 1' })).toEqual({
      phone: '+53 5555 1234',
      address: 'Calle 1',
    });
  });

  it('el cliente no puede cambiar entrenador, notas, nombre ni documento', () => {
    for (const body of [{ trainerId: null }, { notes: 'x' }, { name: 'Otro' }, { documentId: '999' }]) {
      expect(() => parseMemberUpdate('MEMBER', body)).toThrow(ZodError);
    }
  });

  it('el entrenador no edita perfiles', () => {
    expect(() => parseMemberUpdate('TRAINER', {})).toThrow(AppError);
  });

  it('valida teléfono y fecha de nacimiento', () => {
    expect(() => parseMemberUpdate('ADMIN', { phone: 'abc' })).toThrow(ZodError);
    expect(() => parseMemberUpdate('ADMIN', { birthDate: '2026-02-31' })).toThrow(ZodError);
    expect(() => parseMemberUpdate('ADMIN', { birthDate: '1850-01-01' })).toThrow(ZodError);
  });
});
