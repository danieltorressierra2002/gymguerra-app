import type { Prisma, PrismaClient } from '@prisma/client';
import { computeSemaforo, todayInTimeZone } from '@gymguerra/shared';
import { audit, type RequestMeta } from '../../lib/audit';
import { AppError } from '../../lib/errors';
import { canViewMember, type Actor } from '../../lib/permissions';
import type { CredentialsService } from '../auth/credentials-service';
import type { IdentityProvisioner } from '../auth/provisioner';
import { getMembershipSettings } from '../settings/service';
import type { CreateMemberInput, ListMembersQuery, MemberUpdate } from './schemas';

type Db = Prisma.TransactionClient;

const toIso = (d: Date) => d.toISOString().slice(0, 10);
const fromIso = (s: string) => new Date(`${s}T00:00:00.000Z`);

const include = {
  user: { select: { name: true, email: true, status: true } },
  trainer: { select: { id: true, user: { select: { name: true } } } },
  // Última membresía no cancelada: alimenta el semáforo en listados y fichas
  memberships: {
    where: { status: { not: 'CANCELLED' } },
    orderBy: { endDate: 'desc' },
    take: 1,
    select: {
      id: true,
      status: true,
      startDate: true,
      endDate: true,
      frozenAt: true,
      plan: { select: { name: true } },
    },
  },
} satisfies Prisma.MemberInclude;

type Row = Prisma.MemberGetPayload<{ include: typeof include }>;
interface Ctx {
  today: string;
  warningDays: number;
}

function present(row: Row, ctx: Ctx, actor: Actor) {
  const { memberships, notes, ...rest } = row;
  const cur = memberships[0];
  const endDate = cur ? toIso(cur.endDate) : null;
  return {
    ...rest,
    // Las notas internas no se muestran al propio cliente
    ...(actor.role === 'MEMBER' ? {} : { notes }),
    birthDate: row.birthDate ? toIso(row.birthDate) : null,
    currentMembership:
      cur && endDate
        ? {
            id: cur.id,
            plan: cur.plan.name,
            status: cur.status,
            startDate: toIso(cur.startDate),
            endDate,
            semaforo: computeSemaforo({
              status: cur.status,
              endDate,
              frozenAt: cur.frozenAt ? toIso(cur.frozenAt) : null,
              today: ctx.today,
              warningDays: ctx.warningDays,
            }),
          }
        : null,
  };
}

function toUpdateData(input: MemberUpdate): Prisma.MemberUncheckedUpdateInput {
  const data: Prisma.MemberUncheckedUpdateInput = {};
  if (input.documentId !== undefined) data.documentId = input.documentId;
  if (input.phone !== undefined) data.phone = input.phone;
  if (input.address !== undefined) data.address = input.address;
  if (input.birthDate !== undefined) data.birthDate = input.birthDate === null ? null : fromIso(input.birthDate);
  if (input.trainerId !== undefined) data.trainerId = input.trainerId;
  if (input.notes !== undefined) data.notes = input.notes;
  if (input.emergencyContact !== undefined) {
    const e = input.emergencyContact;
    data.emergencyContactName = e?.name ?? null;
    data.emergencyContactPhone = e?.phone ?? null;
    data.emergencyContactRelation = e?.relation ?? null;
  }
  return data;
}

export interface MemberServiceDeps {
  prisma: PrismaClient;
  provisioner: IdentityProvisioner;
  credentials: CredentialsService;
  timeZone: string;
  now?: () => Date;
}

export function createMemberService({
  prisma,
  provisioner,
  credentials,
  timeZone,
  now = () => new Date(),
}: MemberServiceDeps) {
  const context = async (): Promise<Ctx> => ({
    today: todayInTimeZone(timeZone, now()),
    ...(await getMembershipSettings(prisma)),
  });

  async function ensureUnique(
    db: Pick<Db, 'user' | 'member'>,
    f: { email?: string; documentId?: string; excludeMemberId?: string },
  ) {
    if (f.email) {
      const taken = await db.user.findFirst({ where: { email: f.email, deletedAt: null }, select: { id: true } });
      if (taken) throw AppError.conflict('EMAIL_TAKEN', 'Ya existe una cuenta con ese correo');
    }
    if (f.documentId) {
      const taken = await db.member.findFirst({
        where: {
          documentId: f.documentId,
          deletedAt: null,
          ...(f.excludeMemberId ? { id: { not: f.excludeMemberId } } : {}),
        },
        select: { id: true },
      });
      if (taken) throw AppError.conflict('DOCUMENT_TAKEN', 'Ya existe un cliente con ese documento');
    }
  }

  async function assertTrainer(db: Pick<Db, 'trainer'>, trainerId: string) {
    const trainer = await db.trainer.findFirst({
      where: { id: trainerId, deletedAt: null, status: { not: 'INACTIVE' } },
      select: { id: true },
    });
    if (!trainer) throw AppError.badRequest('TRAINER_UNAVAILABLE', 'El entrenador no existe o está inactivo');
  }

  async function getMember(actor: Actor, id: string) {
    const ctx = await context();
    const row = await prisma.member.findFirst({ where: { id, deletedAt: null }, include });
    // Sin permiso se responde 404: no se revela que existe
    if (!row || !canViewMember(actor, { memberId: row.id, trainerId: row.trainerId })) {
      throw AppError.notFound('Cliente no encontrado');
    }
    return present(row, ctx, actor);
  }

  return {
    get: getMember,

    async me(actor: Actor) {
      if (!actor.memberId) throw AppError.forbidden();
      return getMember(actor, actor.memberId);
    },

    async list(actor: Actor, q: ListMembersQuery) {
      const ctx = await context();
      const and: Prisma.MemberWhereInput[] = [{ deletedAt: null }];

      if (actor.role === 'TRAINER') {
        if (!actor.trainerId) throw AppError.forbidden();
        and.push({ trainerId: actor.trainerId });
      } else if (actor.role !== 'ADMIN') {
        throw AppError.forbidden();
      }

      if (q.trainerId) and.push({ trainerId: q.trainerId });
      if (q.hasTrainer !== undefined) and.push({ trainerId: q.hasTrainer ? { not: null } : null });
      if (q.q) {
        and.push({
          OR: [
            { documentId: { contains: q.q } },
            { phone: { contains: q.q } },
            { user: { name: { contains: q.q, mode: 'insensitive' } } },
            { user: { email: { contains: q.q, mode: 'insensitive' } } },
          ],
        });
      }

      const where: Prisma.MemberWhereInput = { AND: and };
      const orderBy: Prisma.MemberOrderByWithRelationInput =
        q.sort === 'name' ? { user: { name: q.dir } } : { createdAt: q.dir };

      const [total, rows] = await Promise.all([
        prisma.member.count({ where }),
        prisma.member.findMany({
          where,
          include,
          orderBy: [orderBy, { id: 'asc' }],
          skip: (q.page - 1) * q.pageSize,
          take: q.pageSize,
        }),
      ]);
      return { items: rows.map((r) => present(r, ctx, actor)), total, page: q.page, pageSize: q.pageSize };
    },

    /** Crea la cuenta de acceso y el perfil del cliente. Si la base de datos falla, deshace la cuenta. */
    async create(actor: Actor, input: CreateMemberInput, meta: RequestMeta) {
      await ensureUnique(prisma, { email: input.email, documentId: input.documentId });
      if (input.trainerId) await assertTrainer(prisma, input.trainerId);

      // La cuenta nace SIN contraseña: el cliente la crea con el enlace que le llega por correo
      const identity = await provisioner.createUser({ email: input.email, name: input.name });

      let id: string;
      try {
        id = await prisma.$transaction(async (tx) => {
          const user = await tx.user.create({
            data: {
              email: input.email,
              name: input.name,
              role: 'MEMBER',
              status: 'ACTIVE', // la cuenta la crea el administrador
              authProvider: identity.provider,
              authSubject: identity.subject,
            },
            select: { id: true },
          });
          const member = await tx.member.create({
            data: {
              userId: user.id,
              documentId: input.documentId,
              phone: input.phone,
              address: input.address,
              birthDate: input.birthDate ? fromIso(input.birthDate) : undefined,
              emergencyContactName: input.emergencyContact?.name,
              emergencyContactPhone: input.emergencyContact?.phone,
              emergencyContactRelation: input.emergencyContact?.relation,
              trainerId: input.trainerId,
              notes: input.notes,
            },
            select: { id: true },
          });
          await audit(tx, {
            actorId: actor.id,
            action: 'member.create',
            entityType: 'Member',
            entityId: member.id,
            after: { userId: user.id, trainerId: input.trainerId ?? null },
            meta,
          });
          return member.id;
        });
      } catch (err) {
        // Compensación: no dejar una cuenta huérfana en el proveedor de identidad
        await provisioner.deleteUser(identity.subject).catch((e) => console.error('No se pudo revertir el alta', e));
        throw err;
      }

      const member = await getMember(actor, id);
      // El administrador recibe el enlace para que el cliente cree su contraseña y se lo entrega
      // (WhatsApp, en persona...). Si hay correo configurado, además se envía. Si algo falla, el
      // cliente ya existe y se puede generar otro enlace con /invite.
      const invitation = await credentials
        .prepareInvitation({ to: input.email, name: input.name })
        .catch((e) => {
          console.error('No se pudo generar el enlace de activación', e);
          return { link: null, sent: false };
        });
      return { ...member, setupLink: invitation.link, invitationSent: invitation.sent };
    },

    /** Genera un enlace nuevo para crear o restablecer la contraseña (invalida el anterior) y lo devuelve. */
    async invite(actor: Actor, id: string, meta: RequestMeta) {
      const row = await prisma.member.findFirst({
        where: { id, deletedAt: null },
        select: { user: { select: { email: true, name: true } } },
      });
      if (!row) throw AppError.notFound('Cliente no encontrado');
      const { link, sent } = await credentials.prepareInvitation({ to: row.user.email, name: row.user.name });
      await prisma.$transaction((tx) =>
        audit(tx, { actorId: actor.id, action: 'member.invite', entityType: 'Member', entityId: id, meta }),
      );
      return { setupLink: link, sent };
    },

    /**
     * Copia de TODOS los datos personales del cliente (derecho de acceso y portabilidad).
     * Incluye las notas internas porque también son datos sobre él.
     */
    async exportMine(actor: Actor) {
      if (!actor.memberId) throw AppError.forbidden();
      const memberId = actor.memberId;
      const [member, memberships, payments, orders, consents] = await Promise.all([
        prisma.member.findFirst({
          where: { id: memberId, deletedAt: null },
          select: {
            documentId: true,
            phone: true,
            address: true,
            birthDate: true,
            emergencyContactName: true,
            emergencyContactPhone: true,
            emergencyContactRelation: true,
            photoUrl: true,
            notes: true,
            joinedAt: true,
            user: { select: { name: true, email: true, createdAt: true } },
            trainer: { select: { user: { select: { name: true } } } },
          },
        }),
        prisma.membership.findMany({
          where: { memberId },
          orderBy: { createdAt: 'desc' },
          select: {
            startDate: true,
            endDate: true,
            status: true,
            priceSnapshot: true,
            currency: true,
            cancelledAt: true,
            createdAt: true,
            plan: { select: { name: true } },
          },
        }),
        prisma.payment.findMany({
          where: { memberId },
          orderBy: { createdAt: 'desc' },
          select: { receiptNumber: true, amount: true, currency: true, method: true, status: true, paidAt: true },
        }),
        prisma.order.findMany({
          where: { memberId },
          orderBy: { createdAt: 'desc' },
          select: {
            orderNumber: true,
            status: true,
            total: true,
            currency: true,
            createdAt: true,
            items: { select: { nameSnapshot: true, unitPrice: true, quantity: true, lineTotal: true } },
          },
        }),
        prisma.consent.findMany({
          where: { userId: actor.id },
          orderBy: { acceptedAt: 'desc' },
          select: { documentType: true, version: true, acceptedAt: true },
        }),
      ]);
      if (!member) throw AppError.notFound('Cliente no encontrado');
      return { exportedAt: now().toISOString(), profile: member, memberships, payments, orders, consents };
    },

    async update(actor: Actor, id: string, input: MemberUpdate, meta: RequestMeta) {
      if (actor.role === 'TRAINER') throw AppError.forbidden();
      if (actor.role === 'MEMBER' && actor.memberId !== id) throw AppError.notFound('Cliente no encontrado');

      await prisma.$transaction(async (tx) => {
        const current = await tx.member.findFirst({ where: { id, deletedAt: null }, select: { userId: true } });
        if (!current) throw AppError.notFound('Cliente no encontrado');

        if (input.documentId !== undefined) await ensureUnique(tx, { documentId: input.documentId, excludeMemberId: id });
        if (input.trainerId) await assertTrainer(tx, input.trainerId);

        const data = toUpdateData(input);
        if (Object.keys(data).length > 0) await tx.member.update({ where: { id }, data });
        if (input.name !== undefined) await tx.user.update({ where: { id: current.userId }, data: { name: input.name } });

        // Se registran los campos cambiados, no sus valores (evita copiar datos personales al log)
        await audit(tx, {
          actorId: actor.id,
          action: 'member.update',
          entityType: 'Member',
          entityId: id,
          after: { changed: Object.keys(input) },
          meta,
        });
      });
      return getMember(actor, id);
    },

    /** Baja lógica: conserva el historial de pagos y membresías. */
    async remove(actor: Actor, id: string, meta: RequestMeta) {
      const today = todayInTimeZone(timeZone, now());
      const subject = await prisma.$transaction(async (tx) => {
        const member = await tx.member.findFirst({
          where: { id, deletedAt: null },
          select: { userId: true, user: { select: { authSubject: true } } },
        });
        if (!member) throw AppError.notFound('Cliente no encontrado');

        const active = await tx.membership.count({
          where: { memberId: id, status: { in: ['ACTIVE', 'FROZEN'] }, endDate: { gte: fromIso(today) } },
        });
        if (active > 0) {
          throw AppError.conflict('HAS_ACTIVE_MEMBERSHIP', 'Cancela la membresía vigente antes de dar de baja al cliente');
        }

        const deletedAt = now();
        await tx.member.update({ where: { id }, data: { deletedAt } });
        await tx.user.update({ where: { id: member.userId }, data: { deletedAt, status: 'SUSPENDED' } });
        await audit(tx, {
          actorId: actor.id,
          action: 'member.delete',
          entityType: 'Member',
          entityId: id,
          meta,
        });
        return member.user.authSubject;
      });

      // Fuera de la transacción: si el proveedor falla, la baja en la base de datos ya es efectiva
      // y el middleware de autenticación rechaza la cuenta de todos modos.
      if (subject) await provisioner.disableUser(subject).catch((e) => console.error('No se pudo deshabilitar la cuenta', e));
    },
  };
}

export type MemberService = ReturnType<typeof createMemberService>;
