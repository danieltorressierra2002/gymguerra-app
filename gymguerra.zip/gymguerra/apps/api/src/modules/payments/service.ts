import { Prisma } from '@prisma/client';
import { AppError } from '../../lib/errors';
import type { PaymentInput } from './schemas';

/** Registra un pago PAGADO asociado a una membresía, dentro de la transacción de quien lo llama. */
export async function recordMembershipPayment(
  tx: Prisma.TransactionClient,
  args: {
    actorId: string;
    memberId: string;
    membershipId: string;
    defaultAmount: Prisma.Decimal;
    currency: string;
    input: PaymentInput;
  },
) {
  const amount = args.input.amount ? new Prisma.Decimal(args.input.amount) : args.defaultAmount;
  if (amount.lte(0)) throw AppError.badRequest('INVALID_AMOUNT', 'El monto debe ser mayor que 0');

  return tx.payment.create({
    data: {
      memberId: args.memberId,
      membershipId: args.membershipId,
      amount,
      currency: args.currency,
      method: args.input.method,
      status: 'PAID',
      paidAt: new Date(),
      recordedById: args.actorId,
      notes: args.input.notes,
      idempotencyKey: args.input.idempotencyKey,
    },
    select: { id: true, receiptNumber: true },
  });
}
