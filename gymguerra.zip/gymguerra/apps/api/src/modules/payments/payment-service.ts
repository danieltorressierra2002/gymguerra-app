import { Prisma, type OrderStatus, type PrismaClient } from '@prisma/client';
import { addDays, zonedDayStart } from '@gymguerra/shared';
import { audit, type RequestMeta } from '../../lib/audit';
import { AppError } from '../../lib/errors';
import type { Actor } from '../../lib/permissions';
import type { CreatePaymentInput, ListPaymentsQuery, VoidPaymentInput } from './schemas';

type Db = Prisma.TransactionClient;

const include = {
  member: { select: { id: true, documentId: true, user: { select: { name: true } } } },
  membership: { select: { id: true, plan: { select: { name: true } } } },
  order: { select: { id: true, orderNumber: true } },
} satisfies Prisma.PaymentInclude;

export interface PaymentServiceDeps {
  prisma: PrismaClient;
  /** Zona horaria del gimnasio: define dónde empieza y termina cada día en los filtros */
  timeZone: string;
  now?: () => Date;
}

export function createPaymentService({ prisma, timeZone, now = () => new Date() }: PaymentServiceDeps) {
  async function sumPaid(tx: Db, orderId: string) {
    const r = await tx.payment.aggregate({ where: { orderId, status: 'PAID' }, _sum: { amount: true } });
    return r._sum.amount ?? new Prisma.Decimal(0);
  }

  /** Si no puede verlo, responde 404 (no revela que existe). */
  async function load(actor: Actor, id: string) {
    const row = await prisma.payment.findUnique({ where: { id }, include });
    const visible =
      row && (actor.role === 'ADMIN' || (actor.role === 'MEMBER' && actor.memberId === row.memberId));
    if (!row || !visible) throw AppError.notFound('Pago no encontrado');
    return row;
  }

  return {
    async list(actor: Actor, q: ListPaymentsQuery) {
      const and: Prisma.PaymentWhereInput[] = [];

      if (actor.role === 'MEMBER') {
        if (!actor.memberId) throw AppError.forbidden();
        and.push({ memberId: actor.memberId });
      } else if (actor.role !== 'ADMIN') {
        throw AppError.forbidden();
      } else if (q.memberId) {
        and.push({ memberId: q.memberId });
      }

      if (q.membershipId) and.push({ membershipId: q.membershipId });
      if (q.orderId) and.push({ orderId: q.orderId });
      if (q.method) and.push({ method: q.method });
      if (q.status) and.push({ status: q.status });
      // Los días se miden en la zona horaria del gimnasio, no en UTC
      if (q.from) and.push({ paidAt: { gte: zonedDayStart(q.from, timeZone) } });
      if (q.to) and.push({ paidAt: { lt: zonedDayStart(addDays(q.to, 1), timeZone) } });

      const where: Prisma.PaymentWhereInput = { AND: and };
      const [total, items] = await Promise.all([
        prisma.payment.count({ where }),
        prisma.payment.findMany({
          where,
          include,
          orderBy: [{ paidAt: { sort: q.dir, nulls: 'last' } }, { id: 'asc' }],
          skip: (q.page - 1) * q.pageSize,
          take: q.pageSize,
        }),
      ]);
      return { items, total, page: q.page, pageSize: q.pageSize };
    },

    getById: load,

    /**
     * Pago manual (efectivo, transferencia, tarjeta). Si se reintenta con la misma
     * idempotencyKey devuelve el pago original en vez de cobrar dos veces.
     */
    async create(actor: Actor, input: CreatePaymentInput, meta: RequestMeta) {
      const amount = new Prisma.Decimal(input.amount);
      if (amount.lte(0)) throw AppError.badRequest('INVALID_AMOUNT', 'El monto debe ser mayor que 0');

      if (input.idempotencyKey) {
        const existing = await prisma.payment.findUnique({
          where: { idempotencyKey: input.idempotencyKey },
          include,
        });
        if (existing) return { payment: existing, replayed: true };
      }

      const id = await prisma.$transaction(async (tx) => {
        let target: { memberId: string; currency: string } | undefined;
        let order: { id: string; status: OrderStatus; total: Prisma.Decimal } | undefined;

        if (input.membershipId) {
          const m = await tx.membership.findUnique({
            where: { id: input.membershipId },
            select: { memberId: true, currency: true, status: true },
          });
          if (!m) throw AppError.notFound('Membresía no encontrada');
          if (m.status === 'CANCELLED') {
            throw AppError.conflict('MEMBERSHIP_CANCELLED', 'No se registran pagos en una membresía cancelada');
          }
          target = { memberId: m.memberId, currency: m.currency };
        }

        if (input.orderId) {
          const o = await tx.order.findUnique({
            where: { id: input.orderId },
            select: { id: true, memberId: true, currency: true, status: true, total: true },
          });
          if (!o) throw AppError.notFound('Pedido no encontrado');
          if (o.status === 'CANCELLED') {
            throw AppError.conflict('ORDER_CANCELLED', 'No se registran pagos en un pedido cancelado');
          }
          if (target && target.memberId !== o.memberId) {
            throw AppError.badRequest('MEMBER_MISMATCH', 'La membresía y el pedido son de clientes distintos');
          }
          target = target ?? { memberId: o.memberId, currency: o.currency };
          order = { id: o.id, status: o.status, total: o.total };
        }

        if (!target) throw AppError.badRequest('NO_TARGET', 'Indica membershipId u orderId');

        const created = await tx.payment.create({
          data: {
            memberId: target.memberId,
            membershipId: input.membershipId,
            orderId: input.orderId,
            amount,
            currency: target.currency, // la moneda la define la membresía o el pedido, no el cliente
            method: input.method,
            status: 'PAID',
            paidAt: now(),
            recordedById: actor.id,
            notes: input.notes,
            idempotencyKey: input.idempotencyKey,
          },
          select: { id: true },
        });

        // Pedido completamente pagado → pasa a PAGADO
        if (order && order.status === 'PENDING') {
          const paid = await sumPaid(tx, order.id);
          if (paid.gte(order.total)) {
            await tx.order.update({ where: { id: order.id }, data: { status: 'PAID', paidAt: now() } });
          }
        }

        await audit(tx, {
          actorId: actor.id,
          action: 'payment.create',
          entityType: 'Payment',
          entityId: created.id,
          after: {
            amount: input.amount,
            method: input.method,
            membershipId: input.membershipId ?? null,
            orderId: input.orderId ?? null,
          },
          meta,
        });
        return created.id;
      });

      return { payment: await load(actor, id), replayed: false };
    },

    /** Anula un pago registrado por error. No se borra: queda en el historial. */
    async void(actor: Actor, id: string, input: VoidPaymentInput, meta: RequestMeta) {
      await prisma.$transaction(async (tx) => {
        const p = await tx.payment.findUnique({ where: { id }, select: { status: true, orderId: true } });
        if (!p) throw AppError.notFound('Pago no encontrado');
        if (p.status !== 'PAID') {
          throw AppError.conflict('NOT_VOIDABLE', 'Solo se anulan pagos con estado PAGADO');
        }

        const order = p.orderId
          ? await tx.order.findUnique({ where: { id: p.orderId }, select: { status: true, total: true } })
          : null;
        if (order && (order.status === 'PREPARED' || order.status === 'DELIVERED')) {
          throw AppError.conflict('ORDER_ALREADY_PROCESSED', 'El pedido ya se preparó o entregó; no se puede anular el pago');
        }

        const { count } = await tx.payment.updateMany({ where: { id, status: 'PAID' }, data: { status: 'VOID' } });
        if (count === 0) throw AppError.conflict('STALE', 'El pago cambió; recarga e intenta de nuevo');

        // Si el pedido ya no está cubierto, vuelve a PENDIENTE
        if (p.orderId && order?.status === 'PAID') {
          const remaining = await sumPaid(tx, p.orderId);
          if (remaining.lt(order.total)) {
            await tx.order.update({ where: { id: p.orderId }, data: { status: 'PENDING', paidAt: null } });
          }
        }

        await audit(tx, {
          actorId: actor.id,
          action: 'payment.void',
          entityType: 'Payment',
          entityId: id,
          before: { status: 'PAID' },
          after: { status: 'VOID', reason: input.reason },
          meta,
        });
      });
      return load(actor, id);
    },

    /** Datos del recibo (el PDF se genera a partir de esto en la fase de reportes). */
    async receipt(actor: Actor, id: string) {
      const p = await load(actor, id);
      if (p.status !== 'PAID' || !p.paidAt) {
        throw AppError.conflict('NOT_PAID', 'Solo hay recibo para pagos con estado PAGADO');
      }
      return {
        receiptNumber: p.receiptNumber,
        issuedAt: p.paidAt,
        customer: { name: p.member?.user.name ?? null, documentId: p.member?.documentId ?? null },
        concept: p.membership
          ? `Membresía — ${p.membership.plan.name}`
          : p.order
            ? `Pedido #${p.order.orderNumber}`
            : 'Pago',
        amount: p.amount,
        currency: p.currency,
        method: p.method,
      };
    },
  };
}

export type PaymentService = ReturnType<typeof createPaymentService>;
