import { z } from 'zod';
import { isoDate, uuid } from '../../lib/validators';

/** Montos como texto decimal ("25.50") para no perder precisión con floats. */
export const money = z.preprocess(
  (v) => (typeof v === 'number' ? v.toFixed(2) : v),
  z.string().regex(/^\d{1,10}(\.\d{1,2})?$/, 'Monto inválido (máx. 2 decimales)'),
);

const method = z.enum(['CASH', 'TRANSFER', 'CARD', 'ONLINE']);

/** Pago que acompaña a crear o renovar una membresía (el monto es opcional: usa el precio del plan). */
export const paymentInputSchema = z
  .object({
    amount: money.optional(),
    method,
    notes: z.string().trim().max(500).optional(),
    /** Evita cobros duplicados si el cliente reintenta la petición */
    idempotencyKey: z.string().trim().min(8).max(100).optional(),
  })
  .strict();

/** Pago manual independiente: debe ir ligado a una membresía o a un pedido. */
export const createPaymentSchema = z
  .object({
    membershipId: uuid.optional(),
    orderId: uuid.optional(),
    amount: money,
    method,
    notes: z.string().trim().max(500).optional(),
    idempotencyKey: z.string().trim().min(8).max(100).optional(),
  })
  .strict()
  .refine((v) => v.membershipId || v.orderId, {
    message: 'Indica membershipId u orderId',
    path: ['membershipId'],
  });

export const voidPaymentSchema = z.object({ reason: z.string().trim().min(3).max(500) }).strict();

export const listPaymentsQuerySchema = z.object({
  memberId: uuid.optional(),
  membershipId: uuid.optional(),
  orderId: uuid.optional(),
  method: method.optional(),
  status: z.enum(['PENDING', 'PAID', 'FAILED', 'REFUNDED', 'VOID']).optional(),
  from: isoDate.optional(),
  to: isoDate.optional(),
  dir: z.enum(['asc', 'desc']).default('desc'),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(20),
});

export type PaymentInput = z.infer<typeof paymentInputSchema>;
export type CreatePaymentInput = z.infer<typeof createPaymentSchema>;
export type VoidPaymentInput = z.infer<typeof voidPaymentSchema>;
export type ListPaymentsQuery = z.infer<typeof listPaymentsQuerySchema>;
