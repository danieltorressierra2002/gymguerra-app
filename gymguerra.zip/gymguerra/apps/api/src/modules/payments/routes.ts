import { Router } from 'express';
import { ah } from '../../lib/async-handler';
import { uuid } from '../../lib/validators';
import { requestMeta, requireRole } from '../../middleware/auth';
import { createPaymentSchema, listPaymentsQuerySchema, voidPaymentSchema } from './schemas';
import type { PaymentService } from './payment-service';

export function paymentsRouter(service: PaymentService) {
  const r = Router();

  // Admin ve todos; el cliente solo los suyos (el servicio fuerza el filtro)
  r.get(
    '/',
    requireRole('ADMIN', 'MEMBER'),
    ah(async (req, res) => {
      res.json(await service.list(req.user!, listPaymentsQuerySchema.parse(req.query)));
    }),
  );

  r.get(
    '/:id',
    requireRole('ADMIN', 'MEMBER'),
    ah(async (req, res) => {
      res.json({ data: await service.getById(req.user!, uuid.parse(req.params.id)) });
    }),
  );

  r.get(
    '/:id/receipt',
    requireRole('ADMIN', 'MEMBER'),
    ah(async (req, res) => {
      res.json({ data: await service.receipt(req.user!, uuid.parse(req.params.id)) });
    }),
  );

  r.post(
    '/',
    requireRole('ADMIN'),
    ah(async (req, res) => {
      const { payment, replayed } = await service.create(
        req.user!,
        createPaymentSchema.parse(req.body),
        requestMeta(req),
      );
      // 200 si es un reintento con la misma idempotencyKey, 201 si se creó
      res.status(replayed ? 200 : 201).json({ data: payment });
    }),
  );

  r.post(
    '/:id/void',
    requireRole('ADMIN'),
    ah(async (req, res) => {
      const data = await service.void(
        req.user!,
        uuid.parse(req.params.id),
        voidPaymentSchema.parse(req.body),
        requestMeta(req),
      );
      res.json({ data });
    }),
  );

  return r;
}
