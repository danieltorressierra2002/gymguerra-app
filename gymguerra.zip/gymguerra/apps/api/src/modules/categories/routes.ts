import { Router } from 'express';
import { ah } from '../../lib/async-handler';
import { uuid } from '../../lib/validators';
import { requestMeta, requireRole } from '../../middleware/auth';
import { createCategorySchema, updateCategorySchema } from './schemas';
import type { CategoryService } from './service';

export function categoriesRouter(service: CategoryService) {
  const r = Router();
  r.use(requireRole('ADMIN'));

  r.get('/', ah(async (_req, res) => void res.json({ data: await service.list() })));

  r.post(
    '/',
    ah(async (req, res) => {
      const data = await service.create(req.user!, createCategorySchema.parse(req.body), requestMeta(req));
      res.status(201).json({ data });
    }),
  );

  r.patch(
    '/:id',
    ah(async (req, res) => {
      const data = await service.update(
        req.user!,
        uuid.parse(req.params.id),
        updateCategorySchema.parse(req.body ?? {}),
        requestMeta(req),
      );
      res.json({ data });
    }),
  );

  r.delete(
    '/:id',
    ah(async (req, res) => {
      await service.remove(req.user!, uuid.parse(req.params.id), requestMeta(req));
      res.status(204).end();
    }),
  );

  return r;
}
