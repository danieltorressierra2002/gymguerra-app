import type { Prisma, PrismaClient } from '@prisma/client';
import { slugify } from '@gymguerra/shared';
import { audit, type RequestMeta } from '../../lib/audit';
import { AppError } from '../../lib/errors';
import type { Actor } from '../../lib/permissions';
import { uniqueSlug } from '../../lib/unique-slug';
import type { CreateCategoryInput, UpdateCategoryInput } from './schemas';

type Db = Prisma.TransactionClient;

const select = { id: true, name: true, slug: true, isActive: true, createdAt: true, updatedAt: true } as const;

export function createCategoryService({ prisma, now = () => new Date() }: { prisma: PrismaClient; now?: () => Date }) {
  async function ensureNameFree(db: Pick<Db, 'productCategory'>, name: string, excludeId?: string) {
    const taken = await db.productCategory.findFirst({
      where: {
        name: { equals: name, mode: 'insensitive' },
        deletedAt: null,
        ...(excludeId ? { id: { not: excludeId } } : {}),
      },
      select: { id: true },
    });
    if (taken) throw AppError.conflict('CATEGORY_NAME_TAKEN', 'Ya existe una categoría con ese nombre');
  }

  return {
    /** Tienda pública: solo categorías activas. */
    async listPublic() {
      const rows = await prisma.productCategory.findMany({
        where: { isActive: true, deletedAt: null },
        orderBy: { name: 'asc' },
        select: { id: true, name: true, slug: true },
      });
      return rows;
    },

    async list() {
      return prisma.productCategory.findMany({ where: { deletedAt: null }, orderBy: { name: 'asc' }, select });
    },

    async create(actor: Actor, input: CreateCategoryInput, meta: RequestMeta) {
      return prisma.$transaction(async (tx) => {
        await ensureNameFree(tx, input.name);
        // El slug se calcula una vez y no cambia al renombrar, para no romper enlaces
        const slug = await uniqueSlug(slugify(input.name, 60, 'categoria'), async (s) =>
          Boolean(await tx.productCategory.findUnique({ where: { slug: s }, select: { id: true } })),
        );
        const created = await tx.productCategory.create({
          data: { name: input.name, slug, isActive: input.isActive },
          select,
        });
        await audit(tx, {
          actorId: actor.id,
          action: 'category.create',
          entityType: 'ProductCategory',
          entityId: created.id,
          after: { name: input.name },
          meta,
        });
        return created;
      });
    },

    async update(actor: Actor, id: string, input: UpdateCategoryInput, meta: RequestMeta) {
      return prisma.$transaction(async (tx) => {
        const current = await tx.productCategory.findFirst({ where: { id, deletedAt: null }, select: { id: true } });
        if (!current) throw AppError.notFound('Categoría no encontrada');
        if (input.name !== undefined) await ensureNameFree(tx, input.name, id);
        const updated = await tx.productCategory.update({ where: { id }, data: input, select });
        await audit(tx, {
          actorId: actor.id,
          action: 'category.update',
          entityType: 'ProductCategory',
          entityId: id,
          after: { changed: Object.keys(input) },
          meta,
        });
        return updated;
      });
    },

    /** Baja lógica. No se permite si aún tiene productos: muévelos o quítalos primero. */
    async remove(actor: Actor, id: string, meta: RequestMeta) {
      await prisma.$transaction(async (tx) => {
        const current = await tx.productCategory.findFirst({ where: { id, deletedAt: null }, select: { id: true } });
        if (!current) throw AppError.notFound('Categoría no encontrada');
        const products = await tx.product.count({ where: { categoryId: id, deletedAt: null } });
        if (products > 0) {
          throw AppError.conflict(
            'CATEGORY_HAS_PRODUCTS',
            `La categoría tiene ${products} producto(s). Muévelos o quítalos antes de eliminarla.`,
          );
        }
        await tx.productCategory.update({ where: { id }, data: { deletedAt: now(), isActive: false } });
        await audit(tx, {
          actorId: actor.id,
          action: 'category.delete',
          entityType: 'ProductCategory',
          entityId: id,
          meta,
        });
      });
    },
  };
}

export type CategoryService = ReturnType<typeof createCategoryService>;
