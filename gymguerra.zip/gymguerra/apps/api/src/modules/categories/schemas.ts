import { z } from 'zod';

const name = z.string().trim().min(2).max(60);

export const createCategorySchema = z.object({ name, isActive: z.boolean().default(true) }).strict();
export const updateCategorySchema = z.object({ name, isActive: z.boolean() }).partial().strict();

export type CreateCategoryInput = z.infer<typeof createCategorySchema>;
export type UpdateCategoryInput = z.infer<typeof updateCategorySchema>;
