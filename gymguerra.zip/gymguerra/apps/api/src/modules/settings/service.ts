import type { Prisma } from '@prisma/client';
import { z } from 'zod';
import { DEFAULT_WARNING_DAYS } from '@gymguerra/shared';
import { audit, type RequestMeta } from '../../lib/audit';
import type { Actor } from '../../lib/permissions';

type Db = Prisma.TransactionClient;

export const WARNING_DAYS_KEY = 'membership.warningDays';
export const warningDaysSchema = z.number().int().min(0).max(60);

/** Umbral del semáforo (antes DIAS_ALERTA_AMARILLO). Si falta o es inválido, usa el valor por defecto. */
export async function getMembershipSettings(db: Pick<Db, 'setting'>) {
  const row = await db.setting.findUnique({ where: { key: WARNING_DAYS_KEY } });
  const parsed = warningDaysSchema.safeParse(row?.value);
  return { warningDays: parsed.success ? parsed.data : DEFAULT_WARNING_DAYS };
}

export async function updateWarningDays(
  prisma: { $transaction: <T>(fn: (tx: Db) => Promise<T>) => Promise<T> },
  actor: Actor,
  warningDays: number,
  meta: RequestMeta,
) {
  return prisma.$transaction(async (tx) => {
    const before = await getMembershipSettings(tx);
    await tx.setting.upsert({
      where: { key: WARNING_DAYS_KEY },
      create: { key: WARNING_DAYS_KEY, value: warningDays, updatedById: actor.id },
      update: { value: warningDays, updatedById: actor.id },
    });
    await audit(tx, {
      actorId: actor.id,
      action: 'settings.update',
      entityType: 'Setting',
      entityId: WARNING_DAYS_KEY,
      before: { warningDays: before.warningDays },
      after: { warningDays },
      meta,
    });
    return { warningDays };
  });
}
