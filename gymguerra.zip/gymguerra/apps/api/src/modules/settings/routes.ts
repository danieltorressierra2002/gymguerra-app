import { Router } from 'express';
import type { PrismaClient } from '@prisma/client';
import { z } from 'zod';
import { ah } from '../../lib/async-handler';
import { requestMeta, requireRole } from '../../middleware/auth';
import { getMembershipSettings, updateWarningDays, warningDaysSchema } from './service';

const bodySchema = z.object({ warningDays: warningDaysSchema }).strict();

export function settingsRouter(prisma: PrismaClient) {
  const r = Router();

  // Lectura: cualquier usuario autenticado (el frontend la usa para pintar el semáforo)
  r.get(
    '/membership',
    ah(async (_req, res) => {
      res.json({ data: await getMembershipSettings(prisma) });
    }),
  );

  // Escritura: solo administrador. Configurable desde el panel.
  r.put(
    '/membership',
    requireRole('ADMIN'),
    ah(async (req, res) => {
      const { warningDays } = bodySchema.parse(req.body);
      res.json({ data: await updateWarningDays(prisma, req.user!, warningDays, requestMeta(req)) });
    }),
  );

  return r;
}
