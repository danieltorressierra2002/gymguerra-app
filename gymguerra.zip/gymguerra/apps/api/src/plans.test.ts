import request from 'supertest';
import { beforeEach, describe, expect, it } from 'vitest';
import { app, bearer, ids, planCalls } from './test-helpers';

const valid = {
  name: 'Trimestral',
  price: '60.00',
  currency: 'USD',
  duration: { months: 3 },
};

describe('planes: lista pública', () => {
  it('no exige sesión, usa caché y solo expone datos públicos', async () => {
    const res = await request(app).get('/api/public/plans').expect(200);
    expect(res.headers['cache-control']).toContain('max-age=60');
    const plan = res.body.data[0];
    expect(plan.duration).toEqual({ months: 1 });
    expect(plan).not.toHaveProperty('isActive');
    expect(plan).not.toHaveProperty('sortOrder');
    expect(plan).not.toHaveProperty('durationMonths');
  });

  it('solo consulta planes activos y no borrados', async () => {
    planCalls.findMany.length = 0;
    await request(app).get('/api/public/plans').expect(200);
    expect(planCalls.findMany[0]?.where).toEqual({ isActive: true, deletedAt: null });
  });
});

describe('planes: autorización', () => {
  it('requiere sesión fuera de la lista pública', async () => {
    await request(app).get('/api/plans').expect(401);
  });

  it('solo el administrador crea, edita y elimina', async () => {
    for (const role of ['trainer', 'member']) {
      await request(app).post('/api/plans').set(bearer(role)).send(valid).expect(403);
      await request(app).patch(`/api/plans/${ids.plan}`).set(bearer(role)).send({ isActive: false }).expect(403);
      await request(app).delete(`/api/plans/${ids.plan}`).set(bearer(role)).expect(403);
    }
  });
});

describe('planes: visibilidad de inactivos', () => {
  beforeEach(() => {
    planCalls.findMany.length = 0;
  });

  it('el cliente solo ve planes activos, aunque pida los inactivos', async () => {
    await request(app).get('/api/plans?includeInactive=true').set(bearer('member')).expect(200);
    expect(planCalls.findMany[0]?.where).toMatchObject({ isActive: true });
  });

  it('el administrador ve activos por defecto', async () => {
    await request(app).get('/api/plans').set(bearer('admin')).expect(200);
    expect(planCalls.findMany[0]?.where).toMatchObject({ isActive: true });
  });

  it('el administrador puede pedir también los inactivos', async () => {
    await request(app).get('/api/plans?includeInactive=true').set(bearer('admin')).expect(200);
    expect(planCalls.findMany[0]?.where).not.toHaveProperty('isActive');
  });
});

describe('planes: validación', () => {
  const post = (body: unknown) => request(app).post('/api/plans').set(bearer('admin')).send(body as object);

  it('exige duración en meses o en días, nunca las dos ni ninguna', async () => {
    await post({ ...valid, duration: { months: 1, days: 30 } }).expect(400);
    await post({ ...valid, duration: {} }).expect(400);
    const { duration: _omitida, ...sinDuracion } = valid;
    await post(sinDuracion).expect(400);
  });

  it('rechaza duraciones no positivas o fraccionarias', async () => {
    await post({ ...valid, duration: { months: 0 } }).expect(400);
    await post({ ...valid, duration: { days: -5 } }).expect(400);
    await post({ ...valid, duration: { months: 1.5 } }).expect(400);
  });

  it('rechaza precios con más de 2 decimales o negativos', async () => {
    await post({ ...valid, price: '10.999' }).expect(400);
    await post({ ...valid, price: '-1' }).expect(400);
  });

  it('exige moneda ISO en mayúsculas', async () => {
    await post({ ...valid, currency: 'usd' }).expect(400);
    await post({ ...valid, currency: 'DOLAR' }).expect(400);
  });

  it('rechaza campos que no se pueden fijar desde la API', async () => {
    await post({ ...valid, deletedAt: '2026-01-01' }).expect(400);
    await post({ ...valid, id: ids.plan }).expect(400);
  });

  it('limita la lista de beneficios', async () => {
    await post({ ...valid, benefits: Array.from({ length: 21 }, (_, i) => `b${i}`) }).expect(400);
    await post({ ...valid, benefits: [''] }).expect(400);
  });

  it('en la edición valida igual y rechaza ids que no son UUID', async () => {
    await request(app).patch(`/api/plans/${ids.plan}`).set(bearer('admin')).send({ price: '1.234' }).expect(400);
    await request(app).patch('/api/plans/abc').set(bearer('admin')).send({}).expect(400);
    await request(app).delete('/api/plans/abc').set(bearer('admin')).expect(400);
  });
});
