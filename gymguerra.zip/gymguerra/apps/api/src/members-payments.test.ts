import request from 'supertest';
import { beforeEach, describe, expect, it } from 'vitest';
import { app, bearer, ids, provisionerCalls } from './test-helpers';

const newMember = {
  name: 'Cliente de Prueba',
  email: 'nuevo@test.dev',
  documentId: 'DOC-0001',
};

describe('miembros: autorización', () => {
  it('el cliente no puede listar ni crear clientes', async () => {
    await request(app).get('/api/members').set(bearer('member')).expect(403);
    await request(app).post('/api/members').set(bearer('member')).send(newMember).expect(403);
  });

  it('el entrenador no puede crear, editar ni dar de baja', async () => {
    await request(app).post('/api/members').set(bearer('trainer')).send(newMember).expect(403);
    await request(app).patch(`/api/members/${ids.member}`).set(bearer('trainer')).send({}).expect(403);
    await request(app).delete(`/api/members/${ids.member}`).set(bearer('trainer')).expect(403);
  });

  it('el cliente no puede dar de baja a nadie', async () => {
    await request(app).delete(`/api/members/${ids.member}`).set(bearer('member')).expect(403);
  });

  it('solo el administrador reenvía invitaciones', async () => {
    await request(app).post(`/api/members/${ids.member}/invite`).set(bearer('trainer')).expect(403);
    await request(app).post(`/api/members/${ids.member}/invite`).set(bearer('member')).expect(403);
    await request(app).post('/api/members/no-es-uuid/invite').set(bearer('admin')).expect(400);
  });

  it('el entrenador no usa el perfil exclusivo de cliente', async () => {
    await request(app).get('/api/members/me').set(bearer('trainer')).expect(403);
  });
});

describe('miembros: validación', () => {
  it('rechaza correo inválido y no acepta que el administrador fije una contraseña', async () => {
    const r1 = await request(app).post('/api/members').set(bearer('admin')).send({ ...newMember, email: 'no-es-correo' }).expect(400);
    expect(r1.body.error.code).toBe('VALIDATION_ERROR');
    await request(app).post('/api/members').set(bearer('admin')).send({ ...newMember, password: 'gymguerra2026' }).expect(400);
  });

  it('no permite asignar el rol por la API (mass assignment)', async () => {
    await request(app).post('/api/members').set(bearer('admin')).send({ ...newMember, role: 'ADMIN' }).expect(400);
  });

  it('un cliente no puede cambiarse el entrenador ni el nombre', async () => {
    await request(app).patch(`/api/members/${ids.member}`).set(bearer('member')).send({ trainerId: ids.plan }).expect(400);
    await request(app).patch(`/api/members/${ids.member}`).set(bearer('member')).send({ name: 'Otro' }).expect(400);
  });

  it('rechaza filtros de listado inválidos', async () => {
    await request(app).get('/api/members?pageSize=1000').set(bearer('admin')).expect(400);
    await request(app).get('/api/members?hasTrainer=quizas').set(bearer('admin')).expect(400);
  });
});

describe('miembros: unicidad antes de crear la cuenta', () => {
  beforeEach(() => {
    provisionerCalls.create = 0;
  });

  it('correo repetido → 409 y no se crea la cuenta de acceso', async () => {
    const res = await request(app)
      .post('/api/members')
      .set(bearer('admin'))
      .send({ ...newMember, email: 'taken@test.dev' })
      .expect(409);
    expect(res.body.error.code).toBe('EMAIL_TAKEN');
    expect(provisionerCalls.create).toBe(0);
  });

  it('documento repetido → 409 y no se crea la cuenta de acceso', async () => {
    const res = await request(app)
      .post('/api/members')
      .set(bearer('admin'))
      .send({ ...newMember, documentId: 'DUP-1' })
      .expect(409);
    expect(res.body.error.code).toBe('DOCUMENT_TAKEN');
    expect(provisionerCalls.create).toBe(0);
  });
});

describe('pagos: autorización', () => {
  it('el entrenador no accede a pagos', async () => {
    await request(app).get('/api/payments').set(bearer('trainer')).expect(403);
  });

  it('el cliente no puede registrar ni anular pagos', async () => {
    const body = { membershipId: ids.membership, amount: '25.00', method: 'CASH' };
    await request(app).post('/api/payments').set(bearer('member')).send(body).expect(403);
    await request(app).post(`/api/payments/${ids.member}/void`).set(bearer('member')).send({ reason: 'error' }).expect(403);
  });
});

describe('pagos: validación', () => {
  const base = { membershipId: ids.membership, amount: '25.00', method: 'CASH' };

  it('exige membershipId u orderId', async () => {
    const res = await request(app).post('/api/payments').set(bearer('admin')).send({ amount: '25.00', method: 'CASH' }).expect(400);
    expect(res.body.error.code).toBe('VALIDATION_ERROR');
  });

  it('rechaza montos con más de 2 decimales o negativos', async () => {
    await request(app).post('/api/payments').set(bearer('admin')).send({ ...base, amount: '12.345' }).expect(400);
    await request(app).post('/api/payments').set(bearer('admin')).send({ ...base, amount: '-5' }).expect(400);
    await request(app).post('/api/payments').set(bearer('admin')).send({ ...base, amount: 'abc' }).expect(400);
  });

  it('rechaza monto cero', async () => {
    const res = await request(app).post('/api/payments').set(bearer('admin')).send({ ...base, amount: '0.00' }).expect(400);
    expect(res.body.error.code).toBe('INVALID_AMOUNT');
  });

  it('no deja que el cliente elija la moneda ni el estado', async () => {
    await request(app).post('/api/payments').set(bearer('admin')).send({ ...base, currency: 'EUR' }).expect(400);
    await request(app).post('/api/payments').set(bearer('admin')).send({ ...base, status: 'PAID' }).expect(400);
  });

  it('exige motivo al anular y valida la clave de idempotencia', async () => {
    await request(app).post(`/api/payments/${ids.member}/void`).set(bearer('admin')).send({}).expect(400);
    await request(app).post('/api/payments').set(bearer('admin')).send({ ...base, idempotencyKey: 'corta' }).expect(400);
  });
});
