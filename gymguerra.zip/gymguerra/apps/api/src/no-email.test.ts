import request from 'supertest';
import { beforeEach, describe, expect, it } from 'vitest';
import { buildApp } from './app';
import { app as appWithEmail, bearer, ids, prisma, provisioner, sentEmails, verifier } from './test-helpers';

// Mismo sistema pero SIN proveedor de correo: es la configuración predeterminada
const appNoEmail = buildApp({
  prisma,
  verifier,
  provisioner,
  emailSender: null,
  config: {
    corsOrigins: ['http://localhost:5173'],
    trustProxyHops: 0,
    timeZone: 'UTC',
    appName: 'Gimnasio Guerra',
    secureCookies: false,
    refreshTtlSeconds: 2_592_000,
  },
});

describe('sin correos (EMAIL_PROVIDER=none)', () => {
  beforeEach(() => {
    sentEmails.length = 0;
  });

  it('el administrador recibe el enlace de activación para entregarlo al cliente', async () => {
    const res = await request(appNoEmail).post(`/api/members/${ids.member}/invite`).set(bearer('admin')).expect(200);
    expect(res.body.data.sent).toBe(false);
    expect(res.body.data.setupLink).toMatch(/^https:\/\/gym\.test\/accion/);
    expect(res.headers['cache-control']).toBe('no-store'); // el enlace nunca se guarda en cachés
    expect(sentEmails).toHaveLength(0);
  });

  it('solo el administrador puede pedir el enlace', async () => {
    await request(appNoEmail).post(`/api/members/${ids.member}/invite`).set(bearer('member')).expect(403);
    await request(appNoEmail).post(`/api/members/${ids.member}/invite`).set(bearer('trainer')).expect(403);
    await request(appNoEmail).post(`/api/members/${ids.member}/invite`).expect(401);
  });

  it('un cliente que no existe da 404', async () => {
    await request(appNoEmail).post(`/api/members/${ids.plan}/invite`).set(bearer('admin')).expect(404);
  });

  it('«olvidé mi contraseña» explica que hay que pedir el enlace a la administración', async () => {
    const res = await request(appNoEmail).post('/api/auth/forgot-password').send({ email: 'ana@correo.cu' }).expect(501);
    expect(res.body.error.code).toBe('EMAIL_DISABLED');
    expect(res.body.error.message).toMatch(/administración/);
  });

  it('valida el correo antes de contestar 501', async () => {
    await request(appNoEmail).post('/api/auth/forgot-password').send({ email: 'no-es-correo' }).expect(400);
  });

  it('con correo configurado el mismo enlace además se envía', async () => {
    const res = await request(appWithEmail).post(`/api/members/${ids.member}/invite`).set(bearer('admin')).expect(200);
    expect(res.body.data.sent).toBe(true);
    expect(res.body.data.setupLink).toBeTruthy();
    expect(sentEmails).toHaveLength(1);
    expect(sentEmails[0]?.to).toBe('cliente@test.dev');
  });
});
