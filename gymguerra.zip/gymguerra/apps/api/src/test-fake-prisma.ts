import { randomUUID } from 'node:crypto';
import type { PrismaClient } from '@prisma/client';

/**
 * Base de datos en memoria con solo lo que usa la autenticación propia:
 * igualdad, { not } y { increment }. Si el código empieza a usar otra cosa, falla a propósito.
 */
type Row = Record<string, any>; // eslint-disable-line @typescript-eslint/no-explicit-any
const isObj = (v: unknown): v is Record<string, unknown> => !!v && typeof v === 'object' && !(v instanceof Date);

function matches(row: Row, where: Row): boolean {
  return Object.entries(where).every(([key, cond]) => {
    if (isObj(cond)) {
      if ('not' in cond) return (row[key] ?? null) !== (cond.not ?? null);
      throw new Error(`Operador no soportado por el prisma falso en «${key}»`);
    }
    return (row[key] ?? null) === (cond ?? null);
  });
}

function applyData(row: Row, data: Row) {
  for (const [k, v] of Object.entries(data)) {
    row[k] = isObj(v) && 'increment' in v ? (row[k] ?? 0) + (v.increment as number) : v;
  }
}

function model(defaults: () => Row = () => ({})) {
  const rows: Row[] = [];
  return {
    rows,
    async create({ data }: { data: Row }): Promise<Row> {
      const row: Row = { id: randomUUID(), createdAt: new Date(), ...defaults(), ...data };
      rows.push(row);
      return row;
    },
    async findFirst({ where }: { where: Row }) {
      return rows.find((r) => matches(r, where)) ?? null;
    },
    async findUnique({ where }: { where: Row }) {
      return rows.find((r) => matches(r, where)) ?? null;
    },
    async update({ where, data }: { where: Row; data: Row }) {
      const row = rows.find((r) => matches(r, where));
      if (!row) throw new Error('Registro no encontrado');
      applyData(row, data);
      return row;
    },
    async updateMany({ where, data }: { where: Row; data: Row }) {
      const hit = rows.filter((r) => matches(r, where));
      hit.forEach((r) => applyData(r, data));
      return { count: hit.length };
    },
  };
}

export function createFakePrisma(now: () => Date) {
  const parts = {
    user: model(() => ({
      status: 'PENDING',
      role: 'MEMBER',
      failedLogins: 0,
      lockedUntil: null,
      deletedAt: null,
      passwordHash: null,
      emailVerifiedAt: null,
      authProvider: 'local',
    })),
    session: model(() => ({ revokedAt: null, previousTokenHash: null, lastUsedAt: now() })),
    authToken: model(() => ({ usedAt: null })),
    auditLog: model(),
    setting: { findUnique: async () => null },
  };
  // La «transacción» comparte los mismos datos (no hay reversión): basta para probar la lógica de negocio
  return { ...parts, $transaction: async <T>(fn: (tx: typeof parts) => Promise<T>) => fn(parts) };
}

export type FakePrisma = ReturnType<typeof createFakePrisma>;
export const asPrisma = (db: FakePrisma) => db as unknown as PrismaClient;
