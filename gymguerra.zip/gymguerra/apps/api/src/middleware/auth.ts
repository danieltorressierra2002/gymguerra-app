import type { Request, RequestHandler } from 'express';
import type { PrismaClient } from '@prisma/client';
import { AppError } from '../lib/errors';
import type { Actor, Role } from '../lib/permissions';
import type { RequestMeta } from '../lib/audit';
import type { TokenVerifier, VerifiedIdentity } from '../modules/auth/verifier';

export type AuthUser = Actor & { email: string; sessionId?: string };

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      user?: AuthUser;
    }
  }
}

/**
 * Autenticación por cabecera "Authorization: Bearer <token>".
 * Al no usar cookies, no hay superficie de CSRF. Si más adelante se pasa a sesiones
 * por cookie, se añade protección CSRF (SameSite + token) en ese momento.
 */
export function authenticate(prisma: PrismaClient, verifier: TokenVerifier): RequestHandler {
  return async (req, _res, next) => {
    try {
      const match = req.get('authorization')?.match(/^Bearer\s+(\S+)$/i);
      if (!match?.[1]) throw AppError.unauthorized();

      let identity: VerifiedIdentity;
      try {
        identity = await verifier.verify(match[1]);
      } catch {
        // Mensaje genérico: no revelamos por qué falló el token
        throw AppError.unauthorized('INVALID_TOKEN', 'Sesión inválida o expirada');
      }

      const user = await prisma.user.findFirst({
        where: { authProvider: identity.provider, authSubject: identity.subject, deletedAt: null },
        include: { member: { select: { id: true } }, trainer: { select: { id: true } } },
      });
      if (!user) {
        throw AppError.unauthorized('ACCOUNT_NOT_PROVISIONED', 'Tu cuenta aún no está habilitada');
      }
      if (user.status === 'SUSPENDED') {
        throw AppError.forbidden('ACCOUNT_SUSPENDED', 'Tu cuenta está suspendida');
      }
      if (user.status === 'PENDING') {
        if (!identity.emailVerified) {
          throw AppError.forbidden('EMAIL_NOT_VERIFIED', 'Confirma tu correo para continuar');
        }
        // Correo confirmado en el proveedor: la cuenta pasa a activa
        await prisma.user.update({
          where: { id: user.id },
          data: { status: 'ACTIVE', emailVerifiedAt: new Date() },
        });
      }

      req.user = {
        id: user.id,
        email: user.email,
        sessionId: identity.sessionId,
        role: user.role,
        memberId: user.member?.id ?? null,
        trainerId: user.trainer?.id ?? null,
      };
      next();
    } catch (err) {
      next(err);
    }
  };
}

/** Exige uno de los roles indicados (se usa después de authenticate). */
export function requireRole(...roles: Role[]): RequestHandler {
  return (req, _res, next) => {
    if (!req.user) return next(AppError.unauthorized());
    if (!roles.includes(req.user.role)) return next(AppError.forbidden());
    next();
  };
}

export function requestMeta(req: Request): RequestMeta {
  return { ip: req.ip, userAgent: req.get('user-agent')?.slice(0, 255) };
}
