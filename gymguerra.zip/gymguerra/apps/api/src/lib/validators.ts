import { z } from 'zod';
import { isValidIsoDate } from '@gymguerra/shared';

export const uuid = z.string().uuid();
export const isoDate = z.string().refine(isValidIsoDate, 'Fecha inválida (usa AAAA-MM-DD)');
