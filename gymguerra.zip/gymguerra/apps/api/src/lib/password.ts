import { randomBytes, scrypt, timingSafeEqual, type ScryptOptions } from 'node:crypto';

/**
 * Hash de contraseñas con scrypt, incluido en Node (sin compilar nada: funciona igual en cualquier servidor).
 * Parámetros equivalentes a los que recomienda OWASP: N=2^15, r=8, p=3 (≈32 MiB por cálculo).
 * Formato guardado: scrypt$N$r$p$sal$hash. Los parámetros viajan con el hash, así que se pueden
 * endurecer más adelante y las contraseñas viejas se actualizan solas al iniciar sesión.
 */
export interface ScryptParams {
  N: number;
  r: number;
  p: number;
}

export const DEFAULT_PARAMS: ScryptParams = { N: 2 ** 15, r: 8, p: 3 };

const KEY_LENGTH = 32;
const SALT_LENGTH = 16;

function derive(password: string, salt: Buffer, params: ScryptParams): Promise<Buffer> {
  const options: ScryptOptions = { N: params.N, r: params.r, p: params.p, maxmem: 256 * params.N * params.r };
  // NFKC: la misma contraseña escrita con otra forma Unicode (é vs e + tilde) da el mismo hash
  return new Promise((resolve, reject) => {
    scrypt(password.normalize('NFKC'), salt, KEY_LENGTH, options, (err, key) => (err ? reject(err) : resolve(key)));
  });
}

function parse(stored: string): { params: ScryptParams; salt: Buffer; hash: Buffer } | null {
  const parts = stored.split('$');
  if (parts.length !== 6 || parts[0] !== 'scrypt') return null;
  const [N, r, p] = [Number(parts[1]), Number(parts[2]), Number(parts[3])];
  // Límites: un valor corrupto no puede hacernos gastar memoria o CPU sin control
  const ok = (n: number, min: number, max: number) => Number.isInteger(n) && n >= min && n <= max;
  if (!ok(N, 2 ** 10, 2 ** 20) || (N & (N - 1)) !== 0 || !ok(r, 1, 32) || !ok(p, 1, 16)) return null;
  const salt = Buffer.from(parts[4] ?? '', 'base64url');
  const hash = Buffer.from(parts[5] ?? '', 'base64url');
  if (salt.length === 0 || hash.length !== KEY_LENGTH) return null;
  return { params: { N, r, p }, salt, hash };
}

export function createPasswordHasher(defaults: ScryptParams = DEFAULT_PARAMS) {
  return {
    async hash(password: string): Promise<string> {
      const salt = randomBytes(SALT_LENGTH);
      const key = await derive(password, salt, defaults);
      return `scrypt$${defaults.N}$${defaults.r}$${defaults.p}$${salt.toString('base64url')}$${key.toString('base64url')}`;
    },

    async verify(password: string, stored: string): Promise<boolean> {
      const parsed = parse(stored);
      if (!parsed) return false;
      const key = await derive(password, parsed.salt, parsed.params);
      return timingSafeEqual(key, parsed.hash);
    },

    /** true si el hash usa parámetros más débiles que los actuales (o tiene un formato desconocido). */
    needsRehash(stored: string): boolean {
      const parsed = parse(stored);
      if (!parsed) return true;
      const { N, r, p } = parsed.params;
      return N < defaults.N || r < defaults.r || p < defaults.p;
    },

    /** Gasta el mismo tiempo que una verificación real: así no se nota si el correo existe. */
    async dummyVerify(password: string): Promise<void> {
      await derive(password, randomBytes(SALT_LENGTH), defaults);
    },
  };
}

export type PasswordHasher = ReturnType<typeof createPasswordHasher>;
