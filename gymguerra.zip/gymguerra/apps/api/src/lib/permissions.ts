/**
 * Reglas de acceso puras (sin base de datos) para poder probarlas fácil.
 * La API las aplica siempre; PostgreSQL RLS es una segunda barrera opcional.
 */
export type Role = 'ADMIN' | 'TRAINER' | 'MEMBER';

export interface Actor {
  id: string;
  role: Role;
  /** members.id del usuario, si es cliente */
  memberId: string | null;
  /** trainers.id del usuario, si es entrenador */
  trainerId: string | null;
}

/**
 * Admin ve todo. Entrenador ve solo a sus clientes asignados.
 * Cliente ve solo lo suyo.
 */
export function canViewMember(
  actor: Actor,
  target: { memberId: string; trainerId: string | null },
): boolean {
  switch (actor.role) {
    case 'ADMIN':
      return true;
    case 'TRAINER':
      return actor.trainerId !== null && target.trainerId === actor.trainerId;
    case 'MEMBER':
      return actor.memberId !== null && target.memberId === actor.memberId;
    default:
      return false;
  }
}
