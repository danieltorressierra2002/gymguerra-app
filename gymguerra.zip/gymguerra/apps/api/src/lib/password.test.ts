import { describe, expect, it } from 'vitest';
import { createPasswordHasher } from './password';

// Parámetros livianos solo para que las pruebas sean rápidas
const fast = { N: 2 ** 10, r: 8, p: 1 };
const hasher = createPasswordHasher(fast);

describe('contraseñas (scrypt)', () => {
  it('verifica la contraseña correcta y rechaza la incorrecta', async () => {
    const stored = await hasher.hash('una frase larga y segura');
    expect(await hasher.verify('una frase larga y segura', stored)).toBe(true);
    expect(await hasher.verify('otra cosa distinta', stored)).toBe(false);
  });

  it('nunca guarda la contraseña en claro y usa una sal distinta cada vez', async () => {
    const a = await hasher.hash('misma contraseña 123');
    const b = await hasher.hash('misma contraseña 123');
    expect(a).not.toContain('misma contraseña');
    expect(a).not.toBe(b);
    expect(a.startsWith('scrypt$1024$8$1$')).toBe(true);
  });

  it('la misma contraseña en Unicode compuesto o descompuesto es equivalente', async () => {
    const stored = await hasher.hash('contraseña-é-segura');
    expect(await hasher.verify('contrasen\u0303a-e\u0301-segura', stored)).toBe(true);
  });

  it('un hash corrupto o con parámetros absurdos devuelve false (no lanza ni consume recursos)', async () => {
    expect(await hasher.verify('x', 'no es un hash')).toBe(false);
    expect(await hasher.verify('x', 'scrypt$1024$8$1$AAAA$AAAA')).toBe(false);
    expect(await hasher.verify('x', 'scrypt$1073741824$8$1$AAAAAAAAAAAAAAAAAAAAAA$AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')).toBe(false);
    expect(await hasher.verify('x', 'bcrypt$1024$8$1$AAAA$AAAA')).toBe(false);
  });

  it('detecta cuándo hay que reforzar un hash antiguo', async () => {
    const weak = await hasher.hash('abc');
    const strong = createPasswordHasher({ N: 2 ** 11, r: 8, p: 1 });
    expect(hasher.needsRehash(weak)).toBe(false);
    expect(strong.needsRehash(weak)).toBe(true);
    expect(hasher.needsRehash('formato desconocido')).toBe(true);
  });

  it('dummyVerify termina sin error (equilibra el tiempo cuando el correo no existe)', async () => {
    await expect(hasher.dummyVerify('lo que sea')).resolves.toBeUndefined();
  });
});
