import { describe, expect, it } from 'vitest';
import { canViewMember, type Actor } from './permissions';

const admin: Actor = { id: 'u1', role: 'ADMIN', memberId: null, trainerId: null };
const trainer: Actor = { id: 'u2', role: 'TRAINER', memberId: null, trainerId: 't1' };
const member: Actor = { id: 'u3', role: 'MEMBER', memberId: 'm1', trainerId: null };

describe('canViewMember', () => {
  it('el administrador ve a cualquier cliente', () => {
    expect(canViewMember(admin, { memberId: 'm9', trainerId: null })).toBe(true);
  });

  it('el entrenador ve solo a sus clientes asignados', () => {
    expect(canViewMember(trainer, { memberId: 'm1', trainerId: 't1' })).toBe(true);
    expect(canViewMember(trainer, { memberId: 'm2', trainerId: 't2' })).toBe(false);
    expect(canViewMember(trainer, { memberId: 'm3', trainerId: null })).toBe(false);
  });

  it('el cliente ve solo lo suyo', () => {
    expect(canViewMember(member, { memberId: 'm1', trainerId: 't1' })).toBe(true);
    expect(canViewMember(member, { memberId: 'm2', trainerId: 't1' })).toBe(false);
  });

  it('un entrenador o cliente sin perfil asociado no ve nada', () => {
    expect(canViewMember({ ...trainer, trainerId: null }, { memberId: 'm1', trainerId: null })).toBe(false);
    expect(canViewMember({ ...member, memberId: null }, { memberId: 'm1', trainerId: null })).toBe(false);
  });
});
