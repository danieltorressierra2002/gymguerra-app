import { describe, expect, it } from 'vitest';
import { uniqueSlug } from './unique-slug';
import { AppError } from './errors';

describe('uniqueSlug', () => {
  it('usa el slug base si está libre', async () => {
    expect(await uniqueSlug('batido', async () => false)).toBe('batido');
  });
  it('añade sufijo si hay colisión', async () => {
    const taken = new Set(['batido', 'batido-2']);
    expect(await uniqueSlug('batido', async (s) => taken.has(s))).toBe('batido-3');
  });
  it('falla de forma controlada si no encuentra uno libre', async () => {
    await expect(uniqueSlug('x', async () => true)).rejects.toBeInstanceOf(AppError);
  });
});
