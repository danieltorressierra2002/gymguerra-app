import type { Prisma } from '@prisma/client';

export interface RequestMeta {
  ip?: string;
  userAgent?: string;
}

/**
 * Registra una acción sensible en audit_logs. Se llama DENTRO de la misma
 * transacción que el cambio, así nunca queda un cambio sin su rastro.
 */
export async function audit(
  tx: Prisma.TransactionClient,
  entry: {
    actorId: string;
    action: string;
    entityType: string;
    entityId: string;
    before?: Prisma.InputJsonValue;
    after?: Prisma.InputJsonValue;
    meta: RequestMeta;
  },
): Promise<void> {
  await tx.auditLog.create({
    data: {
      actorId: entry.actorId,
      action: entry.action,
      entityType: entry.entityType,
      entityId: entry.entityId,
      before: entry.before,
      after: entry.after,
      ip: entry.meta.ip,
      userAgent: entry.meta.userAgent,
    },
  });
}
