import { createHash, randomBytes } from 'node:crypto';

/** Token aleatorio de 256 bits, seguro para URL y cookies. Se entrega a la persona UNA vez. */
export function generateToken(): string {
  return randomBytes(32).toString('base64url');
}

/**
 * En la base de datos solo se guarda este hash. Como el token ya es aleatorio de alta entropía,
 * SHA-256 es suficiente (no hace falta un hash lento como el de las contraseñas).
 */
export function hashToken(token: string): string {
  return createHash('sha256').update(token).digest('hex');
}
