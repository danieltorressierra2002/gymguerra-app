/**
 * Política de contraseñas: largo mínimo y lista de contraseñas comunes, sin exigir mezclas absurdas
 * de símbolos (las frases largas son más seguras y más fáciles de recordar).
 */
const COMMON = new Set([
  'password', 'password1', 'password123', 'contrasena', 'contrasena1', 'contrasena123', 'micontrasena',
  '1234567890', '12345678901', '0123456789', '9876543210', '1q2w3e4r5t', 'qwertyuiop', 'qwerty12345',
  'abcdefghij', 'abc1234567', 'iloveyou123', 'letmein123', 'admin12345', 'administrador', 'bienvenido1',
  'bienvenido123', 'cuba123456', 'cuba2026', 'habana123', 'artemisa123', 'gimnasio123', 'gimnasio2026',
  'entrenamiento', 'musculo123', 'fitness123', 'gymguerra', 'gymguerra1', 'gymguerra123', 'gymguerra2026',
  'guerragym', 'guerra2026',
]);

const clean = (s: string) =>
  s
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]/g, '');

export function passwordProblems(password: string, ctx: { email?: string } = {}): string[] {
  const problems: string[] = [];
  if (password.length < 10) problems.push('Debe tener al menos 10 caracteres.');
  if (password.length > 128) problems.push('No puede pasar de 128 caracteres.');

  const c = clean(password);
  if (COMMON.has(c)) problems.push('Es una contraseña demasiado común.');
  if (/^(.)\1+$/.test(password)) problems.push('No puede ser un solo carácter repetido.');
  if (c.includes('gymguerra') || c.includes('gimnasioguerra')) problems.push('No uses el nombre del gimnasio.');

  const local = clean((ctx.email ?? '').split('@')[0] ?? '');
  if (local.length >= 4 && c.includes(local)) problems.push('No uses tu correo electrónico.');
  return problems;
}
