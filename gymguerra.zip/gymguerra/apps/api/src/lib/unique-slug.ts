import { withSuffix } from '@gymguerra/shared';
import { AppError } from './errors';

/** Devuelve `base`, `base-2`, `base-3`... hasta encontrar uno libre. */
export async function uniqueSlug(base: string, exists: (slug: string) => Promise<boolean>): Promise<string> {
  for (let n = 1; n <= 50; n++) {
    const candidate = withSuffix(base, n);
    if (!(await exists(candidate))) return candidate;
  }
  throw AppError.conflict('SLUG_EXHAUSTED', 'No se pudo generar un identificador único; cambia el nombre');
}
