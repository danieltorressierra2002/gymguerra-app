import { describe, expect, it } from 'vitest';
import { passwordProblems } from './password-policy';
import { generateToken, hashToken } from './tokens';

describe('política de contraseñas', () => {
  it('acepta una frase larga', () => {
    expect(passwordProblems('el gato duerme en la azotea', { email: 'ana@correo.cu' })).toEqual([]);
  });

  it('exige al menos 10 caracteres y no más de 128', () => {
    expect(passwordProblems('corta1')).toContain('Debe tener al menos 10 caracteres.');
    expect(passwordProblems('a1'.repeat(70))).toContain('No puede pasar de 128 caracteres.');
  });

  it('rechaza contraseñas comunes, incluida la fija del sistema anterior', () => {
    expect(passwordProblems('gymguerra2026')).toContain('Es una contraseña demasiado común.');
    expect(passwordProblems('Password123')).toContain('Es una contraseña demasiado común.');
    expect(passwordProblems('1234567890')).toContain('Es una contraseña demasiado común.');
    expect(passwordProblems('Contraseña-123'.replace('-', ''))).toContain('Es una contraseña demasiado común.');
  });

  it('rechaza el nombre del gimnasio y el propio correo', () => {
    expect(passwordProblems('Mi-GymGuerra-super-fuerte')).toContain('No uses el nombre del gimnasio.');
    expect(passwordProblems('daniel.torres-2026-fuerte', { email: 'daniel.torres@correo.cu' })).toContain(
      'No uses tu correo electrónico.',
    );
  });

  it('rechaza un solo carácter repetido', () => {
    expect(passwordProblems('aaaaaaaaaaaa')).toContain('No puede ser un solo carácter repetido.');
  });
});

describe('tokens', () => {
  it('generateToken: único, largo y seguro para URL', () => {
    const a = generateToken();
    expect(a).not.toBe(generateToken());
    expect(a.length).toBeGreaterThanOrEqual(43);
    expect(a).toMatch(/^[A-Za-z0-9_-]+$/);
  });

  it('hashToken: determinista, hexadecimal de 64 caracteres y no revela el token', () => {
    const t = generateToken();
    expect(hashToken(t)).toBe(hashToken(t));
    expect(hashToken(t)).toMatch(/^[0-9a-f]{64}$/);
    expect(hashToken(t)).not.toContain(t);
    expect(hashToken(t)).not.toBe(hashToken(generateToken()));
  });
});
