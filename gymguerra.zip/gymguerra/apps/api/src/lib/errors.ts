import type { ErrorRequestHandler, RequestHandler } from 'express';
import { Prisma } from '@prisma/client';
import { ZodError } from 'zod';

export class AppError extends Error {
  constructor(
    public readonly status: number,
    public readonly code: string,
    message: string,
    public readonly details?: unknown,
  ) {
    super(message);
    this.name = 'AppError';
  }

  static badRequest(code: string, message: string, details?: unknown) {
    return new AppError(400, code, message, details);
  }
  static unauthorized(code = 'UNAUTHORIZED', message = 'Autenticación requerida') {
    return new AppError(401, code, message);
  }
  static forbidden(code = 'FORBIDDEN', message = 'No tienes permiso para esta acción') {
    return new AppError(403, code, message);
  }
  static notFound(message = 'No encontrado') {
    return new AppError(404, 'NOT_FOUND', message);
  }
  static conflict(code: string, message: string) {
    return new AppError(409, code, message);
  }
}

export const notFoundHandler: RequestHandler = (_req, _res, next) => {
  next(AppError.notFound('Ruta no encontrada'));
};

function body(code: string, message: string, details?: unknown) {
  return { error: { code, message, ...(details ? { details } : {}) } };
}

/** Manejo global de errores: nunca filtra trazas ni detalles internos al cliente. */
export const errorHandler: ErrorRequestHandler = (err, req, res, _next) => {
  if (err instanceof AppError) {
    res.status(err.status).json(body(err.code, err.message, err.details));
    return;
  }

  if (err instanceof ZodError) {
    const issues = err.issues.map((i) => ({ path: i.path.join('.'), message: i.message }));
    res.status(400).json(body('VALIDATION_ERROR', 'Datos inválidos', issues));
    return;
  }

  // Restricción de exclusión de constraints.sql: membresías solapadas
  if (err instanceof Error && err.message.includes('memberships_no_overlap_excl')) {
    res
      .status(409)
      .json(body('MEMBERSHIP_OVERLAP', 'El cliente ya tiene una membresía en esas fechas'));
    return;
  }

  if (err instanceof Prisma.PrismaClientKnownRequestError) {
    if (err.code === 'P2002') {
      res.status(409).json(body('CONFLICT', 'Ya existe un registro con esos datos'));
      return;
    }
    if (err.code === 'P2025') {
      res.status(404).json(body('NOT_FOUND', 'No encontrado'));
      return;
    }
  }

  // JSON mal formado (body-parser)
  if (err && typeof err === 'object' && 'type' in err && err.type === 'entity.parse.failed') {
    res.status(400).json(body('INVALID_JSON', 'El cuerpo de la petición no es JSON válido'));
    return;
  }

  console.error('Error no controlado', { path: req.path, method: req.method, err });
  res.status(500).json(body('INTERNAL_ERROR', 'Ocurrió un error inesperado'));
};
