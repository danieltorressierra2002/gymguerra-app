import { z } from 'zod';

const schema = z
  .object({
    NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
    PORT: z.coerce.number().int().min(1).max(65535).default(4000),
    DATABASE_URL: z.string().url(),
    CORS_ORIGINS: z
      .string()
      .min(1)
      .transform((s) =>
        s
          .split(',')
          .map((o) => o.trim())
          .filter(Boolean),
      ),
    GYM_TIMEZONE: z
      .string()
      .default('UTC')
      .refine((tz) => {
        try {
          new Intl.DateTimeFormat('en-CA', { timeZone: tz });
          return true;
        } catch {
          return false;
        }
      }, 'GYM_TIMEZONE debe ser una zona horaria IANA válida'),
    TRUST_PROXY_HOPS: z.coerce.number().int().min(0).default(0),
    /** local = inicio de sesión propio (necesario para alojar en Cuba). firebase = opcional, solo fuera de Cuba. */
    AUTH_PROVIDER: z.enum(['local', 'firebase']).default('local'),
    /** Secreto para firmar los tokens de acceso (mínimo 32 caracteres): openssl rand -base64 48 */
    JWT_SECRET: z.string().optional(),
    ACCESS_TOKEN_TTL_MINUTES: z.coerce.number().int().min(1).max(60).default(15),
    REFRESH_TOKEN_TTL_DAYS: z.coerce.number().int().min(1).max(90).default(30),
    FIREBASE_SERVICE_ACCOUNT_BASE64: z.string().optional(),
    APP_NAME: z.string().min(1).default('Gimnasio Guerra'),
    /** URL pública del frontend: destino de los enlaces de los correos */
    APP_URL: z.string().url().default('http://localhost:5173'),
    /** none = no se envían correos (predeterminado): el administrador entrega los enlaces de activación */
    EMAIL_PROVIDER: z.enum(['none', 'console', 'resend']).default('none'),
    RESEND_API_KEY: z.string().optional(),
    MAIL_FROM: z.string().optional(),
  })
  .superRefine((v, ctx) => {
    if (v.AUTH_PROVIDER === 'local' && (v.JWT_SECRET?.length ?? 0) < 32) {
      ctx.addIssue({
        code: 'custom',
        path: ['JWT_SECRET'],
        message: 'Requerida (mínimo 32 caracteres) cuando AUTH_PROVIDER=local',
      });
    }
    if (v.AUTH_PROVIDER === 'firebase' && !v.FIREBASE_SERVICE_ACCOUNT_BASE64) {
      ctx.addIssue({
        code: 'custom',
        path: ['FIREBASE_SERVICE_ACCOUNT_BASE64'],
        message: 'Requerida cuando AUTH_PROVIDER=firebase',
      });
    }
    if (v.EMAIL_PROVIDER === 'resend') {
      for (const key of ['RESEND_API_KEY', 'MAIL_FROM'] as const) {
        if (!v[key]) ctx.addIssue({ code: 'custom', path: [key], message: 'Requerida cuando EMAIL_PROVIDER=resend' });
      }
    }
    // El proveedor "console" imprime los enlaces de acceso en la terminal: nunca en producción
    if (v.NODE_ENV === 'production' && v.EMAIL_PROVIDER === 'console') {
      ctx.addIssue({ code: 'custom', path: ['EMAIL_PROVIDER'], message: 'En producción usa un proveedor real (resend)' });
    }
  });

export type Env = z.infer<typeof schema>;

/** Falla al arrancar (no en la primera petición) si falta algo. */
export function loadEnv(source: NodeJS.ProcessEnv = process.env): Env {
  const parsed = schema.safeParse(source);
  if (!parsed.success) {
    const detail = parsed.error.issues.map((i) => `  - ${i.path.join('.')}: ${i.message}`).join('\n');
    throw new Error(`Configuración inválida:\n${detail}`);
  }
  return parsed.data;
}
