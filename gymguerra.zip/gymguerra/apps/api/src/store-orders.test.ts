import request from 'supertest';
import { describe, expect, it } from 'vitest';
import { LEGAL_DOCUMENTS } from '@gymguerra/shared';
import { app, bearer, ids } from './test-helpers';

const productId = '5d4c3b2a-1f0e-4d9c-8b7a-6f5e4d3c2b1a';
const validOrder = { items: [{ productId, quantity: 2 }], acceptStoreTerms: true };

describe('tienda pública (sin sesión)', () => {
  it('lista productos sin exigir sesión y sin campos internos', async () => {
    const res = await request(app).get('/api/public/products').expect(200);
    expect(res.headers['cache-control']).toContain('max-age=60');
    const p = res.body.items[0];
    expect(Object.keys(p).sort()).toEqual(
      ['category', 'currency', 'description', 'id', 'imageUrl', 'name', 'price', 'slug'].sort(),
    );
    expect(Object.keys(p.category).sort()).toEqual(['name', 'slug']);
  });

  it('valida filtros y el identificador del producto', async () => {
    await request(app).get('/api/public/products?pageSize=1000').expect(400);
    await request(app).get('/api/public/products/BAD_SLUG').expect(400);
  });

  it('lista categorías y expone las versiones vigentes de los documentos legales', async () => {
    const cats = await request(app).get('/api/public/categories').expect(200);
    expect(cats.body.data[0]).toEqual({ id: 'c1', name: 'Suplementos', slug: 'suplementos' });
    const legal = await request(app).get('/api/public/legal').expect(200);
    expect(legal.body.data.documents).toEqual(LEGAL_DOCUMENTS);
  });
});

describe('productos y categorías: autorización', () => {
  it('exigen sesión de administrador', async () => {
    await request(app).get('/api/products').expect(401);
    for (const role of ['member', 'trainer']) {
      await request(app).get('/api/products').set(bearer(role)).expect(403);
      await request(app).post('/api/products').set(bearer(role)).send({}).expect(403);
      await request(app).delete(`/api/products/${ids.plan}`).set(bearer(role)).expect(403);
      await request(app).post('/api/categories').set(bearer(role)).send({ name: 'Ropa' }).expect(403);
      await request(app).delete(`/api/categories/${ids.plan}`).set(bearer(role)).expect(403);
    }
  });
});

describe('productos: validación', () => {
  const base = { categoryId: ids.plan, name: 'Camiseta', price: '12.00', currency: 'USD' };
  const post = (body: unknown) => request(app).post('/api/products').set(bearer('admin')).send(body as object);

  it('rechaza precios inválidos y moneda mal escrita', async () => {
    await post({ ...base, price: '1.234' }).expect(400);
    await post({ ...base, price: '-3' }).expect(400);
    await post({ ...base, currency: 'usd' }).expect(400);
  });

  it('solo acepta imágenes https (sin http ni javascript:)', async () => {
    await post({ ...base, imageUrl: 'http://img.test/a.jpg' }).expect(400);
    await post({ ...base, imageUrl: 'javascript:alert(1)' }).expect(400);
    await post({ ...base, imageUrl: 'data:image/png;base64,AAAA' }).expect(400);
  });

  it('no deja fijar el slug ni existe control de inventario', async () => {
    await post({ ...base, slug: 'mi-slug' }).expect(400);
    await post({ ...base, stockQty: 10 }).expect(400);
    await post({ ...base, minStock: 2 }).expect(400);
  });

  it('exige categoría y nombre válidos', async () => {
    await post({ ...base, categoryId: 'no-uuid' }).expect(400);
    await post({ ...base, name: 'x' }).expect(400);
  });

  it('en la edición valida igual', async () => {
    await request(app).patch(`/api/products/${ids.plan}`).set(bearer('admin')).send({ price: '9.999' }).expect(400);
    await request(app).patch(`/api/products/${ids.plan}`).set(bearer('admin')).send({ stockQty: 5 }).expect(400);
    await request(app).delete('/api/products/abc').set(bearer('admin')).expect(400);
  });

  it('valida el nombre de las categorías', async () => {
    await request(app).post('/api/categories').set(bearer('admin')).send({ name: 'a' }).expect(400);
    await request(app).post('/api/categories').set(bearer('admin')).send({ name: 'Ropa', slug: 'x' }).expect(400);
  });
});

describe('pedidos: autorización', () => {
  it('solo el cliente compra (ni administrador ni entrenador)', async () => {
    await request(app).post('/api/orders').set(bearer('admin')).send(validOrder).expect(403);
    await request(app).post('/api/orders').set(bearer('trainer')).send(validOrder).expect(403);
  });

  it('un usuario sin perfil de cliente no puede comprar', async () => {
    const res = await request(app).post('/api/orders').set(bearer('member')).send(validOrder).expect(403);
    expect(res.body.error.code).toBe('FORBIDDEN');
  });

  it('el entrenador no ve pedidos ni los cancela', async () => {
    await request(app).get('/api/orders').set(bearer('trainer')).expect(403);
    await request(app).post(`/api/orders/${ids.plan}/cancel`).set(bearer('trainer')).send({}).expect(403);
  });

  it('solo el administrador cambia el estado', async () => {
    for (const role of ['member', 'trainer']) {
      await request(app).patch(`/api/orders/${ids.plan}/status`).set(bearer(role)).send({ status: 'PREPARED' }).expect(403);
    }
  });
});

describe('pedidos: validación', () => {
  const post = (body: unknown) => request(app).post('/api/orders').set(bearer('member')).send(body as object);

  it('exige aceptar las condiciones de la tienda', async () => {
    await post({ items: validOrder.items }).expect(400);
    await post({ ...validOrder, acceptStoreTerms: false }).expect(400);
  });

  it('el precio y el total no vienen del navegador', async () => {
    await post({ ...validOrder, total: '0.01' }).expect(400);
    await post({ items: [{ productId, quantity: 1, unitPrice: '0.01' }], acceptStoreTerms: true }).expect(400);
  });

  it('valida cantidades, repetidos y tamaño del carrito', async () => {
    await post({ ...validOrder, items: [] }).expect(400);
    await post({ ...validOrder, items: [{ productId, quantity: 0 }] }).expect(400);
    await post({ ...validOrder, items: [{ productId, quantity: 21 }] }).expect(400);
    await post({ ...validOrder, items: [{ productId, quantity: 1 }, { productId, quantity: 2 }] }).expect(400);
    await post({ ...validOrder, items: [{ productId: 'no-uuid', quantity: 1 }] }).expect(400);
  });

  it('limita las notas', async () => {
    await post({ ...validOrder, notes: 'x'.repeat(301) }).expect(400);
  });

  it('el administrador no puede marcar un pedido como PAGADO a mano', async () => {
    const patch = (status: string) =>
      request(app).patch(`/api/orders/${ids.plan}/status`).set(bearer('admin')).send({ status });
    await patch('PAID').expect(400);
    await patch('PENDING').expect(400);
    await patch('INVENTADO').expect(400);
  });

  it('rechaza ids que no son UUID', async () => {
    await request(app).get('/api/orders/abc').set(bearer('admin')).expect(400);
    await request(app).post('/api/orders/abc/cancel').set(bearer('admin')).send({}).expect(400);
  });
});

describe('consentimientos legales y datos personales', () => {
  it('exigen sesión', async () => {
    await request(app).get('/api/consents/me').expect(401);
    await request(app).post('/api/consents').send({}).expect(401);
    await request(app).get('/api/members/me/export').expect(401);
  });

  it('rechaza tipos desconocidos y listas vacías', async () => {
    await request(app).post('/api/consents').set(bearer('member')).send({ documents: [] }).expect(400);
    await request(app)
      .post('/api/consents')
      .set(bearer('member'))
      .send({ documents: [{ type: 'OTRO', version: '1.0' }] })
      .expect(400);
  });

  it('no registra la aceptación de una versión que ya no es la vigente', async () => {
    const res = await request(app)
      .post('/api/consents')
      .set(bearer('member'))
      .send({ documents: [{ type: 'PRIVACY', version: '0.1' }] })
      .expect(409);
    expect(res.body.error.code).toBe('STALE_VERSION');
  });

  it('la descarga de datos personales es solo para clientes', async () => {
    await request(app).get('/api/members/me/export').set(bearer('trainer')).expect(403);
    await request(app).get('/api/members/me/export').set(bearer('admin')).expect(403);
  });
});
