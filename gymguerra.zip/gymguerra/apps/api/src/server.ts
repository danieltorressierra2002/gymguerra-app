import { PrismaClient } from '@prisma/client';
import { buildApp } from './app';
import { loadEnv } from './config/env';
import { createPasswordHasher } from './lib/password';
import { createFirebaseProvisioner } from './modules/auth/firebase-provisioner';
import { createFirebaseVerifier } from './modules/auth/firebase-verifier';
import { createJwtService } from './modules/auth/local/jwt';
import { createLocalAuth, type LocalAuthService } from './modules/auth/local/service';
import type { IdentityProvisioner } from './modules/auth/provisioner';
import type { TokenVerifier } from './modules/auth/verifier';
import { createConsoleSender } from './modules/email/console-sender';
import { createResendSender } from './modules/email/resend-sender';

const env = loadEnv();
const prisma = new PrismaClient();
const refreshTtlSeconds = env.REFRESH_TOKEN_TTL_DAYS * 86_400;

let verifier: TokenVerifier;
let provisioner: IdentityProvisioner;
let local: LocalAuthService | undefined;

if (env.AUTH_PROVIDER === 'local') {
  // Todo ocurre en tu propio servidor: no se envía ningún dato personal a un proveedor externo
  const accessTtlSeconds = env.ACCESS_TOKEN_TTL_MINUTES * 60;
  const auth = createLocalAuth({
    prisma,
    hasher: createPasswordHasher(),
    jwt: createJwtService({ secret: env.JWT_SECRET!, accessTtlSeconds }),
    config: { accessTtlSeconds, refreshTtlSeconds, appUrl: env.APP_URL },
  });
  verifier = auth.verifier;
  provisioner = auth.provisioner;
  local = auth.service;
} else {
  verifier = createFirebaseVerifier(env.FIREBASE_SERVICE_ACCOUNT_BASE64!);
  provisioner = createFirebaseProvisioner(env.FIREBASE_SERVICE_ACCOUNT_BASE64!, { appUrl: env.APP_URL });
}

const app = buildApp({
  prisma,
  verifier,
  provisioner,
  local,
  emailSender:
    env.EMAIL_PROVIDER === 'resend'
      ? createResendSender({ apiKey: env.RESEND_API_KEY!, from: env.MAIL_FROM! })
      : env.EMAIL_PROVIDER === 'console'
        ? createConsoleSender()
        : null, // none: sin correos
  config: {
    corsOrigins: env.CORS_ORIGINS,
    trustProxyHops: env.TRUST_PROXY_HOPS,
    timeZone: env.GYM_TIMEZONE,
    appName: env.APP_NAME,
    secureCookies: env.NODE_ENV === 'production',
    refreshTtlSeconds,
  },
});

const server = app.listen(env.PORT, () => {
  console.log(`API escuchando en :${env.PORT} (${env.NODE_ENV}, zona horaria ${env.GYM_TIMEZONE})`);
});

async function shutdown(signal: string) {
  console.log(`${signal} recibido, cerrando...`);
  server.close(async () => {
    await prisma.$disconnect();
    process.exit(0);
  });
}
process.on('SIGTERM', () => void shutdown('SIGTERM'));
process.on('SIGINT', () => void shutdown('SIGINT'));
