-- GymGuerra — constraints.sql
-- Se aplica como migración SQL manual DESPUÉS de la migración inicial de Prisma:
--   npx prisma migrate dev --create-only --name constraints
--   (pega este archivo en la migración generada y ejecuta `prisma migrate dev`)
-- Las columnas son camelCase, por eso van entre comillas dobles.

CREATE EXTENSION IF NOT EXISTS btree_gist;
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- ───────────── Unicidad solo entre registros activos (soft delete) ─────────────

CREATE UNIQUE INDEX users_email_active_uq
  ON users (lower(email)) WHERE "deletedAt" IS NULL;

CREATE UNIQUE INDEX members_document_active_uq
  ON members ("documentId") WHERE "deletedAt" IS NULL;

CREATE UNIQUE INDEX membership_plans_name_active_uq
  ON membership_plans (lower(name)) WHERE "deletedAt" IS NULL;

-- ───────────── Búsqueda avanzada de clientes (nombre parcial, sin tildes exactas) ─────────────

CREATE INDEX users_name_trgm_idx ON users USING gin (name gin_trgm_ops);

-- ───────────── CHECK: reglas de negocio a nivel de base de datos ─────────────

ALTER TABLE membership_plans
  ADD CONSTRAINT membership_plans_price_chk    CHECK (price >= 0),
  -- exactamente uno de los dos: meses calendario o días, y mayor que 0
  ADD CONSTRAINT membership_plans_duration_chk CHECK (
    num_nonnulls("durationMonths", "durationDays") = 1
    AND COALESCE("durationMonths", "durationDays") > 0
  );

ALTER TABLE memberships
  ADD CONSTRAINT memberships_dates_chk  CHECK ("endDate" > "startDate"),
  ADD CONSTRAINT memberships_frozen_chk CHECK ("frozenDaysTotal" >= 0);

ALTER TABLE payments
  ADD CONSTRAINT payments_amount_chk CHECK (amount > 0),
  -- un pago pagado siempre tiene fecha
  ADD CONSTRAINT payments_paid_at_chk CHECK (status <> 'PAID' OR "paidAt" IS NOT NULL),
  -- un pago pertenece a una membresía o a un pedido, nunca a ninguno
  ADD CONSTRAINT payments_target_chk CHECK ("membershipId" IS NOT NULL OR "orderId" IS NOT NULL);

ALTER TABLE products
  ADD CONSTRAINT products_price_chk CHECK (price >= 0);

ALTER TABLE orders
  ADD CONSTRAINT orders_amounts_chk CHECK (subtotal >= 0 AND discount >= 0 AND total >= 0);

ALTER TABLE order_items
  ADD CONSTRAINT order_items_qty_chk   CHECK (quantity > 0),
  ADD CONSTRAINT order_items_price_chk CHECK ("unitPrice" >= 0);

ALTER TABLE classes
  ADD CONSTRAINT classes_capacity_chk CHECK (capacity > 0),
  ADD CONSTRAINT classes_time_chk     CHECK ("endsAt" > "startsAt");

-- ───────────── Un cliente no puede tener membresías solapadas ─────────────
-- Las canceladas no cuentan. El rango es [inicio, vencimiento): el día del
-- vencimiento es también el inicio de la renovación y no se considera solape.

ALTER TABLE memberships
  ADD CONSTRAINT memberships_no_overlap_excl
  EXCLUDE USING gist (
    "memberId" WITH =,
    daterange("startDate", "endDate", '[)') WITH &&
  ) WHERE (status <> 'CANCELLED');

-- ───────────── audit_logs: solo inserción ─────────────
-- Los usuarios se eliminan con soft delete; un DELETE real sobre users
-- dispararía ON DELETE SET NULL y este trigger lo bloquearía a propósito.

CREATE OR REPLACE FUNCTION audit_logs_immutable() RETURNS trigger AS $$
BEGIN
  RAISE EXCEPTION 'audit_logs es de solo inserción';
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER audit_logs_no_update_delete
  BEFORE UPDATE OR DELETE ON audit_logs
  FOR EACH ROW EXECUTE FUNCTION audit_logs_immutable();

-- ───────────── Configuración inicial ─────────────

INSERT INTO settings (key, value, "updatedAt") VALUES
  ('membership.warningDays', '5'::jsonb, now()),       -- antes DIAS_ALERTA_AMARILLO
  ('membership.reminderDays', '[7, 3, 1]'::jsonb, now()),
  ('billing.defaultCurrency', '"USD"'::jsonb, now())    -- ajusta a tu moneda
ON CONFLICT (key) DO NOTHING;

-- ───────────── Opcional: RLS como segunda barrera ─────────────
-- La autorización principal vive en la API (middleware por rol). Si quieres
-- defensa en profundidad, activa RLS y fija el usuario por transacción:
--   BEGIN; SELECT set_config('app.user_id', '<uuid>', true); ...consultas...; COMMIT;
--
-- ALTER TABLE memberships ENABLE ROW LEVEL SECURITY;
-- CREATE POLICY memberships_member_read ON memberships FOR SELECT
--   USING ("memberId" IN (
--     SELECT id FROM members WHERE "userId" = current_setting('app.user_id')::uuid
--   ));
-- (el rol de la app necesita no ser dueño de la tabla, o usar FORCE ROW LEVEL SECURITY)
