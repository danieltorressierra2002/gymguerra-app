/**
 * Crea (o reactiva) el PRIMER administrador y muestra el enlace para que defina su contraseña.
 * Hace falta porque con inicio de sesión propio no hay una consola externa donde crear usuarios.
 *
 *   npm run admin:create -w @gymguerra/api -- --email dueno@ejemplo.cu --name "Nombre Apellido"
 */
import { randomUUID } from 'node:crypto';
import { PrismaClient } from '@prisma/client';
import { issuePasswordToken } from '../src/modules/auth/local/service';

function arg(name: string): string | undefined {
  const i = process.argv.indexOf(`--${name}`);
  return i >= 0 ? process.argv[i + 1] : undefined;
}

const email = arg('email')?.trim().toLowerCase();
const name = arg('name')?.trim();
if (!email || !name || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
  console.error('Uso: npm run admin:create -w @gymguerra/api -- --email correo@ejemplo.cu --name "Nombre Apellido"');
  process.exit(1);
}

const prisma = new PrismaClient();
try {
  let user = await prisma.user.findFirst({ where: { email, deletedAt: null } });
  if (user && user.role !== 'ADMIN') {
    console.error('Ya existe una cuenta con ese correo y no es de administrador. Usa otro correo.');
    process.exit(1);
  }
  if (!user) {
    user = await prisma.user.create({
      data: { email, name, role: 'ADMIN', status: 'PENDING', authProvider: 'local', authSubject: randomUUID() },
    });
  }
  const token = await issuePasswordToken(prisma, user.id, user.passwordHash ? 'PASSWORD_RESET' : 'PASSWORD_SETUP');
  const appUrl = process.env.APP_URL ?? 'http://localhost:5173';
  console.log(`\nAdministrador: ${email}`);
  console.log('Abre este enlace para crear la contraseña (un solo uso, caduca pronto):\n');
  console.log(`${appUrl}/crear-contrasena#token=${token}\n`);
} finally {
  await prisma.$disconnect();
}
