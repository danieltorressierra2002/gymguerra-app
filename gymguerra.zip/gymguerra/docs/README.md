# Documentación de GymGuerra

- **Sistema de diseño y pantallas** (documento): https://claude.ai/artifact/SQXxAWEyFB2jpUTNP1fv9k
- **Vista previa de los paneles** (lienzo): https://claude.ai/artifact/QKWYLp4o5Jb8BUGu6ELEXu
  - Copias locales en `mockups/` (son archivos del editor de diseño; se ven en el enlace).
- **Modelo de datos**: `apps/api/prisma/schema.prisma` y `apps/api/prisma/constraints.sql`
- **Tokens de diseño**: `apps/web/src/styles/tokens.css` y `apps/web/tailwind.config.js`
- **Referencia de la API**: `API.md`
