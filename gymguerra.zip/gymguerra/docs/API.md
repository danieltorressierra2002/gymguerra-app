# API de GymGuerra

Base: `/api`. Todas las rutas exigen `Authorization: Bearer <token>`.
Errores: `{ "error": { "code", "message", "details?" } }`. Las listas devuelven `{ items, total, page, pageSize }`.
Fechas: `AAAA-MM-DD`. Montos: texto decimal (`"25.50"`).

**Vencimiento:** los planes duran N *meses calendario* o N días. Un plan de 1 mes que empieza el 9 de nov vence el 9 de dic; ese día todavía cuenta (aparece «Por vencer») y la renovación empieza ese mismo día. Si el mes no tiene ese día se usa el último (31 ene + 1 mes = 28 feb).

Roles: **A** administrador · **T** entrenador · **C** cliente.

## Acceso y contraseñas
La API **nunca** fija ni conoce la contraseña de un cliente. Al crear un cliente se crea su cuenta sin contraseña y se le envía por correo un enlace de un solo uso para crearla.

| Método | Ruta | Roles | Descripción |
|---|---|---|---|
| POST | `/auth/forgot-password` | público | Cuerpo `{ "email" }`. Responde siempre `202` igual, exista o no la cuenta. Límite: 5 intentos por IP cada 15 min |

## Planes
Un plan dura N *meses calendario* (`"duration": { "months": 1 }`) o N días (`{ "days": 30 }`), nunca las dos. Cambiar el precio o la duración no afecta a las membresías ya vendidas: cada una guarda el precio de su venta.

| Método | Ruta | Roles | Descripción |
|---|---|---|---|
| GET | `/public/plans` | público | Planes activos para la landing (solo datos públicos, con caché de 1 min) |
| GET | `/plans` | A T C | Lista. Solo A puede pedir `?includeInactive=true` |
| GET | `/plans/:id` | A T C | Detalle (T y C solo si está activo) |
| POST | `/plans` | A | Crear (`name`, `price`, `currency`, `duration`, `benefits`, `includesTrainer`, `isActive`, `sortOrder`) |
| PATCH | `/plans/:id` | A | Editar parcialmente (`description: null` la borra) |
| DELETE | `/plans/:id` | A | Baja lógica; responde `activeMemberships` para avisar cuántas siguen vigentes |

## Configuración
| Método | Ruta | Roles | Descripción |
|---|---|---|---|
| GET | `/settings/membership` | A T C | Umbral del semáforo (`warningDays`) |
| PUT | `/settings/membership` | A | Cambia el umbral (0–60) |

## Miembros
| Método | Ruta | Roles | Descripción |
|---|---|---|---|
| GET | `/members` | A T | Lista. Filtros: `q`, `trainerId`, `hasTrainer`, `sort`, `dir`, `page`, `pageSize`. El entrenador ve solo a los suyos |
| GET | `/members/me` | C | Mi perfil y mi membresía actual |
| GET | `/members/me/export` | C | Descarga todos mis datos personales en JSON (derecho de acceso y portabilidad) |
| GET | `/members/:id` | A T C | Ficha (T: asignados; C: solo la suya) |
| POST | `/members` | A | Crea la cuenta (sin contraseña) y el perfil. Responde `setupLink`: enlace de un solo uso (72 h) que el administrador entrega al cliente. Si hay correo configurado, también se envía (`invitationSent`) |
| POST | `/members/:id/invite` | A | Genera un enlace nuevo (invalida el anterior) y lo devuelve en `setupLink` |
| PATCH | `/members/:id` | A C | A: todo. C: solo teléfono, dirección y contacto de emergencia |
| DELETE | `/members/:id` | A | Baja lógica (exige no tener membresía vigente) |

## Membresías
| Método | Ruta | Roles | Descripción |
|---|---|---|---|
| GET | `/memberships` | A T C | Filtros: `state` (OK, EXPIRING, EXPIRED, FROZEN, CANCELLED), `memberId`, `planId`, `trainerId`, `paymentMethod`, `endFrom`, `endTo`, `q`, `sort`, `dir` |
| GET | `/memberships/me` | C | Mi membresía vigente con semáforo |
| GET | `/memberships/:id` | A T C | Detalle |
| POST | `/memberships` | A | Crear (pago opcional en la misma operación) |
| POST | `/memberships/:id/renew` | A | Renovar (empieza el día del vencimiento; si ya venció, hoy) |
| POST | `/memberships/:id/freeze` | A | Pausar |
| POST | `/memberships/:id/unfreeze` | A | Reanudar (corre el vencimiento) |
| POST | `/memberships/:id/cancel` | A | Cancelar (motivo obligatorio) |

## Pagos
| Método | Ruta | Roles | Descripción |
|---|---|---|---|
| GET | `/payments` | A C | Filtros: `memberId`, `membershipId`, `orderId`, `method`, `status`, `from`, `to`. C ve solo los suyos |
| GET | `/payments/:id` | A C | Detalle |
| GET | `/payments/:id/receipt` | A C | Datos del recibo (solo pagos PAGADOS) |
| POST | `/payments` | A | Pago manual ligado a una membresía o pedido. `idempotencyKey` evita duplicados |
| POST | `/payments/:id/void` | A | Anular (motivo obligatorio) |

## Tienda
La tienda **no controla existencias**: el administrador edita los productos y los quita cuando se agotan (`DELETE` = baja lógica; `isActive: false` = ocultar sin borrar). Un pedido con un producto que ya no está publicado se rechaza con `409 PRODUCT_UNAVAILABLE` y la lista de productos.

Público (sin sesión, caché de 1 min):

| Método | Ruta | Descripción |
|---|---|---|
| GET | `/public/categories` | Categorías activas |
| GET | `/public/products` | Productos activos. Filtros: `category` (slug), `q`, `page`, `pageSize` |
| GET | `/public/products/:slug` | Detalle |

Administración:

| Método | Ruta | Roles | Descripción |
|---|---|---|---|
| GET, POST | `/categories` | A | Listar / crear (el slug se genera solo y no cambia al renombrar) |
| PATCH, DELETE | `/categories/:id` | A | Editar / baja (no si aún tiene productos) |
| GET | `/products` | A | Filtros: `q`, `categoryId`, `isActive`, `page`, `pageSize` |
| POST | `/products` | A | Crear (`categoryId`, `name`, `price`, `currency`, `imageUrl` https, `sku` opcional) |
| PATCH, DELETE | `/products/:id` | A | Editar / quitar. Cambiar precio o nombre no afecta pedidos ya hechos |

## Pedidos
Precios, nombres y totales los calcula el servidor; el cliente solo envía productos y cantidades.

| Método | Ruta | Roles | Descripción |
|---|---|---|---|
| POST | `/orders` | C | Crear desde el carrito. Exige `acceptStoreTerms: true` (queda registrado con su versión) |
| GET | `/orders` | A C | Filtros: `status`, `memberId`, `from`, `to`. C ve solo los suyos |
| GET | `/orders/:id` | A C | Detalle con líneas y pagos |
| POST | `/orders/:id/cancel` | A C | Cancelar (solo si está PENDIENTE) |
| PATCH | `/orders/:id/status` | A | `PREPARED`, `DELIVERED` o `CANCELLED`. **PAGADO no se fija a mano**: ocurre cuando los pagos cubren el total |

Estados: PENDIENTE, PAGADO, PREPARADO, ENTREGADO (o CANCELADO). Un pedido pagado no se cancela directamente: primero se anula el pago.

## Documentos legales y consentimientos

| Método | Ruta | Roles | Descripción |
|---|---|---|---|
| GET | `/public/legal` | público | Versión y fecha de vigencia de cada documento |
| GET | `/consents/me` | A T C | `current`, `accepted` y `pending` (los de inicio de sesión que faltan) |
| POST | `/consents` | A T C | `{ documents: [{ type, version }] }`. Solo acepta la versión vigente (`409 STALE_VERSION` si no) |

## Cuentas y sesiones (inicio de sesión propio)
No hay contraseñas por defecto: cada cuenta se activa con un enlace de un solo uso que llega por correo. Las contraseñas se guardan con **scrypt** y nunca se devuelven.

- El **token de acceso** dura 15 minutos y va en `Authorization: Bearer <token>`. Guárdalo solo en memoria.
- El **token de renovación** viaja en la cookie `gg_rt` (`HttpOnly`, `SameSite=Strict`, `Secure` en producción, solo para `/api/auth`). Rota en cada uso; reutilizar uno viejo cierra la sesión.
- El frontend debe llamar con `credentials: 'include'` y estar en el mismo sitio (por ejemplo `app.gimnasio.cu` y `api.gimnasio.cu`).
- Los enlaces de los correos llevan el token en el fragmento: `https://…/crear-contrasena#token=…` (el frontend lo lee con `location.hash`).

| Método | Ruta | Descripción |
|---|---|---|
| POST | `/auth/login` | `{ email, password }` → `accessToken` y cookie de renovación. 10 intentos / 15 min por IP; la cuenta se bloquea 15 min tras 5 fallos. Los errores no revelan si el correo existe |
| POST | `/auth/refresh` | Renueva el acceso con la cookie y rota el token de renovación |
| POST | `/auth/logout` | Cierra la sesión (efecto inmediato) y borra la cookie |
| POST | `/auth/set-password` | `{ token, password }`. Crea la contraseña (cuenta nueva o recuperación). Un solo uso; cierra las demás sesiones |
| POST | `/auth/forgot-password` | `{ email }`. Con correo configurado: siempre `202`, exista o no la cuenta. **Sin correo** (predeterminado) responde `501 EMAIL_DISABLED`: el cliente pide un enlace nuevo a la administración |
| POST | `/account/change-password` | (con sesión) `{ currentPassword, newPassword }`. Cierra las otras sesiones |

Política de contraseñas: mínimo 10 caracteres, sin contraseñas comunes, sin el correo ni el nombre del gimnasio. Se aceptan frases largas.
