# Parte legal de GymGuerra

> **Importante:** los textos son plantillas redactadas sin conocer el país del gimnasio. No son asesoría
> legal. Un abogado que conozca la ley de protección de datos y de consumo de tu país debe revisarlos y
> ajustarlos antes de publicar. Cada punto que depende de la ley local está marcado con `[[REVISAR: ...]]`.

## Qué incluye

| Pieza | Dónde |
|---|---|
| Política de Privacidad, Cookies, Términos, Condiciones de la Tienda y Aviso Legal | `apps/web/src/features/legal/content/*.md` |
| Datos del gimnasio que se insertan en los textos | `apps/web/src/features/legal/legal-config.ts` |
| Páginas legales (`<LegalPage slug="privacidad" />`) y pie con enlaces (`<LegalLinks />`) | `LegalPage.tsx`, `LegalLinks.tsx` |
| Aviso de cookies con Aceptar / Rechazar / Configurar y enlace «Preferencias de cookies» | `CookieBanner.tsx` |
| Pantalla de aceptación tras iniciar sesión | `ConsentGate.tsx` |
| Registro de qué versión aceptó cada persona, cuándo y desde qué IP | tabla `consents` + `/api/consents` |
| Descarga de mis datos (acceso y portabilidad) | `GET /api/members/me/export` |
| Comprobación previa a publicar | `npm run legal:check -w @gymguerra/web` |

## Antes de publicar
1. Completa `legal-config.ts` (razón social, documento fiscal, dirección, correo, país, jurisdicción...).
2. Revisa los textos con un abogado y resuelve todas las notas `[[REVISAR: ...]]`.
3. Ejecuta `npm run legal:check -w @gymguerra/web`: debe terminar sin pendientes.
4. Audita el sitio publicado: la tabla de la Política de Cookies debe coincidir con lo que realmente se guarda.

## Cómo se conecta
- **Tras iniciar sesión:** llama a `GET /api/consents/me`; si `pending` no está vacío, muestra `<ConsentGate pending={...} onAccept={...} />`. `onAccept` llama a `POST /api/consents` con las versiones de `current`.
- **Al comprar:** envía `acceptStoreTerms: true` en `POST /api/orders`. La API registra la aceptación.
- **Cookies:** monta `<CookieBanner />` una vez en la app y `<LegalLinks />` en el pie. Hoy solo se usa almacenamiento técnico, así que se muestra un aviso informativo. **Si añades analítica o publicidad**, agrégalas a `COOKIE_CONFIG.optionalInUse`, carga sus scripts solo cuando `hasConsent(readConsent(), 'analytics')` sea verdadero y sube `CONSENT_VERSION`.
- **Cambiar un documento de forma relevante:** sube su versión en `packages/shared/src/legal.ts`; a todos se les volverá a pedir aceptarlo.

## Decisiones de diseño
- Rechazar cookies tiene el mismo estilo y está en la primera capa; las casillas opcionales empiezan apagadas; el consentimiento caduca a los 180 días; retirarlo es tan fácil como darlo (enlace permanente en el pie).
- Las fuentes se alojan en tu propio dominio (no Google Fonts), para no enviar la IP de los visitantes a un tercero. Las vistas previas de diseño sí usan Google Fonts, solo para mostrarse.
- Las pruebas de consentimiento no se borran con la baja del usuario (`onDelete: Restrict`).

## Lo que queda pendiente
- **Supresión definitiva:** la baja de un cliente es lógica (conserva pagos y pedidos por obligaciones contables). Falta una función de anonimización de datos personales cuando venza el plazo legal de conservación.
- **Recibos en PDF** y notificaciones de cambios de estado.
- Confirmar con el equipo que los nombres `gg-theme` y `gg-cart` de la política de cookies coincidan con los reales.

## Normativa cubana consultada (Artemisa, Cuba)
Los textos se adaptaron a lo que dicen estas dos normas. **Un abogado cubano debe confirmar que aplican a tu caso y que no falta nada.**

- **Ley 149/2022 «De Protección de Datos Personales»** (Gaceta Oficial, 25 de agosto de 2022). Reconoce los derechos de acceso, rectificación, actualización, cancelación y oposición.
- **Resolución 58/2022 del Ministerio de Comunicaciones** (Reglamento para la seguridad y protección de los datos personales en soporte electrónico). Lo que exige y cómo lo cubrimos:

| Exigencia | Dónde se cubre |
|---|---|
| Alojar los datos personales en **servidores ubicados en Cuba** (art. 7) | `privacidad.md` §3. **Requiere cambios en la infraestructura: ver abajo** |
| Informar el propósito al pedir cada dato, dónde se guardan y por cuánto tiempo (art. 8 a) | `privacidad.md` §2, §3 y §5 |
| Describir las opciones para gestionar la privacidad (art. 8 b) | `privacidad.md` §6 |
| Avisar de elementos que rastreen la actividad, incluso de terceros (art. 8 c) | `cookies.md` y aviso del `CookieBanner` |
| Comunicar los cambios de los términos con **3 meses** de antelación (art. 8 d) | `privacidad.md` §10 y `terminos.md` §9 |
| Notificar a las autoridades los incidentes de ciberseguridad (art. 4 c) | `privacidad.md` §7 |
| Vías para acceder, modificar y cancelar los datos; respaldos (art. 6) | `GET /api/members/me/export`, edición de perfil, baja; copias de respaldo |

## Alojamiento en Cuba: lo que cambia en la infraestructura
El artículo 7 de la Resolución 58/2022 dice que los datos personales en soporte electrónico solo se alojan o replican en servidores nacionales. Por eso **no sirven** para guardar datos de clientes los servicios que planteamos al inicio, porque están en el extranjero: Firebase/Firestore, Supabase, Railway, Render, Neon, AWS, Cloudinary, Resend y Google Drive.

Lo que sí puede ir fuera (no contiene datos de clientes): el código en GitHub y los diseños promocionales (Canva, B12).

La API ya está separada por interfaces para este cambio, pero faltan estas piezas **locales**:
1. ✅ **Inicio de sesión propio** (hecho): contraseñas con hash scrypt, sesiones que se pueden cerrar al instante y enlaces de un solo uso. Es el predeterminado (`AUTH_PROVIDER=local`).
2. ✅ **Sin correo** (decisión del gimnasio): el administrador entrega a cada cliente su enlace de activación, por WhatsApp o en persona.
3. **Fotos e imágenes en el propio servidor** en lugar de Cloudinary o S3 (pendiente).
4. **PostgreSQL y la API en un servidor ubicado en Cuba**, con copias de respaldo (pendiente).

Hasta que existan, **no publiques con datos reales de clientes.**
