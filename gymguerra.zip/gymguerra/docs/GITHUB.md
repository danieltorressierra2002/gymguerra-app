# Subir GymGuerra a GitHub

GitHub guarda el **código** y ejecuta las pruebas automáticas. **No aloja la API ni la base de datos**:
GitHub Pages solo sirve páginas estáticas. Los datos de los clientes viven en tu servidor (ver `LEGAL.md`).

Hay dos caminos. Si solo puedes subir **archivos sueltos** (no carpetas), usa el **A**.

---

## A. Solo con archivos (sirve desde el teléfono)

Subes **un solo `.zip`** y GitHub lo descomprime y ordena en carpetas por ti.

1. **Crea el repositorio.** En github.com: *New repository*, nombre `gymguerra`, **Private**, y **sin** README, `.gitignore` ni licencia.
2. **Crea el flujo que descomprime.** En el repositorio: *Add file → Create new file*. En el nombre escribe exactamente
   `.github/workflows/desempaquetar.yml` (al escribir cada `/`, GitHub crea la carpeta). Pega el contenido del archivo
   `desempaquetar.yml` y pulsa *Commit changes*.
3. **Sube el zip.** *Add file → Upload files*, elige `gymguerra.zip` **sin descomprimirlo** y pulsa *Commit changes*.
4. **Espera medio minuto.** En la pestaña **Actions** verás «Desempaquetar proyecto». Cuando termine en verde, el repositorio
   tendrá todas las carpetas y el zip habrá desaparecido.
   - Si no arrancó (por ejemplo, subiste el zip antes de crear el flujo): *Actions → Desempaquetar proyecto → Run workflow*.
   - Si falla con «permission denied»: *Settings → Actions → General → Workflow permissions → Read and write permissions*.
5. **Pruebas automáticas (opcional).** Repite el paso 2 con el nombre `.github/workflows/ci.yml` y el contenido de `ci.yml`.
   Va aparte porque GitHub no permite que un flujo cree otros flujos.
6. **Comprueba.** Deben verse las carpetas `apps`, `packages` y `docs`. Si añadiste el paso 5, el flujo `CI` debe terminar en verde.

> Si Actions no estuviera disponible para tu cuenta, usa el camino B desde una computadora o con Termux.

---

## B. Con git (computadora o Termux)

Descomprime `gymguerra.zip` y, dentro de la carpeta `gymguerra`:

```bash
git init -b main
git config user.name "Tu nombre"
git config user.email "tu-correo@ejemplo.com"
git add .
git status                  # revisa: NO debe aparecer ningún archivo .env
git commit -m "Versión inicial"
git remote add origin https://github.com/TU-USUARIO/gymguerra.git
git push -u origin main
```

GitHub te pedirá usuario y un **token de acceso personal** (Settings → Developer settings → Personal access tokens)
en lugar de la contraseña. En Android puedes usar **Termux** (`pkg install git unzip`).

---

## Secretos
- **Nunca** subas `.env`, claves ni cuentas de servicio. El `.gitignore` ya los bloquea.
- Para el despliegue, guarda las claves en *Settings → Secrets and variables → Actions*.
- Si alguna vez subes un secreto por error, **cámbialo en el servicio de origen**: borrarlo del repositorio no basta, queda en el historial.

## El repositorio anterior (`gymguerra-app`)
Su código tiene escrita la contraseña fija `gymguerra2026`, y también estará en su historial. Como la aplicación nunca se usó,
lo más limpio es **archivarlo o eliminarlo** (*Settings → Danger Zone*) y trabajar solo con el repositorio nuevo.

## Guarda una copia propia
Las reglas de sanciones pueden cambiar. De vez en cuando haz una copia completa:

```bash
git clone --mirror https://github.com/TU-USUARIO/gymguerra.git gymguerra-respaldo.git
```
