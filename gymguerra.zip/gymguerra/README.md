# GymGuerra

Monorepo: `apps/web` (React + Vite + Tailwind), `apps/api` (Express + Prisma + PostgreSQL),
`packages/shared` (lógica de membresías compartida).

## Arranque local

```bash
npm install
docker compose up -d db                 # PostgreSQL local
cp apps/api/.env.example apps/api/.env  # completa JWT_SECRET (openssl rand -base64 48)
cd apps/api
npx prisma migrate dev --name init      # crea las tablas
# Pega constraints.sql en una migración vacía:
npx prisma migrate dev --create-only --name constraints
npm run dev
```

## Pruebas

```bash
npm test          # shared (semáforo) + api (autenticación, permisos, validación)
npm run typecheck
```

## Notas
- Las fechas de membresía son `AAAA-MM-DD`; "hoy" se calcula con `GYM_TIMEZONE`.
- Los planes se miden en meses calendario o en días (exactamente uno de los dos).
- Nadie tiene contraseña fija: las cuentas se activan con un enlace por correo (`EMAIL_PROVIDER`).
- Firebase Authentication: añade el dominio de `APP_URL` en «Dominios autorizados».
- El umbral del semáforo vive en la tabla `settings` (`membership.warningDays`).
- Nada de credenciales en el código: todo por variables de entorno.

## Parte legal
Los documentos (privacidad, cookies, términos, condiciones de la tienda y aviso legal) son **plantillas** en
`apps/web/src/features/legal/content/`. Antes de publicar: completa `legal-config.ts`, haz que los revise un
abogado de tu país y ejecuta `npm run legal:check -w @gymguerra/web` hasta que pase. Ver `docs/LEGAL.md`.

## Más documentación
- `docs/GITHUB.md`: cómo subir el proyecto a GitHub.
- `docs/LEGAL.md`: parte legal, normativa cubana y alojamiento de datos en Cuba.
- `docs/API.md`: referencia de la API.

## Primer administrador
Con inicio de sesión propio no hay una consola externa donde crear usuarios. Crea el primero desde el servidor:

```bash
npm run admin:create -w @gymguerra/api -- --email dueno@ejemplo.cu --name "Nombre Apellido"
```

Muestra un enlace de un solo uso para que defina su contraseña. A partir de ahí, el administrador crea a los clientes desde el panel y a cada uno le llega su enlace por correo.

## Sin correos
Por decisión del gimnasio no se envían correos (`EMAIL_PROVIDER=none`). Al crear un cliente, la API devuelve `setupLink`: el administrador se lo entrega (WhatsApp, en persona...) y el cliente crea su contraseña. Si olvida la contraseña, el administrador genera otro enlace con `POST /api/members/:id/invite`.

## Interfaz web
Pantallas: inicio de sesión, crear contraseña (enlace de activación), **panel del cliente** (estado de la membresía, pagos y recibos, tienda con carrito, pedidos, perfil) y **panel del administrador** (resumen, miembros con todas sus acciones, planes, productos, pedidos y ajustes). El entrenador ve a sus clientes en modo consulta.

```bash
npm run dev -w @gymguerra/api    # API en :4000
npm run dev -w @gymguerra/web    # interfaz en :5173 (reenvía /api a la API)
npm run build -w @gymguerra/web  # genera apps/web/dist
```

**Despliegue en un solo servidor** (recomendado, y necesario para las cookies de sesión): un servidor web (por ejemplo nginx) sirve `apps/web/dist` y reenvía `/api` a la API, bajo el mismo dominio. Con `TRUST_PROXY_HOPS=1` y `CORS_ORIGINS` igual al dominio público. Las fuentes van incluidas en el paquete: no se piden a ningún servicio externo.
